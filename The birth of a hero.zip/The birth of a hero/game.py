"""""
Чтобы запустить файл теперь нужен vpn, тк тг всё банит
"""""
import telebot
from telebot import types


from project_data.config import bot_token
from project_data.db_birth_hero.db_operation import *
from project_data.fonts import *
from project_data.game.enemies import *
from project_data.game.weapons_new import *
from project_data.game.armors_new import *
from project_data.game.magic import *
from project_data.plot import get_plot, get_markup

from time import sleep


# region settings
bot = telebot.TeleBot(token=bot_token)
remove = types.ReplyKeyboardRemove()
# endregion
# region send
def send(message, key_plot, key_markup=None, user_name=None, gif=None, game_object=None, full=True, old_equip=None, new_equip=None):
    # todo: доработать картинки, гифки, видео
    id = message.from_user.id

    plot = get_plot(key=key_plot, user_name=user_name, id=id, game_object=game_object, full=full, old_equip=old_equip,
    new_equip=new_equip)

    for text in plot:
        if text == plot[0]:
            if text not in ['vido', 'gif', 'image', 'pass']:
                bot.send_message(message.chat.id, text, reply_markup=remove, parse_mode='HTML')
            if full:
                if text == 'gif':
                    with open(gif, "rb") as gif:
                        bot.send_animation(message.chat.id, gif, reply_markup=remove)
        elif text == plot[-1] and key_markup:
            if text not in ['vido', 'gif', 'image']:
                bot.send_message(message.chat.id, text, reply_markup=get_markup(key=key_markup, id=id), parse_mode='HTML')
            if full:
                if text == 'gif':
                    with open(gif, "rb") as gif:
                        bot.send_animation(message.chat.id, gif, reply_markup=get_markup(key=key_markup, id=id))
        else:
            if text not in ['vido', 'gif', 'image']:
                bot.send_message(message.chat.id, text, parse_mode='HTML')
            if full:
                if text == 'gif':
                    with open(gif, "rb") as gif:
                        bot.send_animation(message.chat.id, gif)
        if get_user(id, 'in_battle') or get_user(id, 'in_inventory'):
            sleep(1)
        else:
            sleep(3)

# endregion
# region fight
"""""
как работает последовательность действий в бою:
пример: 1:1
первое число - приём(1) или магия(2)
второе число - слот навыка
"""""
def roll_dice(message):
    id = message.from_user.id
    points = randint(1, 6)
    save_fight(id, 'points', points)
    plot = get_plot(key='roll_dice', id=id)
    markup = get_markup(key='create_fight_interface', id=id)

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)


# endregion
# region story
@bot.message_handler(commands=['rebirth'])
def rebirth(message):
    id = message.from_user.id
    # region enemy
    save_enemy(id, 'name', 'Разбойник (Алчек)')
    save_enemy(id, 'health', 20)
    save_enemy(id, 'defence', 0)
    # endregion
    # region fight
    save_fight(id, 'sequence', '')
    save_fight(id, 'points', 0)
    save_fight(id, 'hero_move', True)
    save_fight(id, 'equipped_weapon', 'Меч героя')
    save_fight(id, 'equipped_armor', 'Сияющие доспехи')
    save_fight(id, 'armor_bonus', False)
    # endregion
    # region hero
    save_hero(id, 'name', '')
    save_hero(id, 'max_health', 25)
    save_hero(id, 'health', 25)
    save_hero(id, 'max_defence', 5)
    save_hero(id, 'defence', 5)
    save_hero(id, 'cash', 10)
    # endregion
    # region inventory_armors
    save_inventory_armors(id, 'slot_1', 'Сияющие доспехи')
    save_inventory_armors(id, 'slot_2', '—')
    save_inventory_armors(id, 'slot_3', '—')
    # endregion
    # region inventory_consumables
    save_inventory_consumables(id, 'slot_1', '—')
    save_inventory_consumables(id, 'slot_2', '—')
    save_inventory_consumables(id, 'slot_3', '—')
    # endregion
    # region inventory_weapons
    save_inventory_weapons(id, 'slot_1', 'Меч героя')
    save_inventory_weapons(id, 'slot_2', '—')
    save_inventory_weapons(id, 'slot_3', '—')
    # endregion
    # region magic
    save_magic(id, 'slot_1', '—')
    save_magic(id, 'slot_2', '—')
    save_magic(id, 'slot_3', '—')
    save_magic(id, 'slot_4', '—')
    # endregion
    # region techniques
    save_techniques(id, 'slot_1', 'Размах и удар')
    save_techniques(id, 'slot_2', 'Защитная стойка')
    save_techniques(id, 'slot_3', '—')
    save_techniques(id, 'slot_4', '—')
    # endregion
    # region user
    save_user(id, 'reputation', 0)
    save_user(id, 'magic_level', 0)
    save_user(id, 'in_battle', False)
    save_user(id, 'in_inventory', False)
    save_stage(id, 1)
    save_user(id, 'choices', '')
    # endregion
    # region text
    send(message=message, key_plot='rebirth')
    # endregion
    bot.register_next_step_handler(message,  telegram_start)


@bot.message_handler(commands=['start'])
def telegram_start(message):
    id = message.from_user.id
    db_reg_user(id)
    if get_stage(id) == 1:
        create_all(id)
        send(message=message, key_plot='start', key_markup='start', user_name=message.from_user.first_name)


# endregion
# region prepare_to_fight
def open_the_bag_with_supplies(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    # todo: добавить расходники
    #markup = Markup(resize_keyboard=True)
    first = get_inventory_consumables(id, 'slot_1')
    second = get_inventory_consumables(id, 'slot_2')
    third = get_inventory_consumables(id, 'slot_3')
    if (first == '—') and (second == '—') and (third == '—'):
        bot.send_message(message.chat.id, f'{name}: Хм, кажется, тут пусто.', parse_mode='HTML')


# endregion
@bot.message_handler(content_types=['text'])
def main(message):
    text = message.text
    id = message.from_user.id
    stage = get_stage(id)
    # region fight
    if get_user(id, 'in_battle'):
        if text == 'Кинуть кубик.':
            roll_dice(message)

        elif text == 'Приёмы.':
            pass

        elif text == 'Магия.':
            # todo: сделать магию
            pass

        elif text == 'Осмотреть себя.':
            send(message=message, key_plot='check', key_markup='check_yourself_fight', game_object=hero, full=False)

        elif text == 'Вспомнить магию.':
            # todo: сделать магию
            pass

        elif text == 'Вспомнить приёмы.':
            send(message=message, key_plot='choice_technique', key_markup='choice_technique')


        elif text[8:] in techniques_name_to_object:
            techniques = [get_techniques(id, 'slot_1'), get_techniques(id, 'slot_2'),
                          get_techniques(id, 'slot_3'), get_techniques(id, 'slot_4')]
            if text[8:] in techniques:
                slot = 'slot_' + text[5]
                technique = techniques_name_to_object[get_techniques(id, slot)]
            else:
                enemy = enemies_name_to_object[get_enemy(id, 'name')]
                slot = int(text[5])
                if slot == 1:
                    technique = enemy.weapon.techniques[0]
                elif slot == 2:
                    technique = enemy.weapon.techniques[1]
                elif slot == 3:
                    technique = enemy.techniques[0]
                elif slot == 4:
                    technique = enemy.techniques[1]
            send(message=message, key_plot='check', key_markup='create_fight_interface', game_object=technique, full=False)


        elif text == 'Вспомнить особенность брони.':
            special = armors_name_to_object[get_fight(id, 'equipped_armor')].special
            send(message=message, key_plot='check', key_markup='create_fight_interface', game_object=special, full=False)

        elif text == 'Осмотреть противника.':
            enemy = enemies_name_to_object[get_enemy(id, 'name')]
            send(message=message, key_plot='check', key_markup='check_enemy_fight', game_object=enemy, full=False)

        elif text == 'Вспомнить его приёмы.':
            send(message=message, key_plot='choice_enemy_technique', key_markup='choice_enemy_technique')

        elif 'Вспомнить особенность его брони.':
            enemy_special = enemies_name_to_object[get_enemy(id, 'name')].armor.special
            send(message=message, key_plot='check', key_markup='create_fight_interface', game_object=enemy_special, full=False)

        elif text == 'Закончить ход.':
            pass
    # endregion
    # region inventory
    elif get_user(id, 'in_inventory'):
        # todo: сделать магию
        # region hero
        if text == 'Осмотреть себя.':
            send(message=message, key_plot='check', key_markup='check_yourself', game_object=hero)

        elif text == 'Осмотреть оружие.':
            weapon = weapons_name_to_object[get_fight(id, 'equipped_weapon')]
            send(message=message, key_plot='check', key_markup='create_inventory_interface', game_object=weapon)

        elif text == 'Осмотреть броню.':
            armor = armors_name_to_object[get_fight(id, 'equipped_armor')]
            send(message=message, key_plot='check', key_markup='create_inventory_interface', game_object=armor)

        elif text == 'Вспомнить особенность брони.':
            special = armors_name_to_object[get_fight(id, 'equipped_armor')].special
            send(message=message, key_plot='check', key_markup='create_inventory_interface', game_object=special)

        elif text == 'Выбрать оружие.':
            send(message=message, key_plot='choice_weapon', key_markup='choice_weapon')

        elif text == 'Выбрать броню.':
            send(message=message, key_plot='choice_armor', key_markup='choice_armor')

        elif text == 'Вспомнить приёмы.':
            send(message=message, key_plot='choice_technique', key_markup='choice_technique')


        elif text[8:] in weapons_name_to_object:
            weapons = [get_inventory_weapons(id, 'slot_1'), get_inventory_weapons(id, 'slot_2'),
                       get_inventory_weapons(id, 'slot_3')]
            if text[8:] in weapons:
                new_equip = text[8:]
                old_equip = get_fight(id, "equipped_weapon")
                send(message=message, key_plot='change', key_markup='create_inventory_interface', old_equip=old_equip,
                new_equip=new_equip)


        elif text[8:] in armors_name_to_object:
            armors = [get_inventory_armors(id, 'slot_1'), get_inventory_armors(id, 'slot_2'),
                       get_inventory_armors(id, 'slot_3')]
            if text[8:] in armors:
                new_equip = text[8:]
                old_equip = get_fight(id, "equipped_armor")
                send(message=message, key_plot='change', key_markup='create_inventory_interface', old_equip=old_equip,
                new_equip=new_equip)


        elif text[8:] in techniques_name_to_object:
            techniques = [get_techniques(id, 'slot_1'), get_techniques(id, 'slot_2'),
                          get_techniques(id, 'slot_3'), get_techniques(id, 'slot_4')]
            if text[8:] in techniques:
                slot = 'slot_' + text[5]
                technique = techniques_name_to_object[get_techniques(id, slot)]
            else:
                enemy = enemies_name_to_object[get_enemy(id, 'name')]
                slot = int(text[5])
                if slot == 1:
                    technique = enemy.weapon.techniques[0]
                elif slot == 2:
                    technique = enemy.weapon.techniques[1]
                elif slot == 3:
                    technique = enemy.techniques[0]
                elif slot == 4:
                    technique = enemy.techniques[1]
            send(message=message, key_plot='check', key_markup='create_inventory_interface', game_object=technique)


        elif text == 'Открыть сумку c припасами.':
            open_the_bag_with_supplies(message)

        # endregion
        # region enemy
        elif text == 'Изучить противника.':
            enemy = enemies_name_to_object[get_enemy(id, 'name')]
            send(message=message, key_plot='check', key_markup='check_enemy', game_object=enemy)

        elif text == 'Осмотреть его оружие.':
            enemy_weapon = enemies_name_to_object[get_enemy(id, 'name')].weapon
            send(message=message, key_plot='check', key_markup='create_inventory_interface', game_object=enemy_weapon)

        elif text == 'Осмотреть его броню.':
            enemy_armor = enemies_name_to_object[get_enemy(id, 'name')].armor
            send(message=message, key_plot='check', key_markup='create_inventory_interface', game_object=enemy_armor)

        elif text == 'Узнать его приёмы.':
            send(message=message, key_plot='choice_enemy_technique', key_markup='choice_enemy_technique')

        elif text == 'Узнать особенность его брони.':
            enemy_special = enemies_name_to_object[get_enemy(id, 'name')].armor.special
            send(message=message, key_plot='check', key_markup='create_inventory_interface', game_object=enemy_special)

        # endregion
        elif text == 'Вернуться к выбору.':
            send(message=message, key_plot='fight_back_to_choice', key_markup='8.1')
            save_user(id, 'in_inventory', False)
    # endregion
    # region plot
    # region stage 1
    elif stage == 1:
        if text in [
                    'Кто ты?',
                    'Подожди, кто ты?'
                    ]:
            send(message=message, key_plot='1.1', key_markup='1.1')
        elif text in [
                    'Что за задача?',
                    'Ещё раз, что за задача?'
                    ]:
            send(message=message, key_plot='1.2', key_markup='1.2')
        elif text == 'Я готов.':
            save_stage(id, 2)
            send(message=message, key_plot='1.3')
    # endregion
    # region stage 2
    elif stage == 2:
        save_hero(userid=id, param='name', val=text)
        save_stage(id, 3)
        send(message=message, key_plot='2', key_markup='2')
    # endregion
    # region stage 3
    elif 3 <= stage < 4:
        if text == 'Узнать про пророчество.':
            save_stage(id, get_stage(id) + 0.5)
            if get_stage(id) == 4:
                key_markup = '3.3'
            else:
                key_markup = '3.1'
            send(message=message, key_plot='3.1', key_markup=key_markup)
        elif text == 'Спросить как стать героем в лохмотьях.':
            save_stage(id, get_stage(id) + 0.5)
            if get_stage(id) == 4:
                key_markup = '3.3'
            else:
                key_markup = '3.2'
            send(message=message, key_plot='3.2', key_markup=key_markup)
    # endregion
    # region stage 4
    elif stage == 4:
        if text == 'Спросить ещё что-нибудь.':
            save_stage(id, 5)
            send(message=message, key_plot='4', key_markup='4')
    # endregion
    # region stage 5
    elif 5 <= stage < 6:
        if text == 'Спросить о дальнейшем пути.':
            save_stage(id, get_stage(id) + 0.5)
            if get_stage(id) == 6:
                key_markup = '5.3'
            else:
                key_markup = '5.1'
            send(message=message, key_plot='5.1', key_markup=key_markup)
        elif text == 'Разузнать о происхождении Рассказчика.':
            save_stage(id, get_stage(id) + 0.5)
            if get_stage(id) == 6:
                key_markup = '5.3'
            else:
                key_markup = '5.2'
            send(message=message, key_plot='5.2', key_markup=key_markup)
    # endregion
    # region stage 6
    elif stage == 6:
        if text == 'Осмотреться.':
            save_stage(id, 7)
            send(message=message, key_plot='6', key_markup='6', gif="project_data/video_and_images/village.gif")
    # endregion
    # region stage 7
    elif stage == 7:
        if text == 'Двигаться в сторону ворот.':
            save_stage(id, 8)
            send(message=message, key_plot='7', key_markup='7')
    # endregion
    # region stage 8
    elif stage == 8:
        if text in ['Пойти и убедиться, что всё хорошо.', 'Вернуться и проверить, что всё хорошо.']:
            save_stage(id, 9)
            save_user(id, 'choices', '1')
            send(message=message, key_plot='8.1', key_markup='8.1')
        elif text == 'Пройти мимо как ни в чём не бывало.':
            send(message=message, key_plot='8.2', key_markup='8.2')
        elif text == 'Идти дальше, не обращая внимание.':
            save_user(id, 'choices', '2')
            save_stage(id, 9)
            # todo: доделать
    # endregion
    # region stage 9
    elif stage == 9:
        if text == 'Вступить в схватку.':
            save_enemy(id, 'name', 'Разбойник (Алчек)')
            save_enemy(id, 'health', 20)
            save_enemy(id, 'defence', 0)
            save_user(id, 'in_battle', True)
            send(message=message, key_plot='9.1', key_markup='9.1')
        elif text == 'Подготовиться к бою.':
            save_enemy(id, 'name', 'Разбойник (Алчек)')
            save_enemy(id, 'health', 20)
            save_enemy(id, 'defence', 0)
            save_user(id, 'in_inventory', True)
            send(message=message, key_plot='prepare_to_fight', key_markup='create_inventory_interface')
    # endregion
    # endregion

bot.infinity_polling()
# задачи:
# todo: каждому персонажу прикрутить портрет
