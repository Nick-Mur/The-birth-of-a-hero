# region imports
import telebot
from telebot import types

from project_data.config import bot_token
from project_data.db_birth_hero.db_operation import *
from project_data.fonts import *

import random
from time import sleep


# endregion
# region settings
bot = telebot.TeleBot(token=bot_token)
remove = types.ReplyKeyboardRemove()
Button = types.KeyboardButton
Markup = types.ReplyKeyboardMarkup
# endregion
# region send_text
def send_text_m(message, text, markup):
    bot.send_message(
        message.chat.id,
        text=text,
        reply_markup=markup,
        parse_mode='HTML',
    )
    sleep(3)


def send_text_r(message, text):
    bot.send_message(
        message.chat.id,
        text=text,
        reply_markup=remove,
        parse_mode='HTML'
    )
    sleep(3)


def send_text(message, text):
    bot.send_message(
        message.chat.id,
        text=text,
        parse_mode='HTML'
    )
    sleep(3)


# endregion


def fight(message):
    pass

# endregion
@bot.message_handler(commands=['rebirth'])
def rebirth(message):
    send_text_r(message=message,
                text="...")
    send_text(message=message,
                text=ancient_language("Пустота: Начнём же с самого начала. В другое время, в другом месте."))
    send_text(message=message,
                text=ancient_language("Пустота: как сильно изменится история?"
                                              " Как пойдёт она в этот раз? Решать тебе."))
    send_text(message=message,
                text=ancient_language("Пустота: Скажи что-нибудь, чтобы тебя услышали."))
    send_text(message=message,
                text="...")
    bot.register_next_step_handler(message,  telegram_start)


# region story
@bot.message_handler(commands=['start'])
def telegram_start(message):
    id = message.from_user.id
    db_reg_user(id)
    health = random.choice([30, 35, 40, 45, 50])
    save_hero(id, health, health, 5, 5, 10)
    save_stage(id, 0)
    markup = Markup(resize_keyboard=True)
    start_game_btn = Button('Кто ты?')
    markup.add(start_game_btn)
    send_text_m(message=message,
                text=italics("Неужели меня кто-то посетил?"),
                markup=markup)


def introduction_to_the_storyteller(message):
    markup = Markup(resize_keyboard=True)
    yes_btn = Button('Хочу, начинай уже!')
    no_btn = Button('Пожалуй, я пока не готов к такому.')
    markup.add(yes_btn, no_btn)
    send_text_r(message=message,
              text=italics("Так ты не знаешь?"))
    send_text(message=message,
              text=italics("Занятно."))
    send_text(message=message,
              text=italics(f"Зови меня рассказчиком, {message.from_user.first_name}, будем же знакомы."))
    send_text(message=message,
              text=italics("Не хочешь ли ты услышать одну историю? Эта история о монстрах и героях, о добре и зле, "
                           "о жизни и смерти. Но есть один нюанс. Скажем так, ты станешь её участником. "
                           "Главный совет - держись меня, лишь я тебя слышу, и только я могу всё исправить."))
    send_text_m(message=message,
                text=italics('Что скажешь?'),
                markup=markup)


def abandonment_of_adventure(message):
    markup = Markup(resize_keyboard=True)
    yes_btn = Button('Хорошо, убедил, начнём же творить историю!')
    send_text_r(message=message,
              text=italics('Я готов подождать, я понимаю, это предложение может показаться странным и непонятным.'))
    markup.add(yes_btn)
    send_text(message=message,
                text=italics('Но всё же советую задуматься над ним ещё раз. Эта история явно того стоит!'))
    send_text_m(message=message,
                text=italics('Готов ли ты?'),
                markup=markup)


def call_of_void(message):
    send_text_r(message=message,
                text=italics('Славно.'))
    send_text(message=message,
              text='...')
    # "пустота" - способ говорить с игроком вне сюжета
    text = underlined('ты')
    send_text(message=message,
              text=ancient_language(f'Пустота: Рассказчик меня не слышит, но слышишь {text}.'))
    text = underlined('Воспользуйся')
    send_text(message=message,
              text=ancient_language(f'Пустота: Он считает, что ты из нашего мира, он не знает, кто ты на самом деле. '
                                    f'{text} этим.'))
    text = underlined('не всемогущественны')
    send_text(message=message,
              text=ancient_language(f'Пустота: Здесь ты силён, как и он, но вы оба {text}.'))
    send_text(message=message,
              text=ancient_language('Пустота: Запоминай.'))
    send_text(message=message,
              text=ancient_language('Пустота: Введя в начале фразы "/",'
                                            ' ты сможешь воспользоваться своей особенностью.'
                                            'Например, ты можешь повернуть историю вспять и изменить ход событий!.'))
    text = underlined('героем')
    send_text(message=message,
              text=ancient_language(f'Пустота: Твоя задача наставлять крестьянина. Он должен стать {text}! Но как'
                                    ' именно ты это будешь делать, и на какой путь ты его поставишь - решать тебе.'))
    send_text(message=message,
              text=ancient_language('Пустота: Теперь, используй силу, чтобы выбрать своего героя.'))
    send_text(message=message,
              text=ancient_language('Пустота: Скажи его имя.'))


def choice_hero_name(message):
    markup = Markup(resize_keyboard=True)
    yes_btn = Button('Слушать и лицезреть.')
    markup.add(yes_btn)
    send_text_m(message=message,
                text=italics(ancient_language('Прекрасно. Начнём же историю.')),
                markup=markup)

def meet_the_hero(message):
    id = message.from_user.id
    name = get_one_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    ask_prophecy = Button('Узнать про пророчество.')
    ask_equipment = Button('Спросить как стать героем в лохмотьях.')
    markup.add(ask_prophecy, ask_equipment)
    send_text_r(message,
              f'{name}: Интересно, какого жить в том замке...'
              )
    send_text(message,
              f'{name}: Наверное у тех людей жизнь такая интересная.'
              )
    send_text(message,
              f'{name}: Вот был бы я одним из тех счастливчиков,'
              f' кто работает в страже, - точно бы изменил наше королевство!'
              )
    send_text(message,
              f'{name}: Ни один монстр не смог бы напасть!'
              )
    send_text(message,
              f'{name}: Хотя куда лучше быть в королевской страже... Они все там ... герои! Если бы не король-дурак, '
              f'боюсь даже представить, сколько великих дел они бы переделали. Сколько подвигов бы свершили!'
              )
    send_text(message,
              f'{name}: Вот бы и мне стать героем...'
              )
    send_text(message,
              f'{name}: О небеса, услышьте меня! Помогите мне стать героем! Я стал бы самым героическим героем!'
              )
    send_text(message,
              italics('Ну раз самым героическим...')
              )
    send_text(message,
              f'{name}: НИЧЕГО СЕБЕ!!!'
              )
    send_text(message,
              f'{name}: КТО ЭТО СКАЗАЛ?!'
              )
    send_text_m(message,
              italics(f'Не бойся меня, {name}, я пришёл на твой зов, дабы свершилось пророчество!'
                      f' Ты избран стать героем!'),
                markup
              )


def listen_prophecy(message):
    id = message.from_user.id
    name = get_one_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    ask_equipment = Button('Спросить как стать героем в лохмотьях.')
    markup.add(ask_equipment)
    send_text_r(message,
              f'{name}: Какое ещё "пророчество"?'
              )
    send_text(message,
              italics('Поговаривают, наступит тот день, когда герой из народа, заручившись поддержкой небес,'
                      ' спасёт королевство и избавит его от всех бед!')
              )
    send_text(message,
              f'{name}: И я тот самый герой?!'
              )
    send_text(message,
              italics('Это нам ещё предстоит выяснить.')
              )
    text = underlined('Рассказчиком')
    send_text(message,
              italics(f'А, и ещё, зови меня {text}. Мне так привычнее.')
              )
    send_text(message,
              f'{name}: Подожди, не значит ли это, что я не первый избранный?'
              )
    send_text(message,
              italics('Главное, чтобы ты оказался последним.')
              )
    if get_stage(id) == 4:
        markup = Markup(resize_keyboard=True)
        ask_something = Button('Спросить ещё что-нибудь.')
        markup.add(ask_something)
    send_text_m(message,
                f'{name}: Справедливо.',
                markup
                )


def find_how_to_be_a_hero(message):
    id = message.from_user.id
    name = get_one_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    ask_prophecy = Button('Узнать про пророчество.')
    markup.add(ask_prophecy)
    text = underlined('этом')
    send_text_r(message,
              f'{name}: Но как мне стать героем в {text}?'
              )
    # todo: выдать герою экипировку
    send_text(message,
              italics('О, точно, сейчас исправим.')
              )
    send_text(message,
              bold('Получены *Сияющие доспехи* и *Меч героя*.')
              )
    send_text(message,
              bold('*Сияющие доспехи* заменили *Лохмотья*.')
              )
    send_text(message,
              bold('Экипирован *Меч героя*.')
              )
    send_text(message,
              f'{name}: НИЧЕГО СЕБЕ!!!'
              )
    send_text(message,
              f'{name}: ТЫ И ТАК УМЕЕШЬ?!'
              )
    send_text(message,
              italics('Да, я много чего умею. Но это скорее исключение. Всё таки это не мой профиль.')
              )

    if get_stage(id) == 4:
        markup = Markup(resize_keyboard=True)
        ask_something = Button('Спросить ещё что-нибудь.')
        markup.add(ask_something)
    send_text_m(message,
                f'{name}: Вау...',
                markup
                )

def the_beginning_of_adventures(message):
    id = message.from_user.id
    name = get_one_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    wait = Button('Ждать, когда герой спустится.')
    markup.add(wait)
    send_text_r(message,
                italics('Ладно, довольно вопросов.')
                )
    send_text(message,
              italics('Время приключений!')
              )
    send_text(message,
              italics(f'Для начала, нам необходимо выйти из деревни.')
              )
    send_text(message,
              f'{name}: О, ну это легко. Я знаю здесь всё как свои 5 пальцев! Правда, это займёт время,'
              f' деревня довольная большая, а мы сейчас находимся на самой удалённой точке от ворот...'
              )
    send_text(message,
              italics('Ну, похоже приключение не на 20 минут туда и обратно...')
              )
    send_text(message,
              f'{name}: Для начала, нам нужно спуститься с этого уступа.'
              )
    send_text_m(message,
                italics('Так вперёд же мой друг!'),
                markup
                )


def serious_or_naive_hero(message):
    id = message.from_user.id
    name = get_one_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    naive_hero = Button('Я думаю всё и так будет хорошо!')
    serious_hero = Button('Надеюсь, он раскроет себя.')
    markup.add(naive_hero, serious_hero)
    send_text_r(message,
                f'...'
                )
    send_text(message,
              f'{name}: Знаешь, не такая уж и высокая гора оказалась, раньше я думал она огроменная!'
              )
    send_text(message,
              f'{name}: Вот что значит, путешествовать в компании! А вы как об этом думаете, господин Рассказчик?'
              )
    send_text(message,
              italics(f'Прошу, не называй меня так.'
                      f' Не хочу, чтобы меня сравнивали или даже приравнивали к обычным бездарям.')
              )
    send_text(message,
              italics(f'Идём же дальше, {name}.')
              )
    send_text(message,
              f'{name}: Хорошо, как скажете.'
              )
    text = underlined('настоящим')
    send_text_m(message,
                italics(f'Нам с тобой, {message.from_user.first_name}, похоже придётся долго слушать этого крестьянина. '
                        f'Ну ничего, надеюсь наш путь сделает его чуть серьёзнее, и он всё таки станет {text} героем.'
                        f' А ты как думаешь?'),
                markup
                )


def rapprochement_of_the_player_and_the_narrator(message):
    text = message.text
    markup = Markup(resize_keyboard=True)
    first = Button('Я ещё тебе не настолько доверяю.')
    second = Button('Тяжело вспомнить.')
    markup.add(first, second)
    if text == 'Я думаю всё и так будет хорошо!':
        send_text_r(message,
                    italics(f'Кажется мы по-разному понимаем понятие герой, ну ничего страшного.'
                            f' Мы ещё узнаем кто прав.')
                    )
    elif text == 'Надеюсь, он раскроет себя.':
        send_text_r(message,
                    italics(f'Я рад, что хоть мы и недавно познакомились, но уже понимаем друг друга. Жаль, '
                            f'это не от нас зависит. Или почти не от нас.')
                    )
    else:
        send_text_r(message,
                    italics(f'Я тебя не совсем понял, ну да ладно.')
                    )
    send_text_m(message,
                italics(f'Как ты таким стал, {message.from_user.first_name}?'),
                markup
                )


def situation_with_bandit(message):
    text = message.text
    id = message.from_user.id
    name = get_one_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    first = Button('Пойти и убедиться, что всё хорошо.')
    second = Button('Пройти мимо как ни в чём не бывало.')
    markup.add(first, second)
    if text == 'Я ещё тебе не настолько доверяю.':
        send_text_r(message,
                    italics(f'Да, пожалуй, верное замечание.')
                    )
    elif text == 'Тяжело вспомнить.':
        send_text_r(message,
                    italics(f'Знакомо, я тоже мало что помню. Лишь обрывками.'
                            f' Хотя я и не уверен, что это мои воспоминания.')
                    )
    else:
        send_text_r(message,
                    italics(f'Да, жизнь тебя потрепала. Странно,'
                            f' что я тебя не всегда понимаю. Может это связано с твоим происхождением? Ещё узнаем.')
                    )
    send_text(message,
              f'{name}: Смотри!'
              )
    send_text(message,
              f'{name}: Кажется, там что-то происходит!'
              )
    send_text(message,
              italics(f'Здесь постоянно что-то происходит, {name}, мы же в деревне.')
              )
    send_text(message,
              f'{name}: Да нет, я не про это. Мне показалось тот человек, который пошёл вслед за бабкой, достал кинжал!'
              )
    send_text(message,
              italics(f'Я понимаю, ты только что встал на путь героя, тебе хочется бороться со злом.')
              )
    text = underlined("уверен")
    send_text_m(message,
               italics(f'Но, во-первых, я ничего не заметил и, я {text}, тебе показалось. Во-вторых,'
                       f' если ты нападёшь на невиновного, то добром это не кончится.'),
                markup
                )


def last_chance_clash_with_the_bandit(message):
    markup = Markup(resize_keyboard=True)
    first = Button('Бежать на помощь.')
    second = Button('Идти дальше.')
    markup.add(first, second)
    send_text_r(message,
                f'Бабка: Ты ничего не получишь!'
                )
    send_text_m(message,
                f'Бабка: уйди от меня!',
                markup
                )


def clash_with_bandit(message):
    id = message.from_user.id
    name = get_one_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    first = Button('Вступить в схватку.')
    markup.add(first)
    send_text_r(message,
                f'Бабка: Ты, Алчек, всегда искал лёгкие пути! '
                )
    send_text(message,
              f'Разбойник (Алчек): Вот зачем ты кричишь. Я ведь просто попросил пару золотых!'
              )
    send_text(message,
              f'Бабка: И кинжал ты достал просто так?'
              )
    send_text(message,
              f'Бабка: Сейчас трудные времена. И ты решил, что тебе всё можно?'
              )
    send_text(message,
              f'Разбойник (Алчек): Слишком много вопросов, Преведа, мы хоть давно знакомы, но уж прости.'
              )
    send_text(message,
              f'Бабка (Преведа): Ну смотри, ты так легко не отделаешься!'
              )
    send_text(message,
              f'{name}: А ну отойди от неё, разбойник! '
              )
    send_text_m(message,
                f'Разбойник (Алчек): Я ТАК ЛЕГКО НЕ СДАМСЯ!',
                markup
                )




# endregion
@bot.message_handler(content_types=['text'])
def main(message):
    text = message.text
    id = message.from_user.id
    stage = get_stage(id)
    # region stage 0
    if stage == 0:
        if text == "Кто ты?":
            introduction_to_the_storyteller(message)
        elif text in [
                'Хочу, начинай уже!',
                'Хорошо, убедил, начнём же творить историю!'
                    ]:
            save_stage(id, 1)
            call_of_void(message)
        elif text == 'Пожалуй, я пока не готов к такому.':
            abandonment_of_adventure(message)
    # endregion
    elif stage == 1:
        save_one_hero(userid=id, param='name', val=text)
        save_stage(id, 2)
        choice_hero_name(message)
    elif stage == 2:
        if text == 'Слушать и лицезреть.':
            save_stage(id, 3)
            meet_the_hero(message)
    elif 3 <= stage < 4:
        if text == 'Узнать про пророчество.':
            save_stage(id, get_stage(id) + 0.5)
            listen_prophecy(message)
        elif text == 'Спросить как стать героем в лохмотьях.':
            save_stage(id, get_stage(id) + 0.5)
            find_how_to_be_a_hero(message)
    elif stage == 4:
        if text == 'Спросить ещё что-нибудь.':
            save_stage(id, 5)
            the_beginning_of_adventures(message)
    elif stage == 5:
        if text == 'Ждать, когда герой спустится.':
            save_stage(id, 6)
            serious_or_naive_hero(message)
    elif stage == 6:
        save_stage(id, 7)
        rapprochement_of_the_player_and_the_narrator(message)
    elif stage == 7:
        save_stage(id, 8)
        situation_with_bandit(message)
    elif stage == 8:
        if text in ['Пойти и убедиться, что всё хорошо.', 'Бежать на помощь.']:
            save_stage(id, 9)
            clash_with_bandit(message)
        elif text == 'Пройти мимо как ни в чём не бывало.':
            last_chance_clash_with_the_bandit(message)
        elif text == 'Идти дальше.':
            pass
        elif text == 'Вступить в схватку.':
            pass


bot.infinity_polling()
