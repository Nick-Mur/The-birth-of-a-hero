"""""
Чтобы запустить файл теперь нужен vpn, тк тг всё банит
"""""
import telebot
from telebot import types


from project_data.config import bot_token
from project_data.db_birth_hero.db_operation import *
from project_data.fonts import *
from project_data.game.enemies import *
from project_data.game.weapons_new import *
from project_data.game.armors_new import *
from project_data.game.magic import *
from project_data.plot import get_plot, get_markup

from time import sleep


# region settings
bot = telebot.TeleBot(token=bot_token)
remove = types.ReplyKeyboardRemove()
# endregion
# region send
def send_text_m(message, text, markup):
    id = message.from_user.id
    bot.send_message(
        message.chat.id,
        text=text,
        reply_markup=markup,
        parse_mode='HTML',
    )
    if get_user(id, 'in_battle') or get_user(id, 'in_inventory'):
        sleep(1)
    else:
        sleep(3)


def send_text_r(message, text):
    id = message.from_user.id
    bot.send_message(
        message.chat.id,
        text=text,
        reply_markup=remove,
        parse_mode='HTML'
    )
    if get_user(id, 'in_battle') or get_user(id, 'in_inventory'):
        sleep(1)
    else:
        sleep(3)

def send_text(message, text):
    id = message.from_user.id
    bot.send_message(
        message.chat.id,
        text=text,
        parse_mode='HTML'
    )
    if get_user(id, 'in_battle') or get_user(id, 'in_inventory'):
        sleep(1)
    else:
        sleep(3)


def send_gif(message, gif):
    id = message.from_user.id
    with open(gif, "rb") as gif:
        bot.send_animation(message.chat.id, gif)
    if get_user(id, 'in_battle') or get_user(id, 'in_inventory'):
        sleep(1)
    else:
        sleep(3)


# endregion
# region fight
"""""
как работает последовательность действий в бою:
пример: 1:1
первое число - приём(1) или магия(2)
второе число - слот навыка
"""""
def roll_dice(message):
    id = message.from_user.id
    points = randint(1, 6)
    save_fight(id, 'points', points)
    plot = get_plot(key='roll_dice', id=id)
    markup = get_markup(key='create_fight_interface', id=id)

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)

def check_yourself_fight(message):
    id = message.from_user.id
    plot = get_plot(key='check_yourself_fight', id=id)
    markup = get_markup(key='check_yourself_fight', id=id)

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)


def check_enemy_fight(message):
    id = message.from_user.id
    plot = get_plot(key='check_enemy_fight', id=id)
    markup = get_markup(key='check_enemy_fight', id=id)

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)


# endregion
# region story
@bot.message_handler(commands=['rebirth'])
def rebirth(message):
    id = message.from_user.id
    # region enemy
    save_enemy(id, 'name', 'Разбойник (Алчек)')
    save_enemy(id, 'health', 20)
    save_enemy(id, 'defence', 0)
    # endregion
    # region fight
    save_fight(id, 'sequence', '')
    save_fight(id, 'points', 0)
    save_fight(id, 'hero_move', True)
    save_fight(id, 'equipped_weapon', 'Меч героя')
    save_fight(id, 'equipped_armor', 'Сияющие доспехи')
    save_fight(id, 'armor_bonus', False)
    # endregion
    # region hero
    save_hero(id, 'name', '')
    save_hero(id, 'max_health', 25)
    save_hero(id, 'health', 25)
    save_hero(id, 'max_defence', 5)
    save_hero(id, 'defence', 5)
    save_hero(id, 'cash', 10)
    # endregion
    # region inventory_armors
    save_inventory_armors(id, 'slot_1', 'Сияющие доспехи')
    save_inventory_armors(id, 'slot_2', '')
    save_inventory_armors(id, 'slot_3', '')
    # endregion
    # region inventory_consumables
    save_inventory_consumables(id, 'slot_1', '')
    save_inventory_consumables(id, 'slot_2', '')
    save_inventory_consumables(id, 'slot_3', '')
    # endregion
    # region inventory_weapons
    save_inventory_weapons(id, 'slot_1', 'Меч героя')
    save_inventory_weapons(id, 'slot_2', '')
    save_inventory_weapons(id, 'slot_3', '')
    # endregion
    # region magic
    save_magic(id, 'slot_1', '')
    save_magic(id, 'slot_2', '')
    save_magic(id, 'slot_3', '')
    save_magic(id, 'slot_4', '')
    # endregion
    # region techniques
    save_techniques(id, 'slot_1', 'Размах и удар')
    save_techniques(id, 'slot_2', 'Защитная стойка')
    save_techniques(id, 'slot_3', '')
    save_techniques(id, 'slot_4', '')
    save_techniques(id, 'slot_5', '')
    save_techniques(id, 'slot_6', '')
    # endregion
    # region user
    save_user(id, 'reputation', 0)
    save_user(id, 'magic_level', 0)
    save_user(id, 'in_battle', False)
    save_user(id, 'in_inventory', False)
    save_stage(id, 1)
    save_user(id, 'choices', '')
    # endregion
    # region text
    plot = get_plot(key='rebirth')
    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text(message=message, text=plot[4])
    send_text(message=message, text=plot[5])
    send_text(message=message, text=plot[6])
    # endregion
    bot.register_next_step_handler(message,  telegram_start)


@bot.message_handler(commands=['start'])
def telegram_start(message):
    id = message.from_user.id
    db_reg_user(id)
    if get_stage(id) == 1:
        create_all(id)
        markup = get_markup(key='start')
        plot = get_plot(key='start', user_name=message.from_user.first_name)

        send_text_r(message=message, text=plot[0])
        send_text_m(message=message, text=plot[1], markup=markup)


def introduction_to_the_void(message):
    markup = get_markup(key='1.1')
    plot = get_plot(key='1.1')

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)

def find_out_the_goal_of_the_game(message):
    markup = get_markup(key='1.2')
    plot = get_plot(key='1.2')

    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text_m(message=message, text=plot[3], markup=markup)


def choice_hero_name(message):
    plot = get_plot(key='1.3')
    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])


def meet_the_hero(message):
    id = message.from_user.id
    markup = get_markup(key='2')
    plot = get_plot(key='2', id=id)

    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text(message=message, text=plot[4])
    send_text(message=message, text=plot[5])
    send_text(message=message, text=plot[6])
    send_text(message=message, text=plot[7])
    send_text(message=message, text=plot[8])
    send_text(message=message, text=plot[9])
    send_text(message=message, text=plot[10])
    send_text(message=message, text=plot[11])
    send_text(message=message, text=plot[12])
    send_text_m(message=message,text=plot[13], markup=markup)


def listen_prophecy(message):
    id = message.from_user.id
    plot = get_plot(key='3.1', id=id)

    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text(message=message, text=plot[4])
    send_text(message=message, text=plot[5])
    send_text(message=message, text=plot[5])
    if get_stage(id) == 4:
        markup = get_markup(key='3.3')
    else:
        markup = get_markup(key='3.1')
    send_text_m(message=message, text=plot[6], markup=markup)


def find_how_to_be_a_hero(message):
    id = message.from_user.id
    plot = get_plot(key='3.2', id=id)

    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text(message=message, text=plot[4])
    send_text(message=message, text=plot[5])
    send_text(message=message, text=plot[6])
    send_text(message=message, text=plot[7])
    if get_stage(id) == 4:
        markup = get_markup(key='3.3')
    else:
        markup = get_markup(key='3.2')
    send_text_m(message=message, text=plot[8], markup=markup)

def the_beginning_of_adventures(message):
    id = message.from_user.id
    markup = get_markup(key='4')
    plot = get_plot(key='4', id=id)

    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text(message=message, text=plot[4])
    send_text(message=message, text=plot[5])
    send_text_m(message=message, text=plot[6], markup=markup)


def ask_about_the_future_way(message):
    id = message.from_user.id
    plot = get_plot(key='5.1', id=id)

    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text(message=message, text=plot[4])
    send_text(message=message, text=plot[5])
    send_text(message=message, text=plot[6])
    send_text(message=message, text=plot[7])
    if get_stage(id) == 6:
        markup = get_markup(key='5.3')
    else:
        markup = get_markup(key='5.1')
    send_text_m(message=message, text=plot[8], markup=markup)


def find_out_about_the_origin_of_the_Storyteller(message):
    id = message.from_user.id
    plot = get_plot(key='5.2', id=id)

    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text(message=message, text=plot[4])
    send_text(message=message, text=plot[5])
    send_text(message=message, text=plot[6])
    send_text(message=message, text=plot[7])
    send_text(message=message, text=plot[8])
    send_text(message=message, text=plot[9])
    send_text(message=message, text=plot[10])
    send_text(message=message, text=plot[11])
    if get_stage(id) == 6:
        markup = get_markup(key='5.3')
    else:
        markup = get_markup(key='5.2')
    send_text_m(message=message, text=plot[12], markup=markup)


def look_around_the_village(message):
    id = message.from_user.id
    plot = get_plot(key='6', id=id)
    markup = get_markup(key='6')

    send_gif(message=message, gif="project_data/video_and_images/village.gif")
    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text(message=message, text=plot[4])
    send_text(message=message, text=plot[5])
    send_text(message=message, text=plot[6])
    send_text(message=message, text=plot[7])
    send_text_m(message=message, text=plot[8], markup=markup)


def situation_with_bandit(message):
    id = message.from_user.id
    markup = get_markup(key='7')
    plot = get_plot(key='7', id=id)

    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text_m(message=message, text=plot[4], markup=markup)


def clash_with_bandit(message):
    id = message.from_user.id
    markup = get_markup(key='8.1')
    plot = get_plot(key='8.1', id=id)

    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text(message=message, text=plot[4])
    send_text(message=message, text=plot[5])
    send_text(message=message, text=plot[6])
    send_text_m(message=message, text=plot[7], markup=markup)


def last_chance_clash_with_the_bandit(message):
    markup = get_markup(key='8.2')
    plot = get_plot(key='8.2')

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)


def teaching_fighting(message):
    id = message.from_user.id
    markup = get_markup(key='9.1')
    plot = get_plot(key='9.1', id=id)

    send_text_r(message=message, text=plot[0])
    send_text(message=message, text=plot[1])
    send_text(message=message, text=plot[2])
    send_text(message=message, text=plot[3])
    send_text(message=message, text=plot[4])
    send_text_m(message=message, text=plot[5], markup=markup)


# endregion
# region prepare_to_fight
def fight_back_to_choice(message):
    id = message.from_user.id
    plot = get_plot(key='fight_back_to_choice', id=id)
    markup = get_markup(key='8.1')

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)


# region hero
def prepare_to_fight(message):
    id = message.from_user.id
    plot = get_plot(key='prepare_to_fight', id=id)
    markup = get_markup(key='create_inventory_interface')

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)


def open_the_bag_with_supplies(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    # todo: добавить расходники
    #markup = Markup(resize_keyboard=True)
    first = get_inventory_consumables(id, 'slot_1')
    second = get_inventory_consumables(id, 'slot_2')
    third = get_inventory_consumables(id, 'slot_3')
    if (first == '—') and (second == '—') and (third == '—'):
        send_text(message,
                  f'{name}: Хм, кажется, тут пусто.')

def check_yourself(message, full=True, key_markup='check_yourself'):
    id = message.from_user.id
    markup = get_markup(key=key_markup, id=id)

    send_text_r(message=message, text='*ЗДЕСЬ БУДЕТ КАРТИНКА*')
    send_text_m(message=message, text=hero.info(id, full), markup=markup)


def check_special(message, description=True, key_markup='create_inventory_interface'):
    id = message.from_user.id
    markup = get_markup(key=key_markup, id=id)

    armor = armors_name_to_object[get_fight(id, 'equipped_armor')]
    special = armor.special

    send_text_r(message=message, text='*ЗДЕСЬ БУДЕТ КАРТИНКА*')
    send_text_m(message=message, text=special.info(description), markup=markup)


def check_weapon(message):
    id = message.from_user.id
    markup = get_markup(key='create_inventory_interface')

    weapon = weapons_name_to_object[get_fight(id, 'equipped_weapon')]

    send_text_r(message=message, text='*ЗДЕСЬ БУДЕТ КАРТИНКА*')
    send_text_m(message=message, text=weapon.info(), markup=markup)


def choice_weapon(message):
    id = message.from_user.id
    plot = get_plot(key='choice_weapon', id=id)
    markup = get_markup(key='choice_weapon', id=id)

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)


def choice_armor(message):
    id = message.from_user.id
    plot = get_plot(key='choice_armor', id=id)
    markup = get_markup(key='choice_armor', id=id)

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)


def check_armor(message):
    id = message.from_user.id
    markup = get_markup(key='create_inventory_interface')

    armor = armors_name_to_object[get_fight(id, 'equipped_armor')]
    send_text_r(message=message, text='*ЗДЕСЬ БУДЕТ КАРТИНКА*')
    send_text_m(message=message, text=armor.info(), markup=markup)

def choice_technique(message):
    id = message.from_user.id
    plot = get_plot(key='choice_technique', id=id)
    markup = get_markup(key='choice_technique', id=id)

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)


def check_technique(message, slot, description=True, key_markup='create_inventory_interface'):
    id = message.from_user.id
    markup = get_markup(key=key_markup, id=id)

    technique = techniques_name_to_object[get_techniques(id, slot)]

    send_text_r(message=message, text='*ЗДЕСЬ БУДЕТ КАРТИНКА*')
    send_text_m(message=message, text=technique.info(description), markup=markup)


# endregion
# region enemy
def check_enemy(message, full=True, key_markup='check_enemy'):
    id = message.from_user.id
    markup = get_markup(key=key_markup, id=id)

    enemy = enemies_name_to_object[get_enemy(id, 'name')]

    send_text_r(message=message, text='*ЗДЕСЬ БУДЕТ КАРТИНКА*')
    send_text_m(message=message, text=enemy.info(id, full), markup=markup)


def check_enemy_weapon(message):
    id = message.from_user.id
    markup = get_markup(key='create_inventory_interface')

    enemy = enemies_name_to_object[get_enemy(id, 'name')]

    send_text_r(message=message, text='*ЗДЕСЬ БУДЕТ КАРТИНКА*')
    send_text_m(message=message, text=enemy.weapon.info(), markup=markup)


def check_enemy_armor(message):
    id = message.from_user.id
    markup = get_markup(key='create_inventory_interface')

    enemy = enemies_name_to_object[get_enemy(id, 'name')]

    send_text_r(message=message, text='*ЗДЕСЬ БУДЕТ КАРТИНКА*')
    send_text_m(message=message, text=enemy.armor.info(), markup=markup)


def choice_enemy_technique(message):
    id = message.from_user.id
    plot = get_plot(key='choice_enemy_technique', id=id)
    markup = get_markup(key='choice_enemy_technique', id=id)

    send_text_r(message=message, text=plot[0])
    send_text_m(message=message, text=plot[1], markup=markup)


def check_enemy_technique(message, slot, description=True, key_markup='create_inventory_interface'):
    id = message.from_user.id
    markup = get_markup(key=key_markup)

    enemy = enemies_name_to_object[get_enemy(id, 'name')]
    if slot == 1:
        technique = enemy.weapon.techniques[0]
    elif slot == 2:
        technique = enemy.weapon.techniques[1]
    elif slot == 3:
        technique = enemy.techniques[0]
    elif slot == 4:
        technique = enemy.techniques[1]

    send_text_r(message=message, text='*ЗДЕСЬ БУДЕТ КАРТИНКА*')
    send_text_m(message=message, text=technique.info(description), markup=markup)


def check_enemy_special(message, description=True, key_markup='create_inventory_interface'):
    id = message.from_user.id
    markup = get_markup(key=key_markup)

    enemy = enemies_name_to_object[get_enemy(id, 'name')]
    send_text_r(message=message, text='*ЗДЕСЬ БУДЕТ КАРТИНКА*')
    send_text_m(message=message,text=enemy.armor.special.info(description), markup=markup)


def change_weapon(message, text):
    id = message.from_user.id
    markup = get_markup(key='create_inventory_interface')

    send_text_r(message=message, text=bold(f'Снят *{get_fight(id, "equipped_weapon")}*'))
    save_fight(id, 'equipped_weapon', text[8:])
    send_text_m(message, text=bold(f'Экипирован *{text}*'), markup=markup)


def change_armor(message, text):
    id = message.from_user.id
    markup = get_markup(key='create_inventory_interface')

    send_text_r(message=message, text=bold(f'Снят *{get_fight(id, "equipped_armor")}*'))
    save_fight(id, 'equipped_armor', text)
    send_text_m(message=message, text=bold(f'Экипирован *{text}*'), markup=markup)
# endregion
# endregion
@bot.message_handler(content_types=['text'])
def main(message):
    text = message.text
    id = message.from_user.id
    stage = get_stage(id)
    # region fight
    if get_user(id, 'in_battle'):
        if text == 'Кинуть кубик.':
            roll_dice(message)
        elif text == 'Приёмы.':
            pass
            #fight_choice_technique(message)
        elif text == 'Магия.':
            # todo: сделать магию
            pass
        elif text == 'Осмотреть себя.':
            check_yourself_fight(message)
        elif text == 'Проверить своё состояние.':
            check_yourself(message=message, full=False, key_markup='check_yourself_fight')
        elif text == 'Вспомнить магию.':
            # todo: сделать магию
            pass
        elif text == 'Вспомнить приёмы.':
            choice_technique(message)
        elif text[8:] in techniques_name_to_object:
            techniques = [get_techniques(id, 'slot_1'), get_techniques(id, 'slot_2'),
                          get_techniques(id, 'slot_3'), get_techniques(id, 'slot_4')]
            if text[8:] in techniques:
                slot = 'slot_' + text[5]
                check_technique(message=message, slot=slot, description=False, key_markup='create_fight_interface')
            else:
                check_enemy_technique(message=message, slot=int(text[5]), description=False, key_markup='create_fight_interface')
        elif text == 'Вспомнить особенность брони.':
            check_special(message=message, description=False, key_markup='create_fight_interface')
        elif text == 'Осмотреть противника.':
            check_enemy_fight(message=message)
        elif text == 'Вспомнить его приёмы.':
            choice_enemy_technique(message)
        elif text == 'Проверить его состояние.':
            check_enemy(message=message, full=False, key_markup='create_fight_interface')
        elif 'Вспомнить особенность его брони.':
            check_enemy_special(message=message, description=False, key_markup='create_fight_interface')
        elif text == 'Закончить ход.':
            pass
    # endregion
    # region inventory
    elif get_user(id, 'in_inventory'):
        # todo: сделать магию
        # region hero
        if text == 'Осмотреть себя.':
            check_yourself(message)
        elif text == 'Открыть сумку c припасами.':
            open_the_bag_with_supplies(message)
        elif text == 'Осмотреть оружие.':
            check_weapon(message)
        elif text == 'Выбрать оружие.':
            choice_weapon(message)
        elif text[8:] in weapons_name_to_object:
            weapons = [get_inventory_weapons(id, 'slot_1'), get_inventory_weapons(id, 'slot_2'),
                       get_inventory_weapons(id, 'slot_3')]
            if text[8:] in weapons:
                text = text[8:]
                change_weapon(message, text)
        elif text == 'Осмотреть броню.':
            check_armor(message)
        elif text == 'Выбрать броню.':
            choice_armor(message)
        elif text[8:] in armors_name_to_object:
            armors = [get_inventory_armors(id, 'slot_1'), get_inventory_armors(id, 'slot_2'),
                       get_inventory_armors(id, 'slot_3')]
            if text[8:] in armors:
                text = text[8:]
                change_armor(message, text)
        elif text == 'Вспомнить приёмы.':
            choice_technique(message)
        elif text[8:] in techniques_name_to_object:
            techniques = [get_techniques(id, 'slot_1'), get_techniques(id, 'slot_2'),
                          get_techniques(id, 'slot_3'), get_techniques(id, 'slot_4')]
            if text[8:] in techniques:
                slot = 'slot_' + text[5]
                check_technique(message, slot)
            else:
                check_enemy_technique(message, int(text[5]))
        elif text == 'Вспомнить особенность брони.':
            check_special(message)
        # endregion
        # region enemy
        elif text == 'Изучить противника.':
            check_enemy(message)
        elif text == 'Осмотреть его оружие.':
            check_enemy_weapon(message)
        elif text == 'Осмотреть его броню.':
            check_enemy_armor(message)
        elif text == 'Узнать его приёмы.':
            choice_enemy_technique(message)
        elif text == 'Узнать особенность его брони.':
            check_enemy_special(message)
        # endregion
        elif text == 'Вернуться к выбору.':
            save_user(id, 'in_inventory', False)
            fight_back_to_choice(message)
    # endregion
    # region stage 1
    elif stage == 1:
        if text in [
                    'Кто ты?',
                    'Подожди, кто ты?'
                    ]:
            introduction_to_the_void(message)
        elif text in [
                    'Что за задача?',
                    'Ещё раз, что за задача?'
                    ]:
            find_out_the_goal_of_the_game(message)
        elif text == 'Я готов.':
            save_stage(id, 2)
            choice_hero_name(message)
    # endregion
    # region stage 2
    elif stage == 2:
        save_hero(userid=id, param='name', val=text)
        save_stage(id, 3)
        meet_the_hero(message)
    # endregion
    # region stage 3
    elif 3 <= stage < 4:
        if text == 'Узнать про пророчество.':
            save_stage(id, get_stage(id) + 0.5)
            listen_prophecy(message)
        elif text == 'Спросить как стать героем в лохмотьях.':
            save_stage(id, get_stage(id) + 0.5)
            find_how_to_be_a_hero(message)
    # endregion
    # region stage 4
    elif stage == 4:
        if text == 'Спросить ещё что-нибудь.':
            save_stage(id, 5)
            the_beginning_of_adventures(message)
    # endregion
    # region stage 5
    elif 5 <= stage < 6:
        if text == 'Спросить о дальнейшем пути.':
            save_stage(id, get_stage(id) + 0.5)
            ask_about_the_future_way(message)
        elif text == 'Разузнать о происхождении Рассказчика.':
            save_stage(id, get_stage(id) + 0.5)
            find_out_about_the_origin_of_the_Storyteller(message)
    # endregion
    # region stage 6
    elif stage == 6:
        if text == 'Осмотреться.':
            save_stage(id, 7)
            look_around_the_village(message)
    # endregion
    # region stage 7
    elif stage == 7:
        if text == 'Двигаться в сторону ворот.':
            save_stage(id, 8)
            situation_with_bandit(message)
    # endregion
    # region stage 8
    elif stage == 8:
        if text in ['Пойти и убедиться, что всё хорошо.', 'Вернуться и проверить, что всё хорошо.']:
            save_stage(id, 9)
            save_user(id, 'choices', '1')
            clash_with_bandit(message)
        elif text == 'Пройти мимо как ни в чём не бывало.':
            last_chance_clash_with_the_bandit(message)
        elif text == 'Идти дальше, не обращая внимание.':
            save_user(id, 'choices', '2')
            save_stage(id, 9)
            # todo: доделать
    # endregion
    # region stage 9
    elif stage == 9:
        if text == 'Вступить в схватку.':
            save_enemy(id, 'name', 'Разбойник (Алчек)')
            save_enemy(id, 'health', 20)
            save_enemy(id, 'defence', 0)
            save_user(id, 'in_battle', True)
            teaching_fighting(message)
        elif text == 'Подготовиться к бою.':
            save_enemy(id, 'name', 'Разбойник (Алчек)')
            save_enemy(id, 'health', 20)
            save_enemy(id, 'defence', 0)
            save_user(id, 'in_inventory', True)
            prepare_to_fight(message)
    # endregion


bot.infinity_polling()
# задачи:
# todo: каждому персонажу прикрутить портрет
