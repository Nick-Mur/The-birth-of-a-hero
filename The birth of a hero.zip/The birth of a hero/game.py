"""""
Чтобы запустить файл теперь нужен vpn, тк тг всё банит
"""""
import telebot
from telebot import types


from project_data.config import bot_token
from project_data.db_birth_hero.db_operation import *
from project_data.fonts import *
from project_data.game.enemies import *
from project_data.game.weapons_new import *
from project_data.game.armors_new import *
from project_data.game.magic import *


from random import choice
from time import sleep
# region settings
bot = telebot.TeleBot(token=bot_token)
remove = types.ReplyKeyboardRemove()
Button = types.KeyboardButton
Markup = types.ReplyKeyboardMarkup
# endregion
# region send
def send_text_m(message, text, markup):
    bot.send_message(
        message.chat.id,
        text=text,
        reply_markup=markup,
        parse_mode='HTML',
    )
    #sleep(4)


def send_text_r(message, text):
    bot.send_message(
        message.chat.id,
        text=text,
        reply_markup=remove,
        parse_mode='HTML'
    )
    #sleep(4)


def send_text(message, text):
    bot.send_message(
        message.chat.id,
        text=text,
        parse_mode='HTML'
    )
    #sleep(4)


def send_gif(message, gif):
    bot.send_animation(message.chat.id, gif)
    #sleep(4)


# endregion
# region fight
def roll_dice(message):
    id = message.from_user.id
    name = get_hero(id, "name")

    points = randint(1, 6)
    save_fight(id, 'points', points)
    text = choice([f'Кости показали: твой потенциал на этот ход равен {points}',
                   f'Неплохо, {name}, твой потенциал - {points}',
                   f'Иии тебе выпало {points}'])
    send_text_r(message,
                italics(f'{text}')
                )
    send_text_m(message,
                italics(f'Что же ты сделаешь в этот раз, {name}?'),
                create_fight_interface(message))


def create_fight_interface(message):
    id = message.from_user.id
    markup = Markup(resize_keyboard=True)
    first = Button('Приёмы.')
    second = Button('Магия.')
    third = Button('Проверить себя.')
    fourth = Button('Проверить противника.')
    fifth = Button('Открыть сумку c расходниками.')
    sixth = Button('Закончить ход.')
    if get_user(id, 'magic_level') > 0:
        markup.add(first, second)
    else:
        markup.add(first)
    markup.add(third, fourth)
    markup.add(fifth)
    markup.add(sixth)
    return markup

def check_yourself(message):
    pass


# endregion
@bot.message_handler(commands=['rebirth'])
def rebirth(message):
    id = message.from_user.id
    save_stage(id, 1)
    send_text_r(message=message,
                text="...")
    send_text(message=message,
                text=ancient_language("Пустота: Решил начать сначала?"))
    send_text(message=message,
                text=ancient_language("Пустота: Всё по новой? Интересно."))
    send_text(message=message,
                text=ancient_language("Пустота: История повернётся вспять."))
    send_text(message=message,
                text=ancient_language("Пустота: Воспользуйся этим, не забывай ради чего это всё."))
    text = bold('Напиши что-нибудь')
    send_text(message=message,
                text=ancient_language(f"Пустота: {text}, чтобы я вновь тебя услышал."))
    send_text(message=message,
                text="...")
    bot.register_next_step_handler(message,  telegram_start)


# region story
@bot.message_handler(commands=['start'])
def telegram_start(message):
    id = message.from_user.id
    db_reg_user(id)
    if get_stage(id) == 1:
        create_all(id)
        markup = Markup(resize_keyboard=True)
        first = Button('Кто ты?')
        second = Button('Что за задача?')
        third = Button('Я готов.')
        markup.add(first, second)
        markup.add(third)

        send_text_r(message=message,
                    text=ancient_language(f"Пустота: Вновь приветствую тебя, {message.from_user.first_name}."))
        send_text_m(message=message,
                    text=ancient_language(f"Пустота: Надеюсь, ты помнишь о своей задаче?"),
                    markup=markup)


def introduction_to_the_void(message):
    markup = Markup(resize_keyboard=True)
    first = Button('Ещё раз, что за задача?')
    second = Button('Я готов.')
    markup.add(first)
    markup.add(second)

    text = underlined('что')
    send_text_r(message=message,
                text=ancient_language(f"Пустота: Сложно сказать, я скорее {text}. Но я более чем осознанное существо."))
    send_text_m(message=message,
                text=ancient_language(f"Пустота: Скажем, мы похожи, но я думаю ты и так понимаешь,"
                                      f" что мы отличаемся. Мы одни из тех, кто влияют на этот мир, но "
                                      f"способы у всех нас разные."),
                markup=markup)

def find_out_the_goal_of_the_game(message):
    markup = Markup(resize_keyboard=True)
    first = Button('Подожди, кто ты?')
    second = Button('Я готов.')
    markup.add(first)
    markup.add(second)

    send_text_r(message=message,
                text=ancient_language(f"Пустота: Снова забыл, ну ничего."))
    send_text(message=message,
              text=ancient_language(f"Пустота: Твоя цель - взрастить героя. Исполнить пророчество."))
    send_text(message=message,
                text=ancient_language(f"Пустота: Необходимо, чтобы ты стал для крестьянина воплощением судьбы."))
    text1 = underlined('переродиться')
    text2 = bold('введя')
    send_text_m(message=message,
                text=ancient_language(f"Пустота: Если ты хотел бы изменить прошлое, сделать иные выборы - ты можешь "
                                      f"{text1}, {text2} '/rebirth'."),
                markup=markup)


def choice_hero_name(message):
    text = bold('напиши имя')
    send_text_r(message=message,
                text=ancient_language(f"Пустота: После того как я договорю, {text} крестьянина,"
                                      f" которого ты хочешь выбрать."))
    text = underlined('рассказчиком')
    send_text(message=message,
              text=ancient_language(f"Пустота: Напомню, будь осторожнее с {text}. Он куда могущественнее, чем кажется."
                                    f" Он может помешать твоей задаче, нашей цели."))
    send_text(message=message,
              text=ancient_language(f"..."))


def meet_the_hero(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    ask_prophecy = Button('Узнать про пророчество.')
    ask_equipment = Button('Спросить как стать героем в лохмотьях.')
    markup.add(ask_prophecy, ask_equipment)

    text = underlined('Регнум Витаэ')
    send_text_r(message,
              f'{name}: Интересно, какого жить в том замке...'
              )
    send_text(message,
              f'{name}: Осознавать, что ты - король {text}.'
              )
    text = underlined('героя')
    send_text(message,
              f'{name}: Наверное, эта мысль и погубила нашего короля, нашего {text}.'
              )
    text = underlined('орден')
    send_text(message,
              f'{name}: Хорошо, что рядом был его {text}. Они доказали, что герой не един, '
              f'героями может быть целый орден!'
              )
    text = underlined('великим')
    send_text(message,
              f'{name}: Они во время заметили проблемы короля и рассказали о них народу. Они смогли помочь ему, '
              f'взвалив груз обязанностей на свои плечи, дабы у него была возможность снова стать {text}.'
              )
    send_text(message,
              f'{name}: Хотел бы я быть одним из них: таким же сильным и ловким, смелым и бесстрашным, '
              f'умным и великим...'
              )
    send_text(message,
              f'{name}: Вот если бы я там был, ни один монстр не посмел бы напасть так подло и коварно на мирный люд!'
              )
    send_text(message,
              f'{name}: Ох, небеса, только позвольте мне ненадолго стать героем - я изменю этот мир, '
              f'я устал от этой несправедливости, услышьте меня!'
              )
    send_text(message,
              italics(f'Я услышал тебя, {name}.')
              )
    send_text(message,
              italics(f'Кажется, ты не такой как все, раз заинтересовал высшие силы.')
              )
    text1 = underlined('пророчеством')
    text2 = underlined('героем')
    send_text(message,
              italics(f'Я до конца не уверен, но, кажется, я был призван {text1}, и ты взаправду получил шанс стать '
                      f'{text2}!')
              )
    send_text(message,
              f'{name}: Что, прости..?'
              )
    send_text(message,
              f'{name}: Я - избранный герой..?'
              )
    send_text_m(message,
              f'{name}: Но что? Как это вообще?',
              markup
              )


def listen_prophecy(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    ask_equipment = Button('Спросить как стать героем в лохмотьях.')
    markup.add(ask_equipment)

    send_text_r(message,
              f'{name}: Какое ещё "пророчество"?'
              )
    send_text(message,
              italics('Поговаривают, наступит тот день, когда герой люда, заручившись поддержкой небес,'
                      ' изменит Регнум Витаэ раз и навсегда и установит новый мировой порядок!')
              )
    send_text(message,
              f'{name}: И я тот самый герой?!'
              )
    send_text(message,
              italics('Это нам ещё предстоит выяснить.')
              )
    text = underlined('Рассказчиком')
    send_text(message,
              italics(f'А, и ещё, зови меня {text}. Мне так привычнее.')
              )
    send_text(message,
              f'{name}: Подожди, не значит ли это, что я не первый избранный?'
              )
    send_text(message,
              italics('Главное, чтобы ты оказался последним.')
              )
    if get_stage(id) == 4:
        markup = Markup(resize_keyboard=True)
        ask_something = Button('Спросить ещё что-нибудь.')
        markup.add(ask_something)
    send_text_m(message,
                f'{name}: Справедливо.',
                markup
                )


def find_how_to_be_a_hero(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    ask_prophecy = Button('Узнать про пророчество.')
    markup.add(ask_prophecy)

    text = underlined('этом')
    send_text_r(message,
              f'{name}: Но как мне стать героем в {text}?'
              )
    send_text(message,
              italics('О, точно, сейчас исправим.')
              )
    send_text(message,
              bold('Получены *Сияющие доспехи* и *Меч героя*.')
              )
    send_text(message,
              bold('*Сияющие доспехи* заменили *Лохмотья*.')
              )
    send_text(message,
              bold('Экипирован *Меч героя*.')
              )
    send_text(message,
              f'{name}: НИЧЕГО СЕБЕ!!!'
              )
    send_text(message,
              f'{name}: ТЫ И ТАК УМЕЕШЬ?!'
              )
    send_text(message,
              italics('Да, я много чего умею. Но это скорее исключение. Всё таки это не мой профиль.')
              )

    if get_stage(id) == 4:
        markup = Markup(resize_keyboard=True)
        ask_something = Button('Спросить ещё что-нибудь.')
        markup.add(ask_something)
    send_text_m(message,
                f'{name}: Вау...',
                markup
                )

def the_beginning_of_adventures(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    first = Button('Спросить о дальнейшем пути.')
    second = Button('Разузнать о происхождении Рассказчика.')
    markup.add(first)
    markup.add(second)

    send_text_r(message,
                italics('Ладно, довольно вопросов. Иначе мы так весь день просидим.')
                )
    send_text(message,
              italics('Мир не ждёт, кто-то может стать героем раньше тебя...')
              )
    send_text(message,
              f'{name}: Это разве работает по времени?'
              )
    send_text(message,
              italics('Не знаю, ты сам просил стать героем ненадолго.')
              )
    send_text(message,
              f'{name}: Ох, блин. И что же мне делать?'
              )
    send_text(message,
                italics('Для начала, я бы рекомендовал спуститься вон в ту деревню.'))
    send_text_m(message,
              f'{name}: Звучит разумно. (начал спускаться со склона)',
              markup
              )


def ask_about_the_future_way(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    first = Button('Разузнать о происхождении Рассказчика.')
    markup.add(first)

    send_text_r(message,
              f'{name}: Слушай, а у тебя уже есть какой-то план? Ну, куда мы пойдём-то, я хоть и выгляжу как рыцарь, '
              f'но я не знаю жизни за деревней, я там совсем редко бывал. Да и драться я не особо умею...'
              )
    send_text(message,
              italics('Спокойно, наш путь долог, ты ещё научишься. Мы направляемся к замку, к королю. Если ты, конечно, '
                      'не умрёшь по пути.')
              )
    send_text(message,
              f'{name}: ЧТО?!'
              )
    send_text(message,
              f'{name}: ПРЯМО К КОРОЛЮ?! '
              )
    send_text(message,
              f'{name}: Но зачем?'
              )
    send_text(message,
              italics('Король - "герой", пусть я и не согласен с этим, но факт есть факт. Ты должен изменить '
                      'Регнум Витаэ. А такое может быть связано с ним.')
              )
    send_text(message,
              italics('Тем более, если мы узнаем что-то новое, что откроем нам глаза на ситуацию, мы сможем изменить '
                      'наш маршрут, не так ли?')
              )
    send_text(message,
              f'{name}: Ну да, ты прав, тем более путь очень далёк...'
              )
    if get_stage(id) == 6:
        markup = Markup(resize_keyboard=True)
        first = Button('Осмотреться.')
        markup.add(first)
    send_text_m(message,
              italics('Вот и договорились.'),
              markup
              )


def find_out_about_the_origin_of_the_Storyteller(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    first = Button('Спросить о дальнейшем пути.')
    markup.add(first)

    send_text_r(message,
              f'{name}: Рассказчик, а ты всегда был... ну... таким?'
              )
    send_text(message,
              italics('Что ты имеешь ввиду?')
              )
    send_text(message,
              f'{name}: Возможно это глупо, но мне интересно, был ли ты таким всегда или нет, какого вообще быть тобой?'
              )
    send_text(message,
              italics('Сложно сказать, я слабо помню жизнь и была ли она вообще.')
              )
    send_text(message,
              italics('Есть отголоски прошлого, но я не могу до конца осознать это.')
              )
    text = underlined('что')
    send_text(message,
              italics(f'Так что сложно сказать, {text} я такое.')
              )
    send_text(message,
              italics(f'Какого быть мной?')
              )
    send_text(message,
              italics(f'Думаю скучно.')
              )
    send_text(message,
              italics(f'Я ожил лишь тогда, когда смог откликнуться на твой зов.')
              )
    send_text(message,
              italics(f'Хотя сейчас быть мной довольно... интересно? Думаю, да.')
              )
    send_text(message,
              italics(f'Я чувствую этот мир и являюсь его частью, но я не лишён сознания, что даёт некоторые '
                      f'преимущества. Думаю ты уже заметил это.')
              )
    send_text(message,
              f'{name}: Звучит и вправду хорошо! Рад за тебя! Думаю у нас всё получится!'
              )
    if get_stage(id) == 6:
        markup = Markup(resize_keyboard=True)
        first = Button('Осмотреться.')
        markup.add(first)
    send_text_m(message,
              italics(f'Ещё посмотрим, что получится. Не радуйся раньше времени.'),
              markup
              )


def look_around_the_village(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    first = Button('Двигаться в сторону ворот.')
    markup.add(first)

    with open("project_data/video_and_images/village.gif", "rb") as gif:
        send_gif(message, gif)
    send_text_r(message,
              f'{name}: Ах, родная деревня! Как же тут всё таки хорошо.'
              )
    send_text(message,
              italics(f'Если тут так хорошо, то чего тогда замечтался на уступе?')
              )
    send_text(message,
              f'{name}: Мечтать полезно и интересно. Всё таки жизнь не череда удач и радостей. Хоть и грех жаловаться, '
              f'но иногда душа хочет большего.'
              )
    send_text(message,
              italics(f'Нет ничего плохого в том, чтобы желать большего, чем у тебя есть сейчас. Даже если другие '
                      f'думают иначе.')
              )
    send_text(message,
              f'{name}: Хорошо, постараюсь запомнить этот урок.'
              )
    send_text(message,
              f'{name}: Как всё таки необычно быть в столь знакомом месте, но в совершенно другом образе!'
              )
    send_text(message,
              f'{name}: Я прямо таки вижу как смотрят на меня люди вокруг, как заглядываются барышни!'
              )
    send_text(message,
              italics(f'Не надо зазнаваться, ты только доспехами успел обзавестись.')
              )
    send_text_m(message,
                f'{name}: Да-да, как скажешь.',
                markup
                )


def situation_with_bandit(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    first = Button('Пойти и убедиться, что всё хорошо.')
    second = Button('Пройти мимо как ни в чём не бывало.')
    markup.add(first)
    markup.add(second)

    send_text_r(message,
              f'{name}: Смотри!'
              )
    send_text(message,
              f'{name}: Кажется, там что-то происходит!'
              )
    send_text(message,
              italics(f'Здесь постоянно что-то происходит, {name}, мы же в деревне.')
              )
    text = underlined("кинжал")
    send_text(message,
              f'{name}: Да нет, я не про это. Мне показалось, тот человек, который пошёл вслед за бабкой, достал {text}!'
              )
    send_text_m(message,
              italics(f'Хм, и что же ты сделаешь? Учти, если ты нападёшь на невиновного, то добром это не кончится. '
                      f'И я не думаю, что лезть в чужие дела такая хорошая идея. Но ты тут герой - решать тебе.'),
              markup
              )

def last_chance_clash_with_the_bandit(message):
    markup = Markup(resize_keyboard=True)
    first = Button('Вернуться и проверить, что всё хорошо.')
    second = Button('Идти дальше, не обращая внимание.')
    markup.add(first)
    markup.add(second)

    send_text_r(message,
                f'Бабка: Ты ничего не получишь!'
                )
    send_text_m(message,
                f'Бабка: уйди от меня!',
                markup
                )


def clash_with_bandit(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    first = Button('Вступить в схватку.')
    markup.add(first)

    send_text_r(message,
                f'Бабка: Ты, Алчек, всегда искал лёгкие пути! '
                )
    send_text(message,
              f'Разбойник (Алчек): Вот зачем ты кричишь. Я ведь просто попросил пару золотых!'
              )
    send_text(message,
              f'Бабка: И кинжал ты достал просто так?'
              )
    send_text(message,
              f'Бабка: Сейчас трудные времена, да. И ты решил, что тебе всё можно?'
              )
    send_text(message,
              f'Разбойник (Алчек): Слишком много вопросов, Преведа, мы хоть давно знакомы, но уж прости.'
              )
    send_text(message,
              f'Бабка (Преведа): Ну смотри, ты так легко не отделаешься!'
              )
    send_text(message,
              f'{name}: А ну отойди от неё, разбойник!'
              )
    send_text_m(message,
                f'Разбойник (Алчек): Я ТАК ЛЕГКО НЕ СДАМСЯ!',
                markup
                )


def teaching_fighting(message):
    id = message.from_user.id
    name = get_hero(id, "name")
    markup = Markup(resize_keyboard=True)
    first = Button('Кинуть кубик.')
    markup.add(first)

    send_text_r(message,
              italics(f'Смело, {name}. И что же ты теперь будешь делать?')
              )
    send_text(message,
              f'{name}: Я не знаю! Помоги мне, Рассказчик!!!'
              )
    text = bold('Благодаря ему, можно понять, на что ты способен за ход')
    send_text(message,
              italics(f'Тебе очень повезло, мой друг. У меня есть один кубик, показывающий потенциал того, '
                      f'кого я хочу. {text}.')
              )
    send_text(message,
              f'{name}: Ого! Но что это мне даёт?'
              )
    send_text(message,
              italics(f'Зная свой потенциал, ты можешь выжать максимум из своих действий!')
              )
    send_text_m(message,
              italics(f'Ты готов?'),
              markup
              )


# endregion
@bot.message_handler(content_types=['text'])
def main(message):
    text = message.text
    id = message.from_user.id
    stage = get_stage(id)
    # region fight
    if get_user(id, 'in_battle'):
        if text == 'Кинуть кубик.':
            roll_dice(message)
        elif text == 'Приёмы.':
            pass
        elif text == 'Магия.':
            # todo: сделать магию
            pass
        elif text == 'Проверить себя.':
            check_yourself(message)
        elif text == 'Проверить противника.':
            pass
        elif text == 'Открыть сумку c расходниками.':
            pass
        elif text == 'Закончить ход.':
            pass
    # endregion
    # region stage 1
    elif stage == 1:
        if text in [
                    'Кто ты?',
                    'Подожди, кто ты?'
                    ]:
            introduction_to_the_void(message)
        elif text in [
                    'Что за задача?',
                    'Ещё раз, что за задача?'
                    ]:
            find_out_the_goal_of_the_game(message)
        elif text == 'Я готов.':
            save_stage(id, 2)
            choice_hero_name(message)
    # endregion
    # region stage 2
    elif stage == 2:
        save_hero(userid=id, param='name', val=text)
        save_stage(id, 3)
        meet_the_hero(message)
    # endregion
    # region stage 3
    elif 3 <= stage < 4:
        if text == 'Узнать про пророчество.':
            save_stage(id, get_stage(id) + 0.5)
            listen_prophecy(message)
        elif text == 'Спросить как стать героем в лохмотьях.':
            save_stage(id, get_stage(id) + 0.5)
            find_how_to_be_a_hero(message)
    # endregion
    # region stage 4
    elif stage == 4:
        if text == 'Спросить ещё что-нибудь.':
            save_stage(id, 5)
            the_beginning_of_adventures(message)
    # endregion
    # region stage 5
    elif 5 <= stage < 6:
        if text == 'Спросить о дальнейшем пути.':
            save_stage(id, get_stage(id) + 0.5)
            ask_about_the_future_way(message)
        elif text == 'Разузнать о происхождении Рассказчика.':
            save_stage(id, get_stage(id) + 0.5)
            find_out_about_the_origin_of_the_Storyteller(message)
    # endregion
    # region stage 6
    elif stage == 6:
        if text == 'Осмотреться.':
            save_stage(id, 7)
            look_around_the_village(message)
    # endregion
    # region stage 7
    elif stage == 7:
        if text == 'Двигаться в сторону ворот.':
            save_stage(id, 8)
            situation_with_bandit(message)
    # endregion
    # region stage 8
    elif stage == 8:
        if text in ['Пойти и убедиться, что всё хорошо.', 'Вернуться и проверить, что всё хорошо.']:
            save_stage(id, 9)
            clash_with_bandit(message)
        elif text == 'Пройти мимо как ни в чём не бывало.':
            last_chance_clash_with_the_bandit(message)
        elif text == 'Идти дальше, не обращая внимание.':
            save_stage(id, 9)
            # todo: доделать
    # endregion
    # region stage 9
    elif stage == 9:
        if text == 'Вступить в схватку.':
            save_enemy(id, 'name', 'Разбойник (Алчек)')
            save_enemy(id, 'health', 20)
            save_enemy(id, 'defence', 0)
            save_user(id, 'in_battle', True)
            teaching_fighting(message)
    # endregion


bot.infinity_polling()
# задачи:
# todo: каждому персонажу прикрутить портрет
