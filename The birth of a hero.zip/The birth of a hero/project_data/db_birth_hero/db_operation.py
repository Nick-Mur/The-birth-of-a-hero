from datetime import datetime

from sqlalchemy.exc import IntegrityError

from project_data.db_birth_hero.data.users import User
from project_data.db_birth_hero.data.hero import Hero
from project_data.db_birth_hero.data.enemy import Enemy
from project_data.db_birth_hero.data.inventory_weapons import InventoryWeapons
from project_data.db_birth_hero.data.inventory_armors import InventoryArmors
from project_data.db_birth_hero.data.inventory_consumables import InventoryConsumables
from project_data.db_birth_hero.data.fight import Fight
from project_data.db_birth_hero.data.techniques import Techniques
from project_data.db_birth_hero.data.magic import Magic


"""
строение, id для предметов
разделение в id - "." (пример: 01.03 - 1 оружие, 3 подвид)
1) оружие:
    первые две цифры - само оружие
    вторые две - его подвид
    3 слота под оружия
    1 слот - активное оружие
2) броня:
    первые две цифры - сама броня
    вторые две - её подвид
    3 слота под броню
    1 слот - активная броня
3) приёмы:
    4 слота
    первые 2 слота - "выученные" приёмы (за события)
    вторые 2 - приёмы от оружия
    4 цифры под один приём
    первые 2 - вид
    вторые 2 - подвид
4) магия:
    4 слота
    все - "выученные" (за уровень) 
    4 цифры под одну магию
    первые 2 - вид
    вторые 2 - подвид
5) расходники:
    3 слота
    3 цифры
    1 цифра- вид (на хп, на + очки хода, и тд)
    вторые 2 - подвид
6) противники:
    1 слот 
    первые 2 цифры - сам монстр
    вторые 2 - хп
    третьи 2 - макс хп
    четвёртые 2 - защита
    пятые 2 - макс защита
    шестые, седьмые, восьмые 4 цифры - приёмы
    девятый блок - оружие
    десятый - броня
7) бой:
    последовательность атак: первая цифра - магия или приём (0 или 1), вторые две - вид, потом точка и тд
"""


# region reg_user
def db_reg_user(userid):
    try:
        from project_data.db_birth_hero.data import db_session
        db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
        user = User()
        user.userID = userid
        db_sess = db_session.create_session()
        db_sess.add(user)
        db_sess.commit()
        db_sess.close()
    except IntegrityError:
        pass


def insert_nickname_in_table(userid, nickname):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    hero_name = Hero(name=nickname)
    user.hero.append(hero_name)
    db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def edit_nickname_in_table(userid, nickname):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    user.created_date = datetime.now()
    user.hero[0].name = nickname
    db_sess.commit()
    db_sess.close()


def db_viewer_nickname(userid):
    """
    Для register_nickname
    """
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    if user.hero:
        db_sess.close()
        return False  # Если сработает - значит не регистрируем
    db_sess.close()
    return True


# endregion
# region save
def save_enemy(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.enemy:
        if param == 'id_enemy':
            user.enemy[0].id_enemy = val
        elif param == 'health':
            user.enemy[0].health = val
        elif param == 'defence':
            user.enemy[0].defence = val
    db_sess.commit()
    db_sess.close()


def save_fight(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.fight:
        if param == 'sequence':
            user.fight[0].sequence = val
        elif param == 'points':
            user.fight[0].points = val
        elif param == 'hero_move':
            user.fight[0].hero_move = val
        elif param == 'equipped_weapon':
            user.fight[0].equipped_weapon = val
        elif param == 'equipped_armor':
            user.fight[0].equipped_armor = val
    db_sess.commit()
    db_sess.close()


def save_hero(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.hero:
        if param == 'name':
            user.hero[0].name = val
        elif param == 'max_health':
            user.hero[0].max_health = val
        elif param == 'health':
            user.hero[0].health = val
        elif param == 'max_defence':
            user.hero[0].max_defence = val
        elif param == 'defence':
            user.hero[0].defence = val
        elif param == 'cash':
            user.hero[0].cash = val
    db_sess.commit()
    db_sess.close()


def save_inventory_armors(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.inventory_armors:
        if param == 'slot_1':
            user.inventory_armors[0].slot_1 = val
        elif param == 'slot_2':
            user.inventory_armors[0].slot_2 = val
        elif param == 'slot_3':
            user.inventory_armors[0].slot_3 = val
    db_sess.commit()
    db_sess.close()


def save_inventory_consumables(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.inventory_consumables:
        if param == 'slot_1':
            user.inventory_consumables[0].slot_1 = val
        elif param == 'slot_2':
            user.inventory_consumables[0].slot_2 = val
        elif param == 'slot_3':
            user.inventory_consumables[0].slot_3 = val
    db_sess.commit()
    db_sess.close()


def save_inventory_weapons(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.inventory_weapons:
        if param == 'slot_1':
            user.inventory_weapons[0].slot_1 = val
        elif param == 'slot_2':
            user.inventory_weapons[0].slot_2 = val
        elif param == 'slot_3':
            user.inventory_weapons[0].slot_3 = val
    db_sess.commit()
    db_sess.close()


def save_user(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if param == 'reputation':
        user.reputation = val
    elif param == 'magic_level':
        user.magic_level = val
    elif param == 'in_battle':
        user.in_battle = val
    elif param == 'in_inventory':
        user.in_inventory = val
    db_sess.commit()
    db_sess.close()


def save_stage(userid, val):
    """Сохраняет значение stage"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    user.stage = val
    db_sess.commit()
    db_sess.close()


def save_magic(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.magic:
        if param == 'slot_1':
            user.magic[0].slot_1 = val
        elif param == 'slot_2':
            user.magic[0].slot_2 = val
        elif param == 'slot_3':
            user.magic[0].slot_3 = val
        elif param == 'slot_4':
            user.magic[0].slot_4 = val
    db_sess.commit()
    db_sess.close()


def save_techniques(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.techniques:
        if param == 'slot_1':
            user.techniques[0].slot_1 = val
        elif param == 'slot_2':
            user.techniques[0].slot_2 = val
        elif param == 'slot_3':
            user.techniques[0].slot_3 = val
        elif param == 'slot_4':
            user.techniques[0].slot_4 = val
    db_sess.commit()
    db_sess.close()


# endregion
# region get
def get_enemy(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'id_enemy':
        result =  user.enemy[0].id_enemy
    elif param == 'health':
        result =  user.enemy[0].health
    elif param == 'defence':
        result =  user.enemy[0].defence
    db_sess.commit()
    db_sess.close()
    return result


def get_fight(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'sequence':
        result = user.fight[0].sequence
    elif param == 'points':
        result = user.fight[0].points
    elif param == 'hero_move':
        result = user.fight[0].hero_move
    elif param == 'equipped_weapon':
        result = user.fight[0].equipped_weapon
    elif param == 'equipped_armor':
        result = user.fight[0].equipped_armor
    db_sess.commit()
    db_sess.close()
    return result


def get_hero(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'max_health':
        result = user.hero[0].max_health
    elif param == 'health':
        result = user.hero[0].health
    elif param == 'max_defence':
        result = user.hero[0].max_defence
    elif param == 'defence':
        result = user.hero[0].defence
    elif param == 'cash':
        result = user.hero[0].cash
    elif param == 'name':
        result = user.hero[0].name
    db_sess.commit()
    db_sess.close()
    return result


def get_inventory_armors(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'slot_1':
        result = user.inventory_armors[0].slot_1
    elif param == 'slot_2':
        result = user.inventory_armors[0].slot_2
    elif param == 'slot_3':
        result = user.inventory_armors[0].slot_3
    db_sess.commit()
    db_sess.close()
    return result


def get_inventory_consumables(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'slot_1':
        result = user.inventory_consumables[0].slot_1
    elif param == 'slot_2':
        result = user.inventory_consumables[0].slot_2
    elif param == 'slot_3':
        result = user.inventory_consumables[0].slot_3
    db_sess.commit()
    db_sess.close()
    return result


def get_inventory_weapons(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'slot_1':
        result = user.inventory_weapons[0].slot_1
    elif param == 'slot_2':
        result = user.inventory_weapons[0].slot_2
    elif param == 'slot_3':
        result = user.inventory_weapons[0].slot_3
    db_sess.commit()
    db_sess.close()
    return result


def get_user(userid, param):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'reputation':
        result = user.reputation
    elif param == 'magic_level':
        result = user.magic_level
    elif param == 'in_battle':
        result = user.in_battle
    elif param == 'in_inventory':
        result = user.in_inventory
    db_sess.commit()
    db_sess.close()
    return result


def get_stage(userid):
    """Выводит значение stage"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    stage = user.stage
    db_sess.close()
    return stage


def get_techniques(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'slot_1':
        result = user.techniques[0].slot_1
    elif param == 'slot_2':
        result = user.techniques[0].slot_2
    elif param == 'slot_3':
        result = user.techniques[0].slot_3
    elif param == 'slot_4':
        result = user.techniques[0].slot_4
    db_sess.commit()
    db_sess.close()
    return result


def get_magic(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'slot_1':
        result = user.magic[0].slot_1
    elif param == 'slot_2':
        result = user.magic[0].slot_2
    elif param == 'slot_3':
        result = user.magic[0].slot_3
    elif param == 'slot_4':
        result = user.magic[0].slot_4
    db_sess.commit()
    db_sess.close()
    return result


# endregion
def create_all(userid):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()


    enemy = Enemy(
        id_enemy='0',
        health=0,
        defence=0
    )
    user.enemy.append(enemy)
    db_sess.add(user)


    hero = Hero(
        name='0',
        max_health=0,
        health=0,
        max_defence=0,
        defence=0,
        cash=10
    )
    user.hero.append(hero)
    db_sess.add(user)


    inventory_weapons = InventoryWeapons(
        slot_1='0',
        slot_2='0',
        slot_3='0'
    )
    user.inventory_weapons.append(inventory_weapons)
    db_sess.add(user)


    inventory_armors = InventoryArmors(
        slot_1='0',
        slot_2='0',
        slot_3='0'
    )
    user.inventory_armors.append(inventory_armors)
    db_sess.add(user)


    inventory_consumables = InventoryConsumables(
        slot_1='0',
        slot_2='0',
        slot_3='0'
    )
    user.inventory_consumables.append(inventory_consumables)
    db_sess.add(user)


    fight = Fight(
        sequence='0',
        points=0,
        hero_move=True,
        equipped_weapon='slot_1',
        equipped_armor='slot_1'
    )
    user.fight.append(fight)
    db_sess.add(user)


    magic = Magic(
        slot_1='0',
        slot_2='0',
        slot_3='0',
        slot_4='0'
    )
    user.magic.append(magic)
    db_sess.add(user)


    techniques = Techniques(
        slot_1='0',
        slot_2='0',
        slot_3='0',
        slot_4='0'
    )
    user.techniques.append(techniques)
    db_sess.add(user)


    db_sess.commit()
    db_sess.close()
