from datetime import datetime

from sqlalchemy.exc import IntegrityError

from project_data.db_birth_hero.data.users import User
from project_data.db_birth_hero.data.hero import Hero
from project_data.db_birth_hero.data.enemy import Enemy
from project_data.db_birth_hero.data.boss import Boss
from project_data.db_birth_hero.data.inventory_weapons import InventoryWeapons


"""
строение, id для предметов
разделение в id - "." (пример: 01.03 - 1 оружие, 3 подвид)
1) оружие:
    первые две цифры - само оружие
    вторые две - его подвид
    3 слота под оружия
    1 слот - активное оружие
2) броня:
    первые две цифры - сама броня
    вторые две - её подвид
    3 слота под броню
    1 слот - активная броня
3) приёмы:
    4 слота
    первые 2 слота - "выученные" приёмы (за события)
    вторые 2 - приёмы от оружия
    4 цифры под один приём
    первые 2 - вид
    вторые 2 - подвид
4) магия:
    4 слота
    все - "выученные" (за уровень) 
    4 цифры под одну магию
    первые 2 - вид
    вторые 2 - подвид
5) расходники:
    3 слота
    3 цифры
    1 цифра- вид (на хп, на + очки хода, и тд)
    вторые 2 - подвид
6) противники:
    1 слот 
    первые 2 цифры - сам монстр
    вторые 2 - хп
    третьи 2 - макс хп
    четвёртые 2 - защита
    пятые 2 - макс защита
    шестые, седьмые, восьмые 4 цифры - приёмы
    девятый блок - оружие
    десятый - броня
    
"""
def db_reg_user(userid):
    try:
        from project_data.db_birth_hero.data import db_session
        db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
        user = User()
        user.userID = userid
        db_sess = db_session.create_session()
        db_sess.add(user)
        db_sess.commit()
        db_sess.close()
    except IntegrityError:
        pass


def insert_nickname_in_table(userid, nickname):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    hero_name = Hero(name=nickname)
    user.hero.append(hero_name)
    db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def edit_nickname_in_table(userid, nickname):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    user.created_date = datetime.now()
    user.hero[0].name = nickname
    db_sess.commit()
    db_sess.close()


def db_viewer_nickname(userid):
    """
    Для register_nickname
    """
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    if user.hero:
        db_sess.close()
        return False  # Если сработает - значит не регистрируем
    db_sess.close()
    return True


def get_hero(userid):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    param = {
        'name': user.hero[0].name,
        'max_health': user.hero[0].max_health,
        'health': user.hero[0].health,
        'max_defence': user.hero[0].max_defence,
        'defence': user.hero[0].defence,
        'cash': user.hero[0].cash,
    }
    db_sess.close()
    return param


def save_hero(userid, max_health, health, max_defence, defence, cash):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    try:
        user.hero[0].max_health = max_health
        user.hero[0].health = health
        user.hero[0].max_defence = max_defence
        user.hero[0].defence = defence
        user.hero[0].cash = cash
    except:
        hero = Hero(
            max_health=max_health,
            health=health,
            max_defence=max_defence,
            defence=defence,
            cash=cash
        )
        user.hero.append(hero)
        db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def get_heroes_inventory(userid):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    param = {
        'consumables': user.hero[0].consumables,
        'weapon': user.hero[0].weapon,
        'armor': user.hero[0].armor,
    }
    db_sess.close()
    return param


def save_heroes_inventory(userid, consumables, weapon, armor):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    try:
        user.hero[0].consumables = consumables
        user.hero[0].weapon = weapon
        user.hero[0].armor = armor
    except:
        hero = Hero(
            consumables=consumables,
            weapon=weapon,
            armor=armor,
        )
        user.hero.append(hero)
        db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def get_enemy(userid):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    param = {
        'health': user.enemy[0].health,
        'defence': user.enemy[0].defence,
        'weapon': user.enemy[0].weapon,
        'armor': user.enemy[0].armor
    }
    db_sess.close()
    return param


def save_enemy(userid, health, defence, weapon, armor):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.enemy:
        user.enemy[0].health = health
        user.enemy[0].defence = defence
        user.enemy[0].weapon = weapon
        user.enemy[0].armor = armor
    else:
        enemy = Enemy(
            health=health,
            defence=defence,
            weapon=weapon,
            armor=armor
        )
        user.enemy.append(enemy)
        db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def get_boss(userid):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    param = {
        'defence': user.boss[0].defence,
        'health': user.boss[0].health,
        'status': user.boss[0].status,
        'action': user.boss[0].action
    }
    db_sess.close()
    return param


def save_boss(userid, health, status, action, defence):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.boss:
        user.boss[0].action = action
        user.boss[0].status = status
        user.boss[0].health = health
        user.boss[0].defence = defence
    else:
        boss = Boss(
            action=action,
            status=status,
            health=health,
            defence=defence
        )
        user.boss.append(boss)
        db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def save_one_hero(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if param == 'max_health':
        user.hero[0].max_health = val
    elif param == 'health':
        user.hero[0].health = val
    elif param == 'max_defence':
        user.hero[0].max_defence = val
    elif param == 'defence':
        user.hero[0].defence = val
    elif param == 'cash':
        user.hero[0].cash = val
    elif param == 'name':
        user.hero[0].name = val
    db_sess.commit()
    db_sess.close()


def get_one_hero(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'max_health':
        result = user.hero[0].max_health
    elif param == 'health':
        result = user.hero[0].health
    elif param == 'max_defence':
        result = user.hero[0].max_defence
    elif param == 'defence':
        result = user.hero[0].defence
    elif param == 'cash':
        result = user.hero[0].cash
    elif param == 'name':
        result = user.hero[0].name
    db_sess.commit()
    db_sess.close()
    return result


def get_stage(userid):
    """Выводит значение stage"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    stage = user.stage
    db_sess.close()
    return stage


def save_stage(userid, val):
    """Сохраняет значение stage"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    user.stage = val
    db_sess.commit()
    db_sess.close()


def get_merchant_inventory(userid):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    param = {
        'consumables': user.hero[0].consumables,
    }
    db_sess.close()
    return param


def save_merchant_inventory(userid, consumables):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    try:
        user.hero[0].consumables = consumables
    except:
        hero = Hero(
            consumables=consumables,
        )
        user.hero.append(hero)
        db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def save_user_parameter(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if param == 'reputation_point':
        user.reputation_point = val
    elif param == 'writers_point':
        user.writers_point = val
    elif param == 'magic_point':
        user.magic_point = val
    elif param == 'in_battle':
        user.in_battle = val
    elif param == 'in_inventory':
        user.in_inventory = val
    elif param == 'in_dialogue':
        user.in_dialogue = val
    db_sess.commit()
    db_sess.close()



def save_inventory_weapons(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.inventory_weapons:
        pass
    else:
        inventory_weapons = InventoryWeapons(
            slot_1=0,
            slot_2=0,
            slot_3=0,
        )
        user.inventory_weapons.append(inventory_weapons)
        db_sess.add(user)
    db_sess.commit()
    db_sess.close()

