from datetime import datetime

from sqlalchemy.exc import IntegrityError

from project_data.db_birth_hero.data.users import User
from project_data.db_birth_hero.data.hero import Hero
from project_data.db_birth_hero.data.enemy import Enemy
from project_data.db_birth_hero.data.inventory_weapons import InventoryWeapons
from project_data.db_birth_hero.data.inventory_armors import InventoryArmors
from project_data.db_birth_hero.data.inventory_consumables import InventoryConsumables
from project_data.db_birth_hero.data.fight import Fight
from project_data.db_birth_hero.data.techniques import Techniques
from project_data.db_birth_hero.data.magic import Magic
from project_data.db_birth_hero.data.players_saves import PlayersSaves

# region reg_user
def db_reg_user(userid):
    try:
        from project_data.db_birth_hero.data import db_session
        db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
        user = User()
        user.userID = userid
        db_sess = db_session.create_session()
        db_sess.add(user)
        db_sess.commit()
        db_sess.close()
    except IntegrityError:
        pass


def insert_nickname_in_table(userid, nickname):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    hero_name = Hero(name=nickname)
    user.hero.append(hero_name)
    db_sess.add(user)
    db_sess.commit()
    db_sess.close()


def edit_nickname_in_table(userid, nickname):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    user.created_date = datetime.now()
    user.hero[0].name = nickname
    db_sess.commit()
    db_sess.close()


def db_viewer_nickname(userid):
    """
    Для register_nickname
    """
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter(User.userID == userid).first()
    if user.hero:
        db_sess.close()
        return False  # Если сработает - значит не регистрируем
    db_sess.close()
    return True


# endregion
# region save
def save_enemy(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.enemy:
        if param == 'name':
            user.enemy[0].name = val
        elif param == 'health':
            user.enemy[0].health = val
        elif param == 'defence':
            user.enemy[0].defence = val
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()


def save_fight(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.fight:
        if param == 'self_sequence':
            user.fight[0].self_sequence = val
        elif param == 'enemy_sequence':
            user.fight[0].enemy_sequence = val
        elif param == 'self_points':
            user.fight[0].self_points = val
        elif param == 'enemy_points':
            user.fight[0].enemy_points = val
        elif param == 'self_armor_bonus':
            user.fight[0].self_armor_bonus = val
        elif param == 'enemy_armor_bonus':
            user.fight[0].enemy_armor_bonus = val
        elif param == 'roll_dice':
            user.fight[0].roll_dice = val
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()


def save_hero(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.hero:
        if param == 'name':
            user.hero[0].name = val
        elif param == 'max_health':
            user.hero[0].max_health = val
        elif param == 'health':
            user.hero[0].health = val
        elif param == 'max_defence':
            user.hero[0].max_defence = val
        elif param == 'defence':
            user.hero[0].defence = val
        elif param == 'cash':
            user.hero[0].cash = val
        elif param == 'equipped_weapon':
            user.hero[0].equipped_weapon = val
        elif param == 'equipped_armor':
            user.hero[0].equipped_armor = val
        elif param == 'magic_level':
            user.hero[0].magic_level = val
        elif param == 'battle_level':
            user.hero[0].battle_level = val
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()


def save_inventory_armors(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.inventory_armors:
        if param == 'slot_1':
            user.inventory_armors[0].slot_1 = val
        elif param == 'slot_2':
            user.inventory_armors[0].slot_2 = val
        elif param == 'slot_3':
            user.inventory_armors[0].slot_3 = val
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()


def save_inventory_consumables(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.inventory_consumables:
        if param == 'slot_1':
            user.inventory_consumables[0].slot_1 = val
        elif param == 'slot_2':
            user.inventory_consumables[0].slot_2 = val
        elif param == 'slot_3':
            user.inventory_consumables[0].slot_3 = val
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()


def save_inventory_weapons(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.inventory_weapons:
        if param == 'slot_1':
            user.inventory_weapons[0].slot_1 = val
        elif param == 'slot_2':
            user.inventory_weapons[0].slot_2 = val
        elif param == 'slot_3':
            user.inventory_weapons[0].slot_3 = val
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()


def save_user(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if param == 'reputation':
        user.reputation = val
    elif param == 'in_battle':
        user.in_battle = val
    elif param == 'in_inventory':
        user.in_inventory = val
    elif param == 'choices':
        user.choices = val
    db_sess.commit()
    db_sess.close()


def save_stage(userid, val):
    """Сохраняет значение stage"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    user.stage = val
    db_sess.commit()
    db_sess.close()


def save_magic(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.magic:
        if param == 'slot_1':
            user.magic[0].slot_1 = val
        elif param == 'slot_2':
            user.magic[0].slot_2 = val
        elif param == 'slot_3':
            user.magic[0].slot_3 = val
        elif param == 'slot_4':
            user.magic[0].slot_4 = val
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()


def save_techniques(userid, param, val):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.techniques:
        if param == 'slot_1':
            user.techniques[0].slot_1 = val
        elif param == 'slot_2':
            user.techniques[0].slot_2 = val
        elif param == 'slot_3':
            user.techniques[0].slot_3 = val
        elif param == 'slot_4':
            user.techniques[0].slot_4 = val
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()


def save_players_saves(userid, param, key_markup):
    """Сохраняет значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    if user.players_saves:
        save_date = str(datetime.now())[:16]

        enemy = f"{user.enemy[0].name},{user.enemy[0].health},{user.enemy[0].defence}"

        hero = f"{user.hero[0].name},{user.hero[0].max_health},{user.hero[0].health}," \
               f"{user.hero[0].max_defence},{user.hero[0].defence},{user.hero[0].cash}," \
               f"{user.hero[0].equipped_weapon},{user.hero[0].equipped_armor},{user.hero[0].battle_level},{user.hero[0].magic_level}"

        inv_arm = f'{user.inventory_armors[0].slot_1},{user.inventory_armors[0].slot_2},' \
                  f'{user.inventory_armors[0].slot_3}'

        inv_cons= f'{user.inventory_consumables[0].slot_1},{user.inventory_consumables[0].slot_2},' \
                  f'{user.inventory_consumables[0].slot_3}'

        inv_wps = f'{user.inventory_weapons[0].slot_1},{user.inventory_weapons[0].slot_2},' \
                  f'{user.inventory_weapons[0].slot_3}'

        magic = f'{user.magic[0].slot_1},{user.magic[0].slot_2},' \
                f'{user.magic[0].slot_3},{user.magic[0].slot_4}'

        techniques = f'{user.techniques[0].slot_1},{user.techniques[0].slot_2},' \
                f'{user.techniques[0].slot_3},{user.techniques[0].slot_4}'

        in_inventory = user.in_inventory
        if in_inventory is True:
            in_inventory = 1
        else:
            in_inventory = 0
        user_save = f"{user.reputation},{in_inventory},{user.stage},{user.choices}"

        val = f"{save_date}|{key_markup}|{enemy}|{hero}|{inv_arm}|{inv_cons}|{inv_wps}|{magic}|{techniques}|{user_save}"
        if param == 'slot_1':
            user.players_saves[0].slot_1 = val
        elif param == 'slot_2':
            user.players_saves[0].slot_2 = val
        elif param == 'slot_3':
            user.players_saves[0].slot_3 = val
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()


def start_over(userid):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()

    user.enemy[0].name = '—'
    user.enemy[0].health = 0
    user.enemy[0].defence = 0

    user.fight[0].self_sequence = ''
    user.fight[0].enemy_sequence = ''
    user.fight[0].self_points = 0
    user.fight[0].enemy_points = 0
    user.fight[0].self_armor_bonus = False
    user.fight[0].enemy_armor_bonus = False
    user.fight[0].roll_dice = False

    user.hero[0].name = ''
    user.hero[0].max_health = 60
    user.hero[0].health = 60
    user.hero[0].max_defence = 0
    user.hero[0].defence = 0
    user.hero[0].cash = 10
    user.hero[0].equipped_weapon = '—'
    user.hero[0].equipped_armor = '—'

    user.inventory_armors[0].slot_1 = '—'
    user.inventory_armors[0].slot_2 = '—'
    user.inventory_armors[0].slot_3 = '—'

    user.inventory_consumables[0].slot_1 = '—'
    user.inventory_consumables[0].slot_2 = '—'
    user.inventory_consumables[0].slot_3 = '—'

    user.inventory_weapons[0].slot_1 = '—'
    user.inventory_weapons[0].slot_2 = '—'
    user.inventory_weapons[0].slot_3 = '—'

    user.magic[0].slot_1 = '—'
    user.magic[0].slot_2 = '—'
    user.magic[0].slot_3 = '—'
    user.magic[0].slot_4 = '—'

    user.techniques[0].slot_1 = '—'
    user.techniques[0].slot_2 = '—'
    user.techniques[0].slot_3 = '—'
    user.techniques[0].slot_4 = '—'

    user.reputation = 0
    user.magic_level = 0
    user.in_battle = False
    user.in_inventory = False
    user.stage = 1
    user.choices = ''

    db_sess.commit()
    db_sess.close()


def save_new_weapon(userid, weapon):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()

    user.hero[0].equipped_weapon = weapon.name
    user.techniques[0].slot_1 = weapon.techniques[0].name
    user.techniques[0].slot_2 = weapon.techniques[1].name

    db_sess.commit()
    db_sess.close()

def save_new_armor(userid, armor):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()

    user.hero[0].equipped_armor = armor.name
    user.hero[0].defence = armor.defence
    user.hero[0].max_defence = armor.defence

    db_sess.commit()
    db_sess.close()

# endregion
# region get
def get_enemy(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if user.enemy:
        if param == 'name':
            result =  user.enemy[0].name
        elif param == 'health':
            result =  user.enemy[0].health
        elif param == 'defence':
            result =  user.enemy[0].defence
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()
    return result


def get_fight(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if user.fight:
        if param == 'self_sequence':
            result = user.fight[0].self_sequence
        elif param == 'enemy_sequence':
            result = user.fight[0].enemy_sequence
        elif param == 'self_points':
            result = user.fight[0].self_points
        elif param == 'enemy_points':
            result = user.fight[0].enemy_points
        elif param == 'self_armor_bonus':
            result = user.fight[0].self_armor_bonus
        elif param == 'enemy_armor_bonus':
            result = user.fight[0].enemy_armor_bonus
        elif param == 'roll_dice':
            result = user.fight[0].roll_dice
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()
    return result


def get_hero(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if user.hero:
        if param == 'max_health':
            result = user.hero[0].max_health
        elif param == 'health':
            result = user.hero[0].health
        elif param == 'max_defence':
            result = user.hero[0].max_defence
        elif param == 'defence':
            result = user.hero[0].defence
        elif param == 'cash':
            result = user.hero[0].cash
        elif param == 'name':
            result = user.hero[0].name
        elif param == 'equipped_weapon':
            result = user.hero[0].equipped_weapon
        elif param == 'equipped_armor':
            result = user.hero[0].equipped_armor
        elif param == 'magic_level':
            result = user.hero[0].magic_level
        elif param == 'battle_level':
            result = user.hero[0].battle_level
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()
    return result


def get_inventory_armors(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if user.inventory_armors:
        if param == 'slot_1':
            result = user.inventory_armors[0].slot_1
        elif param == 'slot_2':
            result = user.inventory_armors[0].slot_2
        elif param == 'slot_3':
            result = user.inventory_armors[0].slot_3
        elif param == 'all':
            result = [user.inventory_armors[0].slot_1, user.inventory_armors[0].slot_2,
                      user.inventory_armors[0].slot_3]
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()
    return result


def get_inventory_consumables(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if user.inventory_consumables:
        if param == 'slot_1':
            result = user.inventory_consumables[0].slot_1
        elif param == 'slot_2':
            result = user.inventory_consumables[0].slot_2
        elif param == 'slot_3':
            result = user.inventory_consumables[0].slot_3
        elif param == 'all':
            result = [user.inventory_consumables[0].slot_1, user.inventory_consumables[0].slot_2,
                      user.inventory_consumables[0].slot_3]
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()
    return result


def get_inventory_weapons(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if user.inventory_weapons:
        if param == 'slot_1':
            result = user.inventory_weapons[0].slot_1
        elif param == 'slot_2':
            result = user.inventory_weapons[0].slot_2
        elif param == 'slot_3':
            result = user.inventory_weapons[0].slot_3
        elif param == 'all':
            result = [user.inventory_weapons[0].slot_1, user.inventory_weapons[0].slot_2,
                      user.inventory_weapons[0].slot_3]
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()
    return result


def get_user(userid, param):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if param == 'reputation':
        result = user.reputation
    elif param == 'in_battle':
        result = user.in_battle
    elif param == 'in_inventory':
        result = user.in_inventory
    elif param == 'choices':
        result = user.in_inventory
    db_sess.commit()
    db_sess.close()
    return result


def get_stage(userid):
    """Выводит значение stage"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    stage = user.stage
    db_sess.close()
    return stage


def get_techniques(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if user.techniques:
        if param == 'slot_1':
            result = user.techniques[0].slot_1
        elif param == 'slot_2':
            result = user.techniques[0].slot_2
        elif param == 'slot_3':
            result = user.techniques[0].slot_3
        elif param == 'slot_4':
            result = user.techniques[0].slot_4
        elif param == 'all':
            result = [user.techniques[0].slot_1, user.techniques[0].slot_2,
                      user.techniques[0].slot_3, user.techniques[0].slot_4]
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()
    return result


def get_magic(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if user.magic:
        if param == 'slot_1':
            result = user.magic[0].slot_1
        elif param == 'slot_2':
            result = user.magic[0].slot_2
        elif param == 'slot_3':
            result = user.magic[0].slot_3
        elif param == 'slot_4':
            result = user.magic[0].slot_4
        elif param == 'all':
            result = [user.magic[0].slot_1, user.magic[0].slot_2,
                      user.magic[0].slot_3, user.magic[0].slot_4]
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()
    return result


def get_players_saves(userid, param):
    """Выводит значение блоков"""
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()
    result = ''
    if user.players_saves:
        if param == 'slot_1':
            result = user.players_saves[0].slot_1
        elif param == 'slot_2':
            result = user.players_saves[0].slot_2
        elif param == 'slot_3':
            result = user.players_saves[0].slot_3
        elif param == 'short_show':
            all_params = user.players_saves[0].slot_1
            if all_params != '—':
                time = all_params.split('|')[0]
                hero = all_params.split('|')[3].split(',')
                name = hero[0]
                max_health = hero[1]
                health = hero[2]
                battle_level = hero[-2]
                if int(hero[-1]) == 0:
                    magic_level = ''
                else:
                    magic_level = f"✨ Магический уровень: {hero[-1]}"

                first = f"🪨 Первая печать\n" \
                        f"\n🕓 {time}\n" \
                        f"🪧 Имя: {name}\n" \
                        f"❤️ Здоровье: {health} из {max_health}\n" \
                        f"⭐ боевой уровень: {battle_level}\n" \
                        f"{magic_level}"
            else:
                first = '🪨 Первая печать\n' \
                        '—'

            all_params = user.players_saves[0].slot_2
            if all_params != '—':
                time = all_params.split('|')[0]
                hero = all_params.split('|')[3].split(',')
                name = hero[0]
                max_health = hero[1]
                health = hero[2]
                battle_level = hero[-2]
                if int(hero[-1]) == 0:
                    magic_level = ''
                else:
                    magic_level = f"✨ Магический уровень: {hero[-1]}"

                second = f"🪨 Вторая печать\n" \
                         f"\n🕓 {time}\n" \
                         f"🪧 Имя: {name}\n" \
                         f"❤️ Здоровье: {health} из {max_health}\n" \
                         f"⭐ боевой уровень: {battle_level}\n" \
                         f"{magic_level}"
            else:
                second = '🪨 Вторая печать\n' \
                        '—'

            all_params = user.players_saves[0].slot_3
            if all_params != '—':
                time = all_params.split('|')[0]
                hero = all_params.split('|')[3].split(',')
                name = hero[0]
                max_health = hero[1]
                health = hero[2]
                battle_level = hero[-2]
                if int(hero[-1]) == 0:
                    magic_level = ''
                else:
                    magic_level = f"✨ Магический уровень: {hero[-1]}"

                third = f"🪨 Третья печать\n" \
                        f"\n 🕓{time}\n" \
                        f"🪧 Имя: {name}\n" \
                        f"❤️ Здоровье: {health} из {max_health}\n" \
                        f"⭐ боевой уровень: {battle_level}\n" \
                        f"{magic_level}"
            else:
                third = '🪨 Третья печать\n' \
                        '—'
            result = [first, second, third]
    else:
        create_all(userid)
    db_sess.commit()
    db_sess.close()
    return result


def use_seal(userid, param):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()

    save = get_players_saves(userid, param).split('|')
    if save == ['—']:
        return None

    enemy =  save[2].split(',')
    user.enemy[0].name = enemy[0]
    user.enemy[0].health = int(enemy[1])
    user.enemy[0].defence = int(enemy[2])

    hero = save[3].split(',')
    user.hero[0].name = hero[0]
    user.hero[0].max_health = int(hero[1])
    user.hero[0].health = int(hero[2])
    user.hero[0].max_defence = int(hero[3])
    user.hero[0].defence = int(hero[4])
    user.hero[0].cash = int(hero[5])
    user.hero[0].equipped_weapon = hero[6]
    user.hero[0].equipped_armor = hero[7]
    user.hero[0].battle_level = int(hero[8])
    user.hero[0].magic_level = int(hero[9])

    inv_arm = save[4].split(',')
    user.inventory_armors[0].slot_1 = inv_arm[0]
    user.inventory_armors[0].slot_2 = inv_arm[1]
    user.inventory_armors[0].slot_3 = inv_arm[2]

    inv_cns = save[5].split(',')
    user.inventory_consumables[0].slot_1 = inv_cns[0]
    user.inventory_consumables[0].slot_2 = inv_cns[1]
    user.inventory_consumables[0].slot_3 = inv_cns[2]

    inv_wpn = save[6].split(',')
    user.inventory_weapons[0].slot_1 = inv_wpn[0]
    user.inventory_weapons[0].slot_2 = inv_wpn[1]
    user.inventory_weapons[0].slot_3 = inv_wpn[2]

    magic = save[7].split(',')
    user.magic[0].slot_1 = magic[0]
    user.magic[0].slot_2 = magic[1]
    user.magic[0].slot_3 = magic[2]
    user.magic[0].slot_4 = magic[3]

    techniques = save[8].split(',')
    user.techniques[0].slot_1 = techniques[0]
    user.techniques[0].slot_2 = techniques[1]
    user.techniques[0].slot_3 = techniques[2]
    user.techniques[0].slot_4 = techniques[3]

    user_save = save[9].split(',')
    user.reputation = int(user_save[0])
    user.in_inventory = bool(user_save[1])
    user.stage = int(user_save[2])
    user.choices = user_save[3]

    db_sess.commit()
    db_sess.close()

    return get_players_saves(userid, param).split('|')[1]

def create_all(userid):
    from project_data.db_birth_hero.data import db_session
    db_session.global_init("project_data/db_birth_hero/db/data_birth_hero.db")
    db_sess = db_session.create_session()
    user = db_sess.query(User).filter_by(userID=userid).first()

    if not user.enemy:
        enemy = Enemy(
            name='—',
            health=0,
            defence=0
        )
        user.enemy.append(enemy)
        db_sess.add(user)

    if not user.hero:
        hero = Hero(
            name='',
            max_health=60,
            health=60,
            max_defence=0,
            defence=0,
            cash=10,
            equipped_weapon='—',
            equipped_armor='—',
            battle_level = 1,
            magic_level=0
        )
        user.hero.append(hero)
        db_sess.add(user)

    if not user.inventory_weapons:
        inventory_weapons = InventoryWeapons(
            slot_1='—',
            slot_2='—',
            slot_3='—'
        )
        user.inventory_weapons.append(inventory_weapons)
        db_sess.add(user)

    if not user.inventory_armors:
        inventory_armors = InventoryArmors(
            slot_1='—',
            slot_2='—',
            slot_3='—'
        )
        user.inventory_armors.append(inventory_armors)
        db_sess.add(user)

    if not user.inventory_consumables:
        inventory_consumables = InventoryConsumables(
            slot_1='—',
            slot_2='—',
            slot_3='—'
        )
        user.inventory_consumables.append(inventory_consumables)
        db_sess.add(user)

    if not user.fight:
        fight = Fight(
            self_sequence='',
            enemy_sequence = '',
            self_points=0,
            enemy_points=0,
            self_armor_bonus = False,
            enemy_armor_bonus=False,
            roll_dice=False
        )
        user.fight.append(fight)
        db_sess.add(user)

    if not user.magic:
        magic = Magic(
            slot_1='—',
            slot_2='—',
            slot_3='—',
            slot_4='—'
        )
        user.magic.append(magic)
        db_sess.add(user)

    if not user.techniques:
        techniques = Techniques(
            slot_1='—',
            slot_2='—',
            slot_3='—',
            slot_4='—'
        )
        user.techniques.append(techniques)
        db_sess.add(user)


    if not user.players_saves:
        players_saves = PlayersSaves(
            slot_1='—',
            slot_2='—',
            slot_3='—'
        )
        user.players_saves.append(players_saves)
        db_sess.add(user)


    db_sess.commit()
    db_sess.close()
# endregion