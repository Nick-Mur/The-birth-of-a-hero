import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Merchant_inventory(SqlAlchemyBase):
    __tablename__ = 'merchant_inventory'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    consumables = sqlalchemy.Column(sqlalchemy.String)

    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="merchant_inventory")

    def __repr__(self):
        return '<Merchant_inventory %r>' % self.id