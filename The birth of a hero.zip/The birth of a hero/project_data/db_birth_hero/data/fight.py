import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Fight(SqlAlchemyBase):
    __tablename__ = 'fight'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    sequence = sqlalchemy.Column(sqlalchemy.String)
    points = sqlalchemy.Column(sqlalchemy.Integer)
    hero_move = sqlalchemy.Column(sqlalchemy.Boolean)
    equipped_weapon = sqlalchemy.Column(sqlalchemy.String)
    equipped_armor = sqlalchemy.Column(sqlalchemy.String)

    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="fight")

    def __repr__(self):
        return '<Fight %r>' % self.id
