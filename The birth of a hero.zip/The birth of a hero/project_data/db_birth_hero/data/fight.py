import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Fight(SqlAlchemyBase):
    __tablename__ = 'fight'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    self_sequence = sqlalchemy.Column(sqlalchemy.String, default='')
    enemy_sequence = sqlalchemy.Column(sqlalchemy.String, default='')
    self_points = sqlalchemy.Column(sqlalchemy.Integer, default=0)
    enemy_points = sqlalchemy.Column(sqlalchemy.Integer, default=0)
    self_armor_bonus = sqlalchemy.Column(sqlalchemy.Boolean, default=False)
    enemy_armor_bonus = sqlalchemy.Column(sqlalchemy.Boolean, default=False)
    hero_move = sqlalchemy.Column(sqlalchemy.Boolean, default=True)

    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="fight")

    def __repr__(self):
        return '<Fight %r>' % self.id
