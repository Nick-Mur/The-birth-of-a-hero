import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Hero(SqlAlchemyBase):
    __tablename__ = 'hero'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, default='—')
    max_health = sqlalchemy.Column(sqlalchemy.Integer, default=25)
    health = sqlalchemy.Column(sqlalchemy.Integer, default=25)
    max_defence = sqlalchemy.Column(sqlalchemy.Integer, default=0)
    defence = sqlalchemy.Column(sqlalchemy.Integer, default=0)
    cash = sqlalchemy.Column(sqlalchemy.Integer, default=10)
    equipped_weapon = sqlalchemy.Column(sqlalchemy.String, default='—')
    equipped_armor = sqlalchemy.Column(sqlalchemy.String, default='—')

    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="hero")

    def __repr__(self):
        return '<Hero %r>' % self.id