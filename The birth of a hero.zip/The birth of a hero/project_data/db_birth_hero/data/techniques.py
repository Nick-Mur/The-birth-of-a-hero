import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Techniques(SqlAlchemyBase):
    __tablename__ = 'techniques'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    slot_1 = sqlalchemy.Column(sqlalchemy.String)
    slot_2 = sqlalchemy.Column(sqlalchemy.String)
    slot_3 = sqlalchemy.Column(sqlalchemy.String)
    slot_4 = sqlalchemy.Column(sqlalchemy.String)
    slot_5 = sqlalchemy.Column(sqlalchemy.String)
    slot_6 = sqlalchemy.Column(sqlalchemy.String)

    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="techniques")

    def __repr__(self):
        return '<Techniques %r>' % self.id
