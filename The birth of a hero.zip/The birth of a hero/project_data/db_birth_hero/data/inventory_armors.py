import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class InventoryArmors(SqlAlchemyBase):
    __tablename__ = 'inventory_armors'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    slot_1 = sqlalchemy.Column(sqlalchemy.String, default='—')
    slot_2 = sqlalchemy.Column(sqlalchemy.String, default='—')
    slot_3 = sqlalchemy.Column(sqlalchemy.String, default='—')


    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="inventory_armors")

    def __repr__(self):
        return '<InventoryArmors %r>' % self.id
