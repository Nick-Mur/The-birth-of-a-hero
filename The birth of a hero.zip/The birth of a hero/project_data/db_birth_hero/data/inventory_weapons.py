import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class InventoryWeapons(SqlAlchemyBase):
    __tablename__ = 'inventory_weapons'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    slot_1 = sqlalchemy.Column(sqlalchemy.String)
    slot_2 = sqlalchemy.Column(sqlalchemy.String)
    slot_3 = sqlalchemy.Column(sqlalchemy.String)


    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="inventory_weapons")

    def __repr__(self):
        return '<InventoryWeapons %r>' % self.id