import requests

bot_token = '6341783038:AAE3WWKJgzRqbJ-rywlJ7-b_pVmHY1d9Etw'
MAIN_URL = f'https://api.telegram.org/bot{bot_token}'

r = requests.get(f'{MAIN_URL}/getMe').json()
# print(r)

bot_name = r['result']['first_name']
chat_id = r['result']['id']
