from random import randint


class Techniques:
    def __init__(self, name, cost, chance, type, description, mechanics):
        self.name = name
        self.cost = cost
        self.chance = chance
        self.type = type
        self.description = description
        self.mechanics = mechanics

    def info(self):
        text = f'Название: {self.name}\n' \
               f'Стоимость: {self.cost}\n' \
               f'Шанс срабатывания: {self.chance}\n' \
               f'Тип: {self.type}' \
               f'Описание: {self.description}\n' \
               f'Механика: {self.mechanics}'
        return text

    def points(self, points):
        points -= self.cost
        return points

    @staticmethod
    def new_sequence(self_id, sequence):
        return sequence + '.' + self_id.split('.')[0]

class SwingAndPunch1(Techniques):
     def use(self, min_damage, max_damage):
        if self.chance > randint(1, 100):
            return randint(min_damage, max_damage)
        else:
            return 0


class SwingAndPunch2(Techniques):
     def use(self, min_damage, max_damage):
        if self.chance > randint(1, 100):
            return randint(min_damage, max_damage) * 2
        else:
            return 0

class DefencePosture1(Techniques):
    def use(self, min_damage, max_damage):
        if self.chance > randint(1, 100):
            return randint(min_damage, max_damage)
        else:
            return 0


class DefencePosture2(Techniques):
    @staticmethod
    def points():
        points = 0
        return points

    @staticmethod
    def use(min_damage, max_damage):
        return randint(min_damage, max_damage) * 2


class StrictPunch(Techniques):
    @staticmethod
    def use(min_damage, max_damage):
        return (min_damage + max_damage) // 2


class ComboPunch(Techniques):
    def use(self, min_damage, max_damage):
        if self.chance > randint(1, 100):
            return randint(min_damage, max_damage) + randint(min_damage, max_damage)\
                + randint(min_damage, max_damage) + randint(min_damage, max_damage)
        else:
            return 0

class Lunge(Techniques):
    def use(self, min_damage, max_damage):
        if self.chance > randint(1, 100):
            return randint(min_damage, max_damage) * 3
        else:
            return 0

swing_and_punch1 = SwingAndPunch1(name='Размах и удар', cost=1, chance=75, type='атака', description=
'Главное хорошенько размахнуться, а дальше всё само будет.', mechanics=
'Надёжный хороший удар, бьёт с определённым шансом по врагу с уроном оружия.')
swing_and_punch2 = SwingAndPunch1(name='Размах и удар', cost=2, chance=90, type='атака', description=
'Главное хорошенько размахнуться, а дальше всё само будет.', mechanics=
'Надёжный хороший удар, бьёт с определённым шансом по врагу с уроном оружия.')
# шпиль
defence_posture1 = DefencePosture1(name='Защитная стойка', cost=2, chance=50, type='защита', description=
'Хоть на шпиль нам лезть не нужно, но я всё равно был бы готов ко всякому.', mechanics=
'Переводит твой урон в защиту.')
defence_posture2 = DefencePosture1(name='Защитная стойка', cost=3, chance=80, type='защита', description=
'Хоть на шпиль нам лезть не нужно, но я всё равно был бы готов ко всякому.', mechanics=
'Переводит твой урон в защиту.')
strict_punch1 = StrictPunch(name='Строгий удар', cost=2, chance=100, type='атака', description=
'Прямой удар, от которого не увернуться.', mechanics=
'Всегда бьёт со 100% шансом со средним арифметическим уроном твоего оружия.')
combo_punch1 = ComboPunch(name='Комбо-удар', cost=1, chance=20, type='атака', description=
'Молниеносная серия атак, не оставляющая шанса врагу.', mechanics=
'С малым шансом ты можешь ударить врага 4 раза за атаку.')
lunge1 = Lunge(name='Выпад', cost=3, chance=80, type='атака', description=
'Мощный, быстрый, скрытный удар, валящий наповал.', mechanics=
'Удар невероятной силы, наносящий x3 урона.')
techniques = {'01.01': swing_and_punch1, '01.02': swing_and_punch2,
              '02.01': defence_posture1, '02.02': defence_posture2,
              '03.01': strict_punch1,
              '04.01': combo_punch1,
              '05.01': lunge1}
decode_techniques_types = {'01': 'атака',
                           '02': 'защита',
                           '03': 'атака',
                           '04': 'атака',
                           '05': 'атака'}