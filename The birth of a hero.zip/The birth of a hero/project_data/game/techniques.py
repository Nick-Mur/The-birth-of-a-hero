from random import randint


class Techniques:
    def __init__(self, name, cost, chance, description, mechanics):
        self.name = name
        self.cost = cost
        self.chance = chance
        self.description = description
        self.mechanics = mechanics


    def info(self):
        text = '+=={:::::::::::::::::> |TECHNIQUE|\n' \
               '- - - - - - - - - - - - - - - - - - - - - -' \
               f'\n🪧 Название: {self.name}\n' \
               f'\n🫰 Стоимость: {self.cost} о.п.\n' \
               f'✨ Механика: {self.mechanics}\n' \
               f'\n📜 Описание: {self.description}\n' \
               f'- - - - - - - - - - - - - - - - - - - - - -'
        return text

    def points(self, points):
        points -= self.cost
        return points

    @staticmethod
    def new_sequence(self_id, sequence):
        return sequence + '.' + self_id.split('.')[0]

class SwingAndPunch(Techniques):
     def use(self, min_damage, max_damage):
        if self.chance > randint(1, 100):
            return randint(min_damage, max_damage)
        else:
            return 0

class DefencePosture(Techniques):
    def use(self, min_damage, max_damage):
        if self.chance > randint(1, 100):
            return randint(min_damage, max_damage)
        else:
            return 0


class StrictPunch(Techniques):
    @staticmethod
    def use(min_damage, max_damage):
        return (min_damage + max_damage) // 2


class ComboPunch(Techniques):
    def use(self, min_damage, max_damage):
        if self.chance > randint(1, 100):
            return randint(min_damage, max_damage) + randint(min_damage, max_damage)\
                + randint(min_damage, max_damage) + randint(min_damage, max_damage)
        else:
            return 0

class Lunge(Techniques):
    def use(self, min_damage, max_damage):
        if self.chance > randint(1, 100):
            return randint(min_damage, max_damage) * 3
        else:
            return 0

swing_and_punch = SwingAndPunch(name='Размах и удар', cost=2, chance=90, description=
'Главное хорошенько размахнуться, а дальше всё само будет, главное не промахнуться.', mechanics=
'Надёжный хороший удар без каких-то особенностей.')
defence_posture = DefencePosture(name='Защитная стойка', cost=1, chance=50, description=
'Лучшая защита - это нападение, но при этом не хочется получать по лицу.', mechanics=
'Переводит твой урон в защиту.')
strict_punch = StrictPunch(name='Строгий удар', cost=2, chance=100, description=
'Прямой удар, от которого не увернуться.', mechanics=
'Всегда бьёт со 100% шансом со средним арифметическим уроном твоего оружия.')
combo_punch = ComboPunch(name='Комбо-удар', cost=1, chance=20, description=
'Молниеносная серия атак, не оставляющая шанса врагу.', mechanics=
'С малым шансом ты можешь ударить врага 4 раза за атаку.')
lunge = Lunge(name='Выпад', cost=3, chance=80, description=
'Мощный, быстрый, скрытный удар, валящий наповал.', mechanics=
'Удар невероятной силы, наносящий x3 урона.')
techniques_name_to_object = {'Размах и удар': swing_and_punch,
                             'Защитная стойка': defence_posture}

# todo: убрать шанс удара