from techniques import *
from weapons_new import *
from armors_new import *


class Character:
    def __init__(self, name, health, techniques, weapon, armor, description):
        self.name = name
        self.health = health
        self.techniques = techniques
        self.weapon = weapon
        self.armor = armor
        self.description = description

    def info(self, health):
        text = f'Имя: {self.name}\n' \
               f'Здоровье: {health} из {self.health}\n' \
               f'Оружие: {self.weapon.name}\n' \
               f'Броня: {self.armor.name}' \
               f'Описание: {self.description}\n'
        return text

    def check_techniques(self):
        text = list()
        for i in self.techniques(): text.append(i.info())
        return text

    def check_weapon(self):
        return self.weapon.info()

    def check_armor(self):
        return self.armor.info()

    def check_armor_special(self):
        text = list()
        for i in self.armor.special: text.append(i.info())
        return text


rogue1 = Character(name='Разбойник (Алчек)', health=30, techniques=[strict_punch1, combo_punch1], weapon=dagger1,
                   armor=cloak1, description=
'Старый друг Преведы. Они были знакомы ещё с детства. Алчность и зависть погубили его,'
' заставив отступиться от своих принципов. А раньше он мечтал о судьбе героя, защитника слабых, о судьбе "Робен Гуда".')


enemies = {'01.01': rogue1}
