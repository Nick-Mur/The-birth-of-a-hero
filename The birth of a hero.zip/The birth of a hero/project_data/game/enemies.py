from project_data.game.weapons_new import *
from project_data.game.armors_new import *
from project_data.game.techniques import *
from project_data.db_birth_hero.db_operation import *

from random import choice, randint


class Hero:
    def __init__(self, description):
        self.description = description
        self.class_name = 'Hero'


    def info(self, id, full=True):
        if full:
            text = '+=={:::::::::::::::::> |HERO|\n' \
                   '- - - - - - - - - - - - - - - - - - - - - -' \
                   f'\n🪧 Имя: {get_hero(id, "name")}\n' \
                   f'\n❤️ Здоровье: {get_hero(id, "health")} из {get_hero(id, "max_health")}\n' \
                   f'🛡️ Защита: {get_hero(id, "defence")} из {get_hero(id, "max_defence")}\n' \
                   f'🗡️ Используемое оружие: {get_hero(id, "equipped_weapon")}\n' \
                   f'🥋 Используемая броня: {get_hero(id, "equipped_armor")}\n' \
                   f'\n📜 Описание: {self.description}\n' \
                   f'- - - - - - - - - - - - - - - - - - - - - -'
        else:
            weapon = weapons_name_to_object[get_hero(id, "equipped_weapon")]
            text = '+=={:::::::::::::::::> |HERO|\n' \
                   '- - - - - - - - - - - - - - - - - - - - - -' \
                   f'\n🪧 Имя: {get_hero(id, "name")}\n' \
                   f'\n❤️ Здоровье: {get_hero(id, "health")} из {get_hero(id, "max_health")}\n' \
                   f'🛡️ Защита: {get_hero(id, "defence")} из {get_hero(id, "max_defence")}\n' \
                   f'🩸 Урон: {weapon.damage}\n' \
                   f'🔥 Потенциал: {str(get_fight(id, "self_points"))} о.п.\n' \
                   f'- - - - - - - - - - - - - - - - - - - - - -'
        return text

    def __str__(self):
        return 'Hero'

class Character:
    def __init__(self, name, health, techniques, weapon, armor, description, phrases):
        self.name = name
        self.health = health
        self.techniques = techniques
        self.weapon = weapon
        self.armor = armor
        self.description = description
        self.class_name = 'Enemy'
        self.phrases = phrases


    def info(self, id, full=True):
        if full:
            text = '+=={:::::::::::::::::> |ENEMY|\n' \
                   '- - - - - - - - - - - - - - - - - - - - - -' \
                   f'\n🪧 Имя: {self.name}\n' \
                   f'\n❤️ Здоровье: {get_enemy(id, "health")} из {self.health}\n' \
                   f'🛡️ Защита: {get_enemy(id, "defence")} из {self.armor.defence}\n' \
                   f'🗡️ Используемое оружие: {self.weapon.name}\n' \
                   f'🥋 Используемая броня: {self.armor.name}\n' \
                   f'\n📜 Описание: {self.description}\n' \
                   f'- - - - - - - - - - - - - - - - - - - - - -'
        else:
            text = '+=={:::::::::::::::::> |ENEMY|\n' \
                   '- - - - - - - - - - - - - - - - - - - - - -' \
                   f'\n🪧 Имя: {self.name}\n' \
                   f'\n❤️ Здоровье: {get_enemy(id, "health")} из {self.health}\n' \
                   f'🛡️ Защита: {get_enemy(id, "defence")} из {self.armor.defence}\n' \
                   f'🩸 Урон: {self.weapon.damage}\n' \
                   f'- - - - - - - - - - - - - - - - - - - - - -'
        return text


    def check_techniques(self):
        text = list()
        for i in self.techniques(): text.append(i.info())
        return text

    def check_weapon(self):
        return self.weapon.info()

    def check_armor(self):
        return self.armor.info()

    def check_armor_special(self):
        text = list()
        for i in self.armor.special: text.append(i.info())
        return text


class Rogue(Character):
    def attack(self, id, plot=None):
        points = get_fight(id, 'enemy_points')
        text = plot
        patterns = choice([1, 2])
        if points == 1:
            text.append(bold(f'{self.name} пропустил ход'))
            text += (self.armor.special.check(id=id, subject=rogue))
            return text
        elif points == 2:
            if patterns == 1:
                text += (self.weapon.techniques[0].use(subject=rogue, damage=self.weapon.damage, id=id))
                text += (self.weapon.techniques[1].use(subject=rogue, damage=self.weapon.damage, id=id))
            else:
                text.append(bold(f'{self.name} пропустил ход'))
                text += (self.armor.special.check(id=id, subject=rogue))
                return text
        elif points == 3:
            if patterns == 1:
                text += (self.weapon.techniques[0].use(subject=rogue, damage=self.weapon.damage, id=id))
                text += (self.weapon.techniques[1].use(subject=rogue, damage=self.weapon.damage, id=id))
            else:
                text += (self.techniques[0].use(subject=rogue, damage=self.weapon.damage, id=id))
        elif points == 4:
            if patterns == 1:
                text += (self.weapon.techniques[0].use(subject=rogue, damage=self.weapon.damage, id=id))
                text += (self.weapon.techniques[1].use(subject=rogue, damage=self.weapon.damage, id=id))
            else:
                text += (self.techniques[0].use(subject=rogue, damage=self.weapon.damage, id=id))
                text += (self.weapon.techniques[1].use(subject=rogue, damage=self.weapon.damage, id=id))
        elif points == 5:
            if patterns == 1:
                text += (self.weapon.techniques[0].use(subject=rogue, damage=self.weapon.damage, id=id))
                text += (self.weapon.techniques[1].use(subject=rogue, damage=self.weapon.damage, id=id))
            else:
                text += (self.techniques[0].use(subject=rogue, damage=self.weapon.damage, id=id))
                text += (self.weapon.techniques[1].use(subject=rogue, damage=self.weapon.damage, id=id))
                text += (self.weapon.techniques[1].use(subject=rogue, damage=self.weapon.damage, id=id))
        elif points == 6:
            if patterns == 1:
                text += (self.weapon.techniques[0].use(subject=rogue, damage=self.weapon.damage, id=id))
                text += (self.weapon.techniques[1].use(subject=rogue, damage=self.weapon.damage, id=id))
            else:
                text += (self.techniques[0].use(subject=rogue, damage=self.weapon.damage, id=id))
                text += (self.techniques[0].use(subject=rogue, damage=self.weapon.damage, id=id))
        text.append(choice(self.phrases))
        special = (self.armor.special.check(id=id, subject=rogue))
        if special:
            text += special

        return text

hero = Hero(description='Молодой крестьянин с большими мечтами, неожиданно для себя ставший на путь героя.')


rogue = Rogue(name='Разбойник (Алчек)', health=35, techniques=[sneak_attack], weapon=dagger, armor=mothwing_cloak, description=
'Старый друг Преведы. Они были знакомы ещё с детства. Алчность и зависть погубили его,'
' заставив отступиться от своих принципов. А раньше он мечтал о судьбе героя, защитника слабых, о жизни "Робин Гуда".',
phrases=['Разбойник (Алчек): Я не окажусь снова в нищете!', 'Разбойник (Алчек): Вы все лишь скрываетесь за блеском ваших доспехов!',
         'Разбойник (Алчек): Я не сдамся!'])


enemies_name_to_object = {'Разбойник (Алчек)': rogue}
