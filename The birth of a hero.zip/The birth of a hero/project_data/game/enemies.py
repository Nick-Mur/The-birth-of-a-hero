from project_data.game.weapons_new import *
from project_data.game.armors_new import *
from project_data.game.techniques import *


from random import choice


class Character:
    def __init__(self, name, health, techniques_, weapon, armor, description):
        self.name = name
        self.health = health
        self.techniques_ = techniques_
        self.weapon = weapon
        self.armor = armor
        self.description = description

    def info(self, health):
        text = f'Имя: {self.name}\n' \
               f'Здоровье: {health} из {self.health}\n' \
               f'Оружие: {self.weapon.name}\n' \
               f'Броня: {self.armor.name}' \
               f'Описание: {self.description}\n'
        return text

    def check_techniques(self):
        text = list()
        for i in self.techniques_(): text.append(i.info())
        return text

    def check_weapon(self):
        return self.weapon.info()

    def check_armor(self):
        return self.armor.info()

    def check_armor_special(self):
        text = list()
        for i in self.armor.special: text.append(i.info())
        return text


class Rogue1(Character):
    def attack(self, points):
        patterns = choice([1, 2, 3])
        if points == 6:
            if patterns == 1:
                pass


rogue1 = Rogue1(name='Разбойник (Алчек)', health=30, techniques_=[combo_punch], weapon=dagger,
                   armor=cloak, description=
'Старый друг Преведы. Они были знакомы ещё с детства. Алчность и зависть погубили его,'
' заставив отступиться от своих принципов. А раньше он мечтал о судьбе героя, защитника слабых, о судьбе "Робен Гуда".')


enemies = {'01.01': rogue1}
