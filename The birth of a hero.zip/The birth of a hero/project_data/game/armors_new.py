from specials import *


from random import choice
class Armor:
    def __init__(self, name, defence, special, description):
        self.name = name
        self.defence = defence
        self.special = special
        self.description = description

    def info(self):
        text = f'Название: {self.name}\n' \
               f'Защита: {self.special}\n' \
               f'Особенность:\n'
        for i in self.special:
            text += f'  {i.name}\n'
        text += f'Описание: {self.description}\n'
        return text


shining_armour1 = Armor(name='Сияющие доспехи', defence=5, special=[valiant_warrior2], description=
'Прекрасные сияющие доспехи, они сами появились на тебе, благодаря воле небес. Правда, всё равно до конца не понятно,'
' куда делась старая одежда...')
shining_armour2 = Armor(name='Сияющие доспехи', defence=10, special=choice([valiant_warrior1, valiant_warrior2]),
                        description=
'Прекрасные сияющие доспехи, они сами появились на тебе, благодаря воле небес. Правда, всё равно до конца не понятно,'
' куда делась старая одежда...')
shining_armour3 = Armor(name='Сияющие доспехи', defence=15, special=[valiant_warrior1], description=
'Прекрасные сияющие доспехи, они сами появились на тебе, благодаря воле небес. Правда, всё равно до конца не понятно,'
' куда делась старая одежда...')
cloak1 = Armor(name='Накидка мотылька', defence=0, special=[adventurous_spirit1], description=
'В ней ты можешь представить себя рыцарем без рыцаря')
armors = {'01.01': shining_armour1, '01.02': shining_armour2, '01.03': shining_armour3,
          '02.01': cloak1}
