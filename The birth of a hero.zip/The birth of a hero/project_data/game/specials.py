from techniques import decode_techniques_types


from random import randint


class Special:
    def __init__(self, name, bonus, description, mechanics, type):
        self.name = name
        self.bonus = bonus
        self.description = description
        self.mechanics = mechanics
        self.type = type

    def info(self):
        text = f'Название: {self.name}\n' \
               f'Описание: {self.description}\n' \
               f'Механика: {self.mechanics}'
        return text


class ValiantWarrior1(Special):
    def check(self, sequence, total):
        if decode_techniques_types[sequence.split('.')[-1]] == 'атака':
            return int(total * self.bonus)


class ValiantWarrior2(Special):
    def check(self, sequence, total):
        if decode_techniques_types[sequence.split('.')[-1]] == 'защита':
            return int(total * self.bonus)


class AdventurousSpirit(Special):
    def check(self, sequence, min_damage, max_damage):
        count = 0
        for el in decode_techniques_types[sequence.split('.')]:
            if el == 'защита': count += 1
        if count > 1:
            return int(randint(min_damage, max_damage) * self.bonus)


valiant_warrior1 = ValiantWarrior1(name='Доблестный воин', bonus=0.25, description=
'Для героя нет ничего невозможного, если он сделал всё, что мог, он всё равно на этом не остановится.', mechanics=
'Если на твоём ходе последнее действие - атака, то ты ударишь на ещё четверть от суммарного урона за ход.',
                                   type='вся атака')
valiant_warrior2 = ValiantWarrior2(name='Доблестный воин', bonus=0.25, description=
'Для героя нет ничего невозможного, если он сделал всё, что мог, он всё равно на этом не остановится.', mechanics=
'Если на твоём ходе последнее действие - защита, то ты защитишься на ещё четверть от суммарной защиты за ход.',
                                   type='вся защита')
adventurous_spirit1 = AdventurousSpirit(name='Дух авантюризма', bonus=1, description=
'Кому нужна защита и без неё хорошо.', mechanics=
'Если у тебя больше 2 атак за ход, после завершения хода ты ударишь ещё раз',
                                   type='урон')
