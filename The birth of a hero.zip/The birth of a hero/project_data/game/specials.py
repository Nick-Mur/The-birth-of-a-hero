from project_data.db_birth_hero.db_operation import *


class Special:
    def __init__(self, name, description, mechanics):
        self.name = name
        self.description = description
        self.mechanics = mechanics

    def info(self, description):
        if description:
            text = '+=={:::::::::::::::::> |SPECIAL|\n' \
                   '- - - - - - - - - - - - - - - - - - - - - -' \
                   f'\n🪧 Название: {self.name}\n' \
                   f'\n✨ Механика: {self.mechanics}\n' \
                   f'\n📜 Описание: {self.description}\n' \
                   f'- - - - - - - - - - - - - - - - - - - - - -'
        else:
            text = '+=={:::::::::::::::::> |SPECIAL|\n' \
                   '- - - - - - - - - - - - - - - - - - - - - -' \
                   f'\n🪧 Название: {self.name}\n' \
                   f'\n✨ Механика: {self.mechanics}\n' \
                   f'- - - - - - - - - - - - - - - - - - - - - -'
        return text

class Prudence(Special):
    @staticmethod
    def check(id):
        save_fight(id, 'sequence', '')
        save_fight(id, 'hero_move', False)


    @staticmethod
    def bonus():
        pass


class Adventurism(Special):
    @staticmethod
    def check(id):
        if get_fight(id, 'sequence') == '':
            save_fight(id, 'armor_bonus', True)
        save_fight(id, 'points', 0)
        save_fight(id, 'sequence', '')
        save_fight(id, 'hero_move', False)


    @staticmethod
    def bonus(id):
        save_fight(id, 'points', 6)
        save_fight(id, 'armor_bonus', False)


prudence = Prudence(
name='Благоразумие',
description='Герой знает: для победы не обязательно тратить все силы за раз.',
mechanics='Твои очки действия не сгорают в конце хода.')

adventurism = Adventurism(
name='Авантюризм',
description='Кто не рискует, тот не пьёт шампанского!',
mechanics='Если за ход ты не использовал ни одну технику, на следующем ходу у тебя будет 6 очков действия.')

specials_name_to_object = {'Благоразумие': prudence,
                           'Авантюризм': adventurism}
