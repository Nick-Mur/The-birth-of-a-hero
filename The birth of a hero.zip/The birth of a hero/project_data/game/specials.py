from project_data.db_birth_hero.db_operation import *
from project_data.fonts import *

from random import randint


class Special:
    def __init__(self, name, description, mechanics):
        self.name = name
        self.description = description
        self.mechanics = mechanics

    def info(self, id=None, full=True):
        if full:
            text = '+=={:::::::::::::::::> |SPECIAL|\n' \
                   '- - - - - - - - - - - - - - - - - - - - - -' \
                   f'\n🪧 Название: {self.name}\n' \
                   f'\n✨ Механика: {self.mechanics}\n' \
                   f'\n📜 Описание: {self.description}\n' \
                   f'- - - - - - - - - - - - - - - - - - - - - -'
        else:
            text = '+=={:::::::::::::::::> |SPECIAL|\n' \
                   '- - - - - - - - - - - - - - - - - - - - - -' \
                   f'\n🪧 Название: {self.name}\n' \
                   f'\n✨ Механика: {self.mechanics}\n' \
                   f'- - - - - - - - - - - - - - - - - - - - - -'
        return text

class Prudence(Special):
    def check(self, subject, id):
        if subject.class_name == 'Hero':
            save_fight(id, 'self_sequence', '')
            text = [(bold(f'Для {get_hero(id, "name")} применена особенность *{self.name}*'))]
            save_fight(id, 'self_armor_bonus', True)
        else:
            save_fight(id, 'enemy_sequence', '')
            text = [(bold(f'Для {subject.name} применена особенность *{self.name}*'))]
            save_fight(id, 'enemy_armor_bonus', True)
        return text

    @staticmethod
    def bonus(subject, id):
        if subject.class_name == 'Hero':
            points = get_fight(id, 'self_points')
            save_fight(id, 'self_points', points + randint(1, 6))
            save_fight(id, 'self_armor_bonus', False)
        else:
            points = get_fight(id, 'enemy_points')
            save_fight(id, 'enemy_points', points + randint(1, 6))
            save_fight(id, 'enemy_armor_bonus', False)


class Adventurism(Special):
    def check(self, subject, id):
        if subject.class_name == 'Hero':
            text = list()
            if get_fight(id, 'self_sequence') == '':
                save_fight(id, 'self_armor_bonus', True)
                text = [(bold(f'Для {get_hero(id, "name")} применена особенность *{self.name}*'))]
            save_fight(id, 'self_points', 0)
            save_fight(id, 'self_sequence', '')
        else:
            text = None
            if get_fight(id, 'enemy_sequence') == '':
                save_fight(id, 'enemy_armor_bonus', True)
                text = [(bold(f'Для {subject.name} применена особенность *{self.name}*'))]
            save_fight(id, 'enemy_points', 0)
            save_fight(id, 'enemy_sequence', '')
        return text

    @staticmethod
    def bonus(subject, id):
        if subject.class_name == 'Hero':
            save_fight(id, 'self_points', 6)
            save_fight(id, 'self_armor_bonus', False)
        else:
            save_fight(id, 'enemy_points', 6)
            save_fight(id, 'enemy_armor_bonus', False)


prudence = Prudence(
name='Благоразумие',
description='Герой знает: для победы не обязательно тратить все силы за раз.',
mechanics='Твои очки действия не сгорают в конце хода.')

adventurism = Adventurism(
name='Авантюризм',
description='Кто не рискует, тот не пьёт шампанского!',
mechanics='Если за ход ты не использовал ни одну технику, на следующем ходу у тебя будет 6 очков действия.')

specials_name_to_object = {'Благоразумие': prudence,
                           'Авантюризм': adventurism}
