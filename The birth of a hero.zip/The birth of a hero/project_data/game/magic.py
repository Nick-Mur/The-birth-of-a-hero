magic = {'': ''}
