from project_data.game.techniques import *


from random import choice


class Weapon:
    def __init__(self, name, min_damage, max_damage, techniques, description):
        self.name = name
        self.min_damage = min_damage
        self.max_damage = max_damage
        self.techniques = techniques
        self.description = description

    def info(self):
        text = f'🪧 Название: {self.name}\n' \
               f'\n🩸 Урон: {self.min_damage} - {self.max_damage}\n' \
               f'👊 Связанные приёмы:\n'
        for i in self.techniques:
            text += f'• {i.name}\n'
        text += f'\n📜 Описание: {self.description}\n'
        return text


hero_sword = Weapon(name='Меч героя', min_damage=2, max_damage=4, techniques=[swing_and_punch, defence_posture],
description='Этот меч был дан тебе для свершения великих дел. Он не так хорош, как выглядит, зато красиво блестит.')
dagger = Weapon(name='Скрытый клинок', min_damage=1, max_damage=5, techniques=[lunge, strict_punch],
description='Странный, не понятный кинжал, но бьёт больно.')
weapons_name_to_object = {'Меч героя': hero_sword,
                          'Скрытый клинок': dagger}
