from project_data.game.techniques import *


from random import choice


class Weapon:
    def __init__(self, name, min_damage, max_damage, techniques, description):
        self.name = name
        self.min_damage = min_damage
        self.max_damage = max_damage
        self.techniques = techniques
        self.description = description

    def info(self):
        text = f'Название: {self.name}\n' \
               f'Урон: {self.min_damage} - {self.max_damage}\n' \
               f'Приёмы:\n'
        for i in self.techniques:
            text += f'  {i.name}\n'
        text += f'Описание: {self.description}\n'
        return text


hero_sword1 = Weapon(name='Меч героя', min_damage=1, max_damage=6, techniques=[swing_and_punch1, defence_posture1],
                     description=
'Этот меч был дан тебе для свершения великих дел. Он не так хорош, как выглядит, зато красиво блестит.')
hero_sword2 = Weapon(name='Меч героя', min_damage=2, max_damage=5,
                     techniques=choice([[swing_and_punch1, defence_posture2], [swing_and_punch2, defence_posture1]]),
                     description=
'Этот меч был дан тебе для свершения великих дел. Он не так хорош, как выглядит, зато красиво блестит.')
hero_sword3 = Weapon(name='Меч героя', min_damage=3, max_damage=4, techniques=[swing_and_punch2, defence_posture2],
                     description=
'Этот меч был дан тебе для свершения великих дел. Он не так хорош, как выглядит, зато красиво блестит.')
dagger1 = Weapon(name='Скрытый клинок', min_damage=1, max_damage=5, techniques=[lunge1, strict_punch1],
                     description=
'Странный не понятный кинжал, но бьёт больно.')
weapons = {'01.01': hero_sword1, '01.02': hero_sword2, '01.03': hero_sword3,
           '02.01': dagger1}
