from project_data.fonts import *
from project_data.db_birth_hero.db_operation import *
from project_data.game.enemies import enemies_name_to_object

from telebot import types
from random import choice


Button = types.KeyboardButton
Markup = types.ReplyKeyboardMarkup

def get_plot(key, user_name=None, id=None, full=True, game_object=None, old_equip=None, new_equip=None):
    if id:
        name = get_hero(id, "name")
    # region rebirth
    if key == 'rebirth':
        text = [
            "...",
            ancient_language("Пустота: Решил начать сначала?"),
            ancient_language("Пустота: Всё по новой? Интересно."),
            ancient_language("Пустота: История повернётся вспять."),
            ancient_language("Пустота: Воспользуйся этим, не забывай ради чего это всё."),
            ancient_language(f"Пустота: {bold('Напиши что-нибудь')}, чтобы я вновь тебя услышал."),
            "..."
        ]
    # endregion
    # region start
    elif key == 'start':
        text = [
            ancient_language(f"Пустота: Вновь приветствую тебя, {user_name}."),
            ancient_language(f"Пустота: Надеюсь, ты помнишь о своей задаче?")
        ]
    # endregion
    # region in_inventory
    # region prepare_to_fight
    elif key == 'prepare_to_fight':
        text = [
            f'pass',

            f'{name}: Так, необходимо подготовиться перед боем.'
        ]
    elif key == 'check':
        if full:
            phrase = bold('*ЗДЕСЬ БУДЕТ КАРТИНКА*')
        else:
            phrase = 'pass'
        text = [
            phrase,

            game_object.info(id, full)
        ]

    elif key == 'change':
        text = [
            bold(f'Снят *{old_equip}*'),

            bold(f'Экипирован *{new_equip}*')
        ]
    # endregion
    # region choice_weapon
    elif key == 'choice_weapon':
        # todo: добавить реплик
        text = [
            f'pass',

            f'{name}: Так, что у меня тут есть?'
        ]
    # endregion
    # region choice_armor
    elif key == 'choice_armor':
        # todo: добавить реплик
        text = [
            'pass',

            f'{name}: Так, что у меня тут есть?'
        ]
    # endregion
    # region choice_technique
    elif key == 'choice_technique':
        # todo: добавить реплик
        text = [
            f'pass',

            f'{name}: Так, что я там умею?'
        ]
    # endregion
    # region choice_enemy_technique
    elif key == 'choice_enemy_technique':
        # todo: добавить реплик
        text = [
            'pass',

            f'{name}: Сейчас посмотрим, на что он способен.'
        ]
    # endregion
    # region fight_back_to_choice
    elif key == 'fight_back_to_choice':
        # todo: добавить реплик
        text = [
            f'pass',

            f'{name}: Теперь я точно готов... Надеюсь.'
        ]
    # endregion
    # endregion
    # region fight
    # region roll_dice
    elif key == 'roll_dice':
        # todo: добавить реплик
        points = get_fight(id, 'points')
        random_phrase_1 = choice([f'Кости показали: твой потенциал на этот ход равен {points}',
                   f'Неплохо, {name}, твой потенциал: {points}',
                   f'Иии, тебе выпало {points}'])
        text = [
            italics(random_phrase_1),
            italics(f'Что же ты сделаешь в этот раз, {name}?')
        ]
    # endregion
    # region check_yourself_fight
    elif key == 'check_yourself_fight':
        # todo: добавить реплик
        text = [
            f'{name}: Так.',

            f'{name}: Сейчас посмотрим.'
        ]
    # endregion
    # region check_yourself_fight
    elif key == 'check_enemy_fight':
        # todo: добавить реплик
        text = [
            f'{name}: Так.',

            f'{name}: Сейчас посмотрим.'
        ]
    # endregion
    # endregion
    # region stage 1
    elif key == '1.1':
        text = [
            ancient_language(f"Пустота: Сложно сказать, я скорее {underlined('что')}. "
                             f"Но я более чем осознанное существо."),
            ancient_language(f"Пустота: Скажем, мы похожи, но я думаю ты и так понимаешь,"
                             f" что мы отличаемся. Мы одни из тех, кто влияют на этот мир, но "
                             f"способы у всех нас разные.")
        ]
    elif key == '1.2':
        text = [
            ancient_language(f"Пустота: Снова забыл, ну ничего."),
            ancient_language(f"Пустота: Твоя цель - взрастить героя. Исполнить пророчество."),
            ancient_language(f"Пустота: Необходимо, чтобы ты стал для крестьянина воплощением судьбы."),
            ancient_language(f"Пустота: Если ты хотел бы изменить прошлое, сделать иные выборы - ты можешь "
                             f"{underlined('переродиться')}, {bold('введя')} '/rebirth'.")
        ]
    elif key == '1.3':
        text = [
            ancient_language(f"Пустота: После того как я договорю, {bold('напиши имя')} крестьянина,"
                             f" которого ты хочешь выбрать."),
            ancient_language(f"Пустота: Напомню, будь осторожнее с {underlined('рассказчиком')}. Он куда могущественнее, чем кажется."
                             f" Он может помешать твоей задаче, нашей цели."),
            ancient_language(f"...")
        ]
    # endregion
    # region stage 2
    elif key == '2':
        text = [
            f'{name}: Интересно, каково жить в том замке...',

            f'{name}: Осознавать, что ты - король {underlined("Регнум Витаэ")}.',

            f'{name}: Наверное, эта мысль и погубила нашего короля, нашего {underlined("героя")}.',

            f'{name}: Хорошо, что рядом был его {underlined("орден")}. Они доказали, что герой не един, '
            f'героями может быть целый орден!',

            f'{name}: Они во время заметили проблемы короля и рассказали о них народу. Они смогли помочь ему, '
            f'взвалив груз обязанностей на свои плечи, дабы у него была возможность снова стать {underlined("великим")}.',

            f'{name}: Хотел бы я быть одним из них: таким же сильным и ловким, смелым и бесстрашным, '
            f'умным и великим...',

            f'{name}: Вот если бы я там был, ни один монстр не посмел бы напасть так подло и коварно на мирный люд!',

            f'{name}: Ох, небеса, только позвольте мне ненадолго стать героем - я изменю этот мир, '
            f'я устал от этой несправедливости, услышьте меня!',

            italics(f'Я услышал тебя, {name}.'),

            italics(f'Кажется, ты не такой как все, раз заинтересовал высшие силы.'),

            italics(f'Я до конца не уверен, но, кажется, я был призван {underlined("пророчеством")}, и ты взаправду получил шанс стать '
                    f'{underlined("героем")}!'),

            f'{name}: Что, прости..?',

            f'{name}: Я - избранный герой..?',

            f'{name}: Но что? Как это вообще?',
        ]
    # endregion
    # region stage 3
    elif key == '3.1':
        text = [
            f'{name}: Какое ещё "пророчество"?',

            italics('Поговаривают, наступит тот день, когда герой люда, заручившись поддержкой небес,'
                    ' изменит Регнум Витаэ раз и навсегда и установит новый мировой порядок!'),

            f'{name}: И я тот самый герой?!',

            italics('Это нам ещё предстоит выяснить.'),

            italics(f'А, и ещё, зови меня {underlined("Рассказчиком")}. Мне так привычнее.'),

            f'{name}: Подожди, не значит ли это, что я не первый избранный?',

            italics('Главное, чтобы ты оказался последним.'),

            f'{name}: Справедливо.'
        ]
    elif key == '3.2':
        text = [
            f'{name}: Но как мне стать героем в {underlined("этом")}?',

            italics('О, точно, сейчас исправим.'),

            bold('Получены *Сияющие доспехи* и *Меч героя*.'),

            bold('*Сияющие доспехи* заменили *Лохмотья*.'),

            bold('Экипирован *Меч героя*.'),

            f'{name}: НИЧЕГО СЕБЕ!!!',

            f'{name}: ТЫ И ТАК УМЕЕШЬ?!',

            italics('Да, я много чего умею. Но это скорее исключение. Всё таки это не мой профиль.'),

            f'{name}: Вау...'
        ]

    # endregion
    # region stage 4
    elif key == '4':
        text = [
            italics('Ладно, довольно вопросов. Иначе мы так весь день просидим.'),

            italics('Мир не ждёт, кто-то может стать героем раньше тебя...'),

            f'{name}: Это разве работает по времени?',

            italics('Не знаю, ты сам просил стать героем ненадолго.'),

            f'{name}: Ох, блин. И что же мне делать?',

            italics('Для начала, я бы рекомендовал спуститься вон в ту деревню.'),

            f'{name}: Звучит разумно. (начал спускаться со склона)'
        ]
    # endregion
    # region stage 5
    elif key == '5.1':
        text = [
            f'{name}: Слушай, а у тебя уже есть какой-то план? Ну, куда мы пойдём-то, я хоть и выгляжу как рыцарь, '
            f'но я не знаю жизни за деревней, я там совсем редко бывал. Да и драться я не особо умею...',

            italics('Спокойно, наш путь долог, ты ещё научишься. Мы направляемся к замку, к королю. Если ты, конечно, '
                    'не умрёшь по пути.'),

            f'{name}: ЧТО?!',

            f'{name}: ПРЯМО К КОРОЛЮ?!',

            f'{name}: Но зачем?',

            italics('Король - "герой", пусть я и не согласен с этим, но факт есть факт. Ты должен изменить '
                    'Регнум Витаэ. А такое может быть связано с ним.'),

            italics('Тем более, если мы узнаем что-то новое, что откроем нам глаза на ситуацию, мы сможем изменить '
                    'наш маршрут, не так ли?'),

            f'{name}: Ну да, ты прав, тем более путь очень далёк...',

            italics('Вот и договорились.')
        ]
    elif key == '5.2':
        text = [
            f'{name}: Рассказчик, а ты всегда был... ну... таким?',

            italics('Что ты имеешь ввиду?'),

            f'{name}: Возможно это глупо, но мне интересно, был ли ты таким всегда или нет, какого вообще быть тобой?',

            italics('Сложно сказать, я слабо помню жизнь и была ли она вообще.'),

            italics('Есть отголоски прошлого, но я не могу до конца осознать это.'),

            italics(f'Так что сложно сказать, {underlined("что")} я такое.'),

            italics(f'Какого быть мной?'),

            italics(f'Думаю скучно.'),

            italics(f'Я ожил лишь тогда, когда смог откликнуться на твой зов.'),

            italics(f'Хотя сейчас быть мной довольно... интересно? Думаю, да.'),

            italics(f'Я чувствую этот мир и являюсь его частью, но я не лишён сознания, что даёт некоторые '
                    f'преимущества. Думаю ты уже заметил это.'),

            f'{name}: Звучит и вправду хорошо! Рад за тебя! Думаю у нас всё получится!',

            italics(f'Ещё посмотрим, что получится. Не радуйся раньше времени.')
        ]
    # endregion
    # region stage 6
    elif key == '6':
        text = [
            'gif',

            f'{name}: Ах, родная деревня! Как же тут всё таки хорошо.',

            italics(f'Если тут так хорошо, то чего тогда замечтался на уступе?'),

            f'{name}: Мечтать полезно и интересно. Всё таки жизнь не череда удач и радостей. Хоть и грех жаловаться, '
            f'но иногда душа хочет большего.',

            italics(f'Нет ничего плохого в том, чтобы желать большего, чем у тебя есть сейчас. Даже если другие '
                    f'думают иначе.'),

            f'{name}: Хорошо, постараюсь запомнить этот урок.',

            f'{name}: Как всё таки необычно быть в столь знакомом месте, но в совершенно другом образе!',

            f'{name}: Я прямо таки вижу как смотрят на меня люди вокруг, как заглядываются барышни!',

            italics(f'Не надо зазнаваться, ты только доспехами успел обзавестись.'),

            f'{name}: Да-да, как скажешь.'
        ]
    # endregion
    # region stage 7
    elif key == '7':
        text = [
            f'{name}: Смотри!',

            f'{name}: Кажется, там что-то происходит!',

            italics(f'Здесь постоянно что-то происходит, {name}, мы же в деревне.'),

            f'{name}: Да нет, я не про это. Мне показалось, тот человек, который пошёл вслед за бабкой, достал {underlined("кинжал")}!',

            italics(f'Хм, и что же ты сделаешь? Учти, если ты нападёшь на невиновного, то добром это не кончится. '
                    f'И я не думаю, что лезть в чужие дела такая хорошая идея. Но ты тут герой - решать тебе.'),
        ]
    # endregion
    # region stage 8
    elif key == '8.1':
        text = [
            f'Бабка: Ты, Алчек, всегда искал лёгкие пути! ',

            f'Разбойник (Алчек): Вот зачем ты кричишь. Я ведь просто попросил пару золотых!',

            f'Бабка: И кинжал ты достал просто так?',

            f'Бабка: Сейчас трудные времена, да. И ты решил, что тебе всё можно?',

            f'Разбойник (Алчек): Слишком много вопросов, Преведа, мы хоть давно знакомы, но уж прости.',

            f'Бабка (Преведа): Ну смотри, ты так легко не отделаешься!',

            f'{name}: А ну отойди от неё, разбойник!',

            f'Разбойник (Алчек): Я ТАК ЛЕГКО НЕ СДАМСЯ!'
        ]
    elif key == '8.2':
        text = [
            f'Бабка: Ты ничего не получишь!',

            f'Бабка: уйди от меня!'
        ]
    # todo: будет ещё 8.3
    # endregion
    # region stage 9
    elif key == '9.1':
        text = [
            italics(f'Смело, {name}. И что же ты теперь будешь делать?'),

            f'{name}: Я не знаю! Помоги мне, Рассказчик!!!',

            italics(f'Тебе очень повезло, мой друг. У меня есть один кубик, показывающий потенциал того, '
                    f'кого я хочу. {bold("Благодаря ему, можно понять, на что ты способен за ход")}.'),

            f'{name}: Ого! Но что это мне даёт?',

            italics(f'Зная свой потенциал, ты можешь выжать максимум из своих действий!'),

            italics(f'Ты готов?')
        ]
    # endregion
    return text


def get_markup(key, id=None):
    markup = Markup(resize_keyboard=True)
    # region start
    if key == 'start':
        first = Button('Кто ты?')
        second = Button('Что за задача?')
        third = Button('Я готов.')
        markup.add(first, second)
        markup.add(third)
    # endregion
    # region in_inventory
    # region create_inventory_interface
    elif key == 'create_inventory_interface':
        first = Button('Осмотреть себя.')
        second = Button('Изучить противника.')
        third = Button('Открыть сумку c припасами.')
        fourth = Button('Вернуться к выбору.')
        markup.add(first, second)
        markup.add(third)
        markup.add(fourth)
    # endregion
    # region check_yourself
    elif key == 'check_yourself':
        first = Button('Осмотреть оружие.')
        second = Button('Выбрать оружие.')
        third = Button('Осмотреть броню.')
        fourth = Button('Выбрать броню.')
        fifth = Button('Вспомнить приёмы.')
        sixth = Button('Вспомнить особенность брони.')
        markup.add(first, second)
        markup.add(third, fourth)
        markup.add(fifth)
        markup.add(sixth)
    # endregion
    # region choice_weapon
    elif key == 'choice_weapon':
        slot_1 = get_inventory_weapons(id, 'slot_1')
        slot_2 = get_inventory_weapons(id, 'slot_2')
        slot_3 = get_inventory_weapons(id, 'slot_3')
        first = Button('Слот 1: ' + slot_1)
        second = Button('Слот 2: ' + slot_2)
        third = Button('Слот 3: ' + slot_3)
        markup.add(first)
        markup.add(second)
        markup.add(third)
    # endregion
    # region choice_armor
    elif key == 'choice_armor':
        slot_1 = get_inventory_armors(id, 'slot_1')
        slot_2 = get_inventory_armors(id, 'slot_2')
        slot_3 = get_inventory_armors(id, 'slot_3')
        first = Button('Слот 1: ' + slot_1)
        second = Button('Слот 2: ' + slot_2)
        third = Button('Слот 3: ' + slot_3)
        markup.add(first)
        markup.add(second)
        markup.add(third)
    # endregion
    # region choice_technique
    elif key == 'choice_technique':
        slot_1 = get_techniques(id, 'slot_1')
        slot_2 = get_techniques(id, 'slot_2')
        slot_3 = get_techniques(id, 'slot_3')
        slot_4 = get_techniques(id, 'slot_4')
        first = Button('Слот 1: ' + slot_1)
        second = Button('Слот 2: ' + slot_2)
        third = Button('Слот 3: ' + slot_3)
        fourth = Button('Слот 4: ' + slot_4)
        markup.add(first, second)
        markup.add(third, fourth)
    # endregion
    # region check_enemy
    elif key == 'check_enemy':
        first = Button('Осмотреть его оружие.')
        second = Button('Осмотреть его броню.')
        third = Button('Узнать его приёмы.')
        fourth = Button('Узнать особенность его брони.')
        markup.add(first, second)
        markup.add(third)
        markup.add(fourth)
    # endregion
    # region choice_enemy_technique
    elif key == 'choice_enemy_technique':
        enemy = enemies_name_to_object[get_enemy(id, 'name')]
        slot_1 = enemy.weapon.techniques[0].name
        if len(enemy.weapon.techniques) == 2:
            slot_2 = enemy.weapon.techniques[1].name
        else:
            slot_2 = '—'
        slot_3 = enemy.techniques[0].name
        if len(enemy.techniques) == 2:
            slot_4 = enemy.techniques[1].name
        else:
            slot_4 = '—'
        first = Button('Слот 1: ' + slot_1)
        second = Button('Слот 2: ' + slot_2)
        third = Button('Слот 3: ' + slot_3)
        fourth = Button('Слот 4: ' + slot_4)
        markup.add(first, second)
        markup.add(third, fourth)
    # endregion
    # endregion
    # region fight
    # region create_fight_interface
    elif key == 'create_fight_interface':
        first = Button('Приёмы.')
        second = Button('Магия.')
        third = Button('Осмотреть себя.')
        fourth = Button('Осмотреть противника.')
        sixth = Button('Закончить ход.')
        if get_user(id, 'magic_level') > 0:
            markup.add(first, second)
        else:
            markup.add(first)
        markup.add(third, fourth)
        markup.add(sixth)
    # endregion
    # region check_yourself_fight
    elif key == 'check_yourself_fight':
        first = Button('Вспомнить приёмы.')
        second = Button('Вспомнить магию.')
        third = Button('Вспомнить особенность брони.')
        if get_user(id, 'magic_level') > 0:
            markup.add(first, second)
        else:
            markup.add(first)
        markup.add(third)
    # endregion
    elif key == 'check_enemy_fight':
        first = Button('Вспомнить его приёмы.')
        second = Button('Вспомнить особенность его брони.')
        markup.add(first)
        markup.add(second)
    # endregion
    # region plot
    # region stage 1
    elif key == '1.1':
        first = Button('Ещё раз, что за задача?')
        second = Button('Я готов.')
        markup.add(first)
        markup.add(second)
    elif key == '1.2':
        first = Button('Подожди, кто ты?')
        second = Button('Я готов.')
        markup.add(first)
        markup.add(second)
    # endregion
    # region stage 2
    elif key == '2':
        ask_prophecy = Button('Узнать про пророчество.')
        ask_equipment = Button('Спросить как стать героем в лохмотьях.')
        markup.add(ask_prophecy, ask_equipment)
    # endregion
    # region stage 3
    elif key == '3.1':
        ask_equipment = Button('Спросить как стать героем в лохмотьях.')
        markup.add(ask_equipment)
    elif key == '3.2':

        ask_prophecy = Button('Узнать про пророчество.')
        markup.add(ask_prophecy)
    elif key == '3.3':
        ask_something = Button('Спросить ещё что-нибудь.')
        markup.add(ask_something)
    # endregion
    # region stage 4
    elif key == '4':
        first = Button('Спросить о дальнейшем пути.')
        second = Button('Разузнать о происхождении Рассказчика.')
        markup.add(first)
        markup.add(second)
    # endregion
    # region stage 5
    elif key == '5.1':
        first = Button('Разузнать о происхождении Рассказчика.')
        markup.add(first)
    elif key == '5.2':
        first = Button('Спросить о дальнейшем пути.')
        markup.add(first)
    elif key == '5.3':
        first = Button('Осмотреться.')
        markup.add(first)
    # endregion
    # region stage 6
    elif key == '6':
        first = Button('Двигаться в сторону ворот.')
        markup.add(first)
    # endregion
    # region stage 7
    elif key == '7':
        # 1 выбор
        first = Button('Пойти и убедиться, что всё хорошо.')
        # 2 выбор
        second = Button('Пройти мимо как ни в чём не бывало.')
        markup.add(first)
        markup.add(second)
    # endregion
    # region stage 8
    elif key == '8.1':
        first = Button('Вступить в схватку.')
        second = Button('Подготовиться к бою.')
        markup.add(first)
        markup.add(second)
    elif key == '8.2':
        first = Button('Вернуться и проверить, что всё хорошо.')
        second = Button('Идти дальше, не обращая внимание.')
        markup.add(first)
        markup.add(second)
    # endregion
    # region stage 9
    elif key == '9.1':
        first = Button('Кинуть кубик.')
        markup.add(first)
    # endregion
    # endregion
    return markup
