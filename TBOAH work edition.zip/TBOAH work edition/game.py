"""""
Чтобы запустить файл теперь нужен vpn, тк тг всё банит
"""""
import telebot
from telebot import types


from project_data.settings.config import bot_token
from project_data.db_birth_hero.db_operation import *
from project_data.game.enemies import enemies_name_to_object, hero
from project_data.game.weapons_new import weapons_name_to_object
from project_data.game.armors_new import armors_name_to_object
from project_data.game.magic import *
from project_data.settings.plot import get_plot, get_markup
from project_data.game.techniques import techniques_name_to_object
from random import randint, choice

from time import sleep


# region settings
bot = telebot.TeleBot(token=bot_token)
remove = types.ReplyKeyboardRemove()
# endregion
# region send
def send(message, key_plot, key_markup=None):
    # todo: доработать картинки, гифки, видео
    id = message.from_user.id
    plot = get_plot(key=key_plot, message=message)

    if len(plot) == 1:
        bot.send_message(message.chat.id, plot[0], reply_markup=get_markup(key=key_markup, id=id), parse_mode='HTML')
    else:
        for text in plot:
            if text == plot[0]:
                bot.send_message(message.chat.id, text, reply_markup=remove, parse_mode='HTML')
            elif text == plot[-1] and key_markup:
                bot.send_message(message.chat.id, text, reply_markup=get_markup(key=key_markup, id=id), parse_mode='HTML')
                continue
            else:
                bot.send_message(message.chat.id, text, parse_mode='HTML')
            #sleep(get_settings(id, 'time_sleep'))
            sleep(0)

# endregion
# region story
@bot.message_handler(commands=['rebirth'])
def rebirth(message):
    id = message.from_user.id
    start_over(id)
    send(message=message, key_plot='rebirth')
    bot.register_next_step_handler(message,  telegram_start)


@bot.message_handler(commands=['instant_kill'])
def instant_kill(message):
    id = message.from_user.id
    if get_enemy(id, 'name') in enemies_name_to_object:
        save_enemy(id, 'health', 0)


@bot.message_handler(commands=['start'])
def telegram_start(message):
    id = message.from_user.id
    db_reg(id)
    if get_stage(id) == 1:
        send(message=message, key_plot='start', key_markup='start')


@bot.message_handler(commands=['handbook'])
def handbook(message):
    id = message.from_user.id
    send(message=message, key_plot='handbook', key_markup='handbook')
    if 'handbook' not in get_settings(id, 'special_situation'):
        save_settings(id, 'special_situation', 'handbook')


# endregion
@bot.message_handler(content_types=['text'])
def main(message):
    text = message.text
    id = message.from_user.id
    stage = get_stage(id)
    special_situation = get_settings(id, 'special_situation')
    choices = get_settings(id, 'choices')
    if special_situation:
        if 'handbook' in special_situation:
            if text == 'Краткое обучение искусству войны.':
                send(message=message, key_plot='handbook training')
            elif text == 'О показателях.':
                send(message=message, key_plot='handbook guide')
            # todo: доделать гайд
        elif 'fight' in special_situation:
            if text == 'Драться.':
                send(message=message, key_plot='fight start_fight', key_markup='fight roll_dice')
            elif text == 'Кинуть кубик.' and not get_fight(id, 'roll_dice'):
                send(message=message, key_plot='fight roll_dice', key_markup='fight menu')
                save_fight(id, 'roll_dice', True)
            elif text == 'Приёмы':
                send(message=message, key_plot='pass', key_markup='fight techniques_choice')
            elif text == 'Применить приём.':
                save_settings(id, 'special_situation', 'use_technique')
                send(message=message, key_plot='pass', key_markup='fight techniques')
    # region plot
    # region stage 1
    if stage == 1:
        if text in [
                    'Кто ты?',
                    'Подожди, кто ты?'
                    ]:
            send(message=message, key_plot='1.1', key_markup='1.1')
        elif text in [
                    'Что за задача?',
                    'Ещё раз, что за задача?'
                    ]:
            send(message=message, key_plot='1.2', key_markup='1.2')
        elif text == 'Я готов.':
            send(message=message, key_plot='1.3', key_markup='1.3')
        elif text == 'Приступить к задаче.':
            send(message=message, key_plot='1.4', key_markup='1.4')
            save_stage(id, 2)
    # endregion
    # region stage 2
    elif stage == 2:
        if len(text) <= 25:
            save_hero(userid=id, param='name', val=text)
            save_stage(id, 3)
            send(message=message, key_plot='2', key_markup='2')
    # endregion
    # region stage 3
    elif 3 <= stage < 4:
        if text == 'Продолжить мечтать.':
            send(message=message, key_plot='3.1', key_markup='3.1')
        elif text == 'Попытаться вспомнить всех героев.':
            send(message=message, key_plot='3.2', key_markup='3.2')
        elif text == 'Помечтать о чём-то ещё.':
            send(message=message, key_plot='3.3', key_markup='3.3')
        elif text == 'Начать задавать вопросы.':
            send(message=message, key_plot='3.4', key_markup='3.4')
        elif text in ['Кто ты такой?', 'Ещё раз, кто ты такой?']:
            save_stage(id, get_stage(id) + 0.5)
            send(message=message, key_plot='3.4.1', key_markup='3.4.1')
        elif text in ['Я сошёл с ума?', 'Я точно не сошёл с ума?']:
            save_stage(id, get_stage(id) + 0.5)
            send(message=message, key_plot='3.4.2', key_markup='3.4.2')
        elif text in ['Как долго ты меня подслушивал?', 'Подожди, сколько уже ты здесь?']:
            save_stage(id, get_stage(id) + 0.5)
            send(message=message, key_plot='3.4.3', key_markup='3.4.3')
    # endregion
    # region stage 4
    elif stage == 4:
        if text in ['Кто ты такой?', 'Ещё раз, кто ты такой?', 'Я сошёл с ума?', 'Я точно не сошёл с ума?',
                    'Как долго ты меня подслушивал?', 'Подожди, сколько уже ты здесь?']:
            send(message=message, key_plot='4.1', key_markup='4.1')
        elif text == 'Попытаться всё осознать.':
            send(message=message, key_plot='4.2', key_markup='4.2')
        elif text == 'Спуститься со скалы.':
            send(message=message, key_plot='4.3', key_markup='4.3')
        elif text == 'Пойти вперёд.':
            send(message=message, key_plot='4.4', key_markup='4.4')
        elif text == 'Продолжить путь.':
            send(message=message, key_plot='4.5', key_markup='4.5')
        elif text == 'Подойти к группе крестьянок.':
            send(message=message, key_plot='4.6', key_markup='4.6')
        elif text == 'Понаблюдать за странной парочкой.':
            send(message=message, key_plot='4.7', key_markup='4.7')
        elif text == 'Пойти в сторону бабки.':
            send(message=message, key_plot='4.8', key_markup='4.8')
            save_settings(id, 'choices', '4:1')
            save_stage(id, 5)
        elif text == 'Пойти прочь от странной парочки.':
            send(message=message, key_plot='4.9', key_markup='4.9')
            save_stage(id, 5)
        elif text in ['Пойти в сторону крестьянок.', 'Вернуться к крестьянкам.']:
            send(message=message, key_plot='4.10', key_markup='4.10')
            save_settings(id, 'choices', '4:2')
            save_stage(id, 5)
            # todo: доделать
    # endregion
    # region stage 5
    elif stage == 5:
       if text == 'Бежать за ними.':
           send(message=message, key_plot='5.1', key_markup='5.1')
       elif text == 'Вмешаться.':
           send(message=message, key_plot='5.2', key_markup='fight start')
           save_settings(id, 'special_situation', 'fight')
    # endregion
bot.infinity_polling()
