from project_data.fonts import *
from project_data.db_birth_hero.db_operation import *
from project_data.game.enemies import enemies_name_to_object

from telebot import types
from random import choice


Button = types.KeyboardButton
Markup = types.ReplyKeyboardMarkup
void = underlined('Тенебрис')
grandma = underlined('Бабка')
grandma_with_name = underlined('Бабка (Преведа)')
rogue = underlined('Разбойник (Алчек)')

def get_plot(key, user_name=None, id=None, full=True, game_object=None, old_equip=None, new_equip=None, special_text=None):
    if id:
        name = underlined(get_hero(id, "name"))
        name_in_text = get_hero(id, "name")
    # region rebirth
    if key == 'rebirth':
        text = [
            "...",
            ancient_language(f"{void}: Ах, снова возвращаемся к истокам, как это всё интересно."),
            ancient_language(f"{void}: Надеюсь, ты усвоил новые уроки?"),
            ancient_language(f"{void}: Ну, это мы ещё выясним."),
            ancient_language(f"{void}: {bold('Напиши')} что-нибудь, чтобы вернутся к нашему первому разговору."),
            "..."
        ]
    # endregion
    # region start
    elif key == 'start':
        text = [
            ancient_language(f"{void}: Вновь приветствую тебя, {user_name}."),
            ancient_language(f"{void}: Надеюсь, ты помнишь свою задачу?")
        ]
    # endregion
    # region training
    elif key == 'training':
        # todo: вписать магию
        text = [
            'pass',

            bold('• У персонажей есть здоровье и защита - это то что отнимается при нанесении урона. Защита восстанавливается '
            'по завершении боя, здоровье - в особых ситуациях и с помощью расходников.'),

            bold('• У каждого персонажа есть оружие и броня. Оружие может давать до 2-ух приёмов, также оно имеет урон. '
            'Броня даёт особенность и имеет защиту.'),

            bold(
                '• Приёмы - это то, чем ты атакуешь. Чтобы их использовать надо потратить о.п. (очки потенциала). О. п. '
                'даются в начале хода от 1 до 6.'),

            bold(
                '• Особенность даёт тебе бонус, зависит от брони.'),

            bold(
                '• У героя есть инвентарь, в котором может храниться до 3-ёх оружий, бронь и расходников.')
        ]
    # endregion
    # region pass
    elif key == 'pass':
        stage = get_stage(id)
        if stage == 2:
            phrase = ancient_language(f"{void}: {bold('Введи')} имя крестьянина, которого ты хочешь выбрать.")
        elif get_user(id, 'in_inventory'):
            phrase = bold(f'Подготовка к бою против противника *{get_enemy(id, "name")}*')
        else:
            phrase = ''
        text = [
            '...',

            phrase
        ]
    # endregion
    # region soul
    elif key == 'save_soul':
        seals = get_players_saves(id, 'short_show')
        text = [
            seals[0],
            seals[1],
            seals[2]
        ]

    elif key == 'choice_seal':
        health = get_hero(id, 'health')
        cost = int(0.1 * health)
        save_hero(id, 'health', health - cost)
        text = [
            'pass',
            bold(f'{name_in_text} потерял {cost} здоровья.'),
            bold(f'Печать {special_text[0]} сохранила часть души.')
        ]
        slot = f'slot_{special_text[0]}'
        save_players_saves(userid=id, param=slot, key_markup=special_text[1])
    # endregion
    # region hero_die
    elif key == 'hero_die':
        text = [
            ancient_language(f'{void}: Вот и умер, {name_in_text}...'),

            ancient_language(f'{void}: Жаль его.'),

            ancient_language(f'{void}: Как хорошо, что история на этом не заканчивается, понимаешь меня?'),

            ancient_language(f'{void}: А теперь сделай то, что должен.')
        ]
    # endregion
    # region enemy_die
    elif key == 'enemy_die':
        text = [
            bold(f'{get_enemy(id, "name")} пал.'),
            bold(f'Боевой уровень повышен.')
        ]
    # endregion
    # region fight_preparation
    # region prepare_to_fight
    elif key == 'prepare_to_fight':
        text = [
            f'pass',

            f'{name}: Так, необходимо подготовиться перед боем.'
        ]
    # endregion
    # region check
    elif key == 'check':
        if full:
            phrase = bold('*ЗДЕСЬ БУДЕТ КАРТИНКА*')
        else:
            phrase = 'pass'
        text = [
            phrase,

            game_object.info(id, full)
        ]
    # endregion
    # region change
    elif key == 'change':
        text = [
            bold(f'Снят *{old_equip}*'),

            bold(f'Экипирован *{new_equip}*')
        ]
    # endregion
    # region choice_weapon
    elif key == 'choice_weapon':
        # todo: добавить реплик
        text = [
            f'pass',

            f'{name}: Так, что у меня тут есть?'
        ]
    # endregion
    # region choice_armor
    elif key == 'choice_armor':
        # todo: добавить реплик
        text = [
            'pass',

            f'{name}: Так, что у меня тут есть?'
        ]
    # endregion
    # region choice_technique
    elif key == 'choice_technique':
        # todo: добавить реплик
        text = [
            f'pass',

            f'{name}: Так, что я там умею?'
        ]
    # endregion
    # region choice_enemy_technique
    elif key == 'choice_enemy_technique':
        # todo: добавить реплик
        text = [
            'pass',

            f'{name}: Сейчас посмотрим, на что он способен.'
        ]
    # endregion
    # region fight_back_to_choice
    elif key == 'fight_back_to_choice':
        # todo: добавить реплик
        text = [
            f'pass',

            f'{name}: Теперь я точно готов... Надеюсь.'
        ]
    # endregion
    # endregion
    # region fight
    # region roll_dice
    elif key == 'roll_dice':
        if game_object.class_name == 'Hero':
            text = [
                'pass',

                bold(f'Твой потенциал теперь {get_fight(id, "self_points")} о.п.')
            ]
        else:
            text = [
                bold(f'Потенциал {get_enemy(id, "name")} теперь {get_fight(id, "enemy_points")} о.п.')
            ]
    # endregion
    # region check_yourself_fight
    elif key == 'check_yourself_fight':
        # todo: добавить реплик
        text = [
            f'pass',

            f'{name}: Сейчас посмотрим.'
        ]
    # endregion
    # region check_yourself_fight
    elif key == 'check_enemy_fight':
        # todo: добавить реплик
        text = [
            f'pass',

            f'{name}: Сейчас посмотрим.'
        ]
    # endregion
    # region techniques_fight
    elif key == 'techniques_fight':
        # todo: добавить реплик
        text = [
            'pass',

            f'{name}: Сейчас посмотрим.'
        ]
    # endregion
    # region Back_phrase_fight
    elif key == 'Back_phrase_fight':
        text = [
            'pass',

            f'{name}: Не, не то.'
        ]
    # endregion
    # endregion
    # region plot
    # region stage 1
    elif key == '1.1':
        text = [
            ancient_language(f"{void}: Я предстаю перед тобой в облике тени."),
            ancient_language(f"{void}: Я та, кто даёт силы волшебникам и наполняет мир магией."),
            ancient_language(f"{void}: Я высшая сила, а ты мой верный друг, думаю эти слова вполне конкретно меня описывают, не так ли?")
        ]
    elif key == '1.2':
        text = [
            ancient_language(f"{void}: Напоминаю."),
            ancient_language(f"{void}: Твоя цель - взрастить героя, способного исполнить пророчество."),
            ancient_language(f"{void}: Ты станешь частью души крестьянина, помоги ему принимать правильные решения."),
            ancient_language(f"{void}: Ты можешь обмануть судьбу, переродиться, вернувшись в начало истории, ко мне сюда, {bold('введя')} '/rebirth'."),
            ancient_language(f"{void}: Благодаря этому, ты сможешь принять иные решения, зная иные вводные.")
        ]
    elif key == '1.3':
        text = [
            ancient_language(f"{void}: Напомню, будь осторожнее с рассказчиком. Не дай ему всё испортить."),
            ancient_language(f"{void}: Также не забывай про 3 печати души."),
            ancient_language(f"{void}: За 10% текущего здоровья крестьянина ты сможешь сохранить часть его души."),
            ancient_language(f"{void}: Использовать/сохранять печати можно во время подготовки к бою, после боя."),
            ancient_language(f"{void}: Также ты можешь сейчас использовать часть души, дабы вернуться туда, куда ты хочешь."),
            ancient_language(f"{void}: {bold('Введи')} имя крестьянина, которого ты хочешь выбрать {bold('(не больше 25 символов)')}."),
        ]
    # endregion
    # region stage 2
    elif key == '2':
        text = [
            '...',

            f'{name}: Интересно, каково жить в том замке...',

            f'{name}: Осознавать, что ты - король великого королевства "Регнум Луминис", герой всех людей, глава сильнейшего ордена.',

            f'{name}: Может как раз всё это и погубило нашего короля?',

            f'{name}: Хорошо, что рядом был его орден.',

            f'{name}: Они во время заметили проблемы короля и рассказали о них народу.',

            f'{name}: Они смогли помочь ему, взвалив груз обязанностей на свои плечи, дабы у него была возможность снова стать великим.',

            f'{name}: Они доказали: герой не обязательно один, целый орден может состоять из героев.',

            f'{name}: Интересно, какой была бы моя жизнь, если бы я был одним из них?',

            f'{name}: Может будь я там в период великой войны, ни один монстр не посмел бы напасть!',

            f'{name}: Ох, небеса, только позвольте мне ненадолго стать героем - я изменю этот мир, '
            f'я устал от этой несправедливости, услышьте меня!',

            '...',

            italics(f'Я услышал тебя, {name_in_text}.'),

            italics(f'Кажется, ты не такой как все, раз заинтересовал высшие силы.'),

            italics(f'Я до конца не уверен, но, кажется, я был призван пророчеством, и ты взаправду получил шанс стать героем.'),

            f'{name}: Что, прости..?',

            f'{name}: Я - избранный герой..?',

            f'{name}: Но что? Как это вообще?',
        ]
    # endregion
    # region stage 3
    elif key == '3.1':
        text = [
            f'{name}: Какое ещё "пророчество"?',

            italics('Поговаривают, наступит тот день, когда герой люда, заручившись поддержкой небес,'
                    ' изменит Регнум Луминис раз и навсегда и установит новый мировой порядок!'),

            f'{name}: И я тот самый герой?!',

            italics('Это нам ещё предстоит выяснить.'),

            italics(f'А, и ещё, зови меня Рассказчиком.'),

            italics(f'Мне так привычнее.'),

            f'{name}: Подожди, а я первый избранный?',

            italics('Главное, чтобы ты оказался последним.'),

            f'{name}: Справедливо.'
        ]
    elif key == '3.2':
        text = [
            f'{name}: Но как мне стать героем в этом?',

            italics('О, точно, сейчас исправим.'),

            bold('Экипированы *Меч героя* и *Сияющие доспехи*.'),

            f'{name}: НИЧЕГО СЕБЕ!!!',

            f'{name}: ТЫ И ТАК УМЕЕШЬ?!',

            italics('Да, я много чего умею.'),

            italics('Но это скорее исключение.'),

            italics('Всё таки это не мой профиль.'),

            f'{name}: Вау...'
        ]

    # endregion
    # region stage 4
    elif key == '4':
        text = [
            italics('Ладно, довольно вопросов. Иначе мы здесь застрянем на весь день.'),

            italics('Мир не ждёт, кто-то может стать героем раньше тебя...'),

            f'{name}: Это разве работает по времени?',

            italics('Не знаю, ты сам просил стать героем ненадолго.'),

            f'{name}: Ох. И что же мне делать?',

            italics('Для начала, я бы рекомендовал спуститься ту деревню, которая под нами.'),

            f'{name}: Звучит разумно. (начал спускаться со склона)'
        ]
    # endregion
    # region stage 5
    elif key == '5.1':
        text = [
            f'{name}: Слушай, а у тебя уже есть какой-то план?',

            f'{name}: Ну, куда мы пойдём-то?',

            f'{name}: Я хоть и выгляжу как рыцарь, но я не знаю жизни за деревней, я там совсем редко бывал.',

            f'{name}: Да и драться я не особо умею...',

            italics('Спокойно, наш путь долог, ты ещё научишься.'),

            italics('Мы направляемся к замку, к королю.'),

            italics('Если ты, конечно, не умрёшь по пути.'),

            f'{name}: ЧТО?!',

            f'{name}: ПРЯМО К КОРОЛЮ?!',

            f'{name}: Но зачем?',

            italics('Король был героем, к тому же ты должен изменить его королевство.'),

            italics('Тем более, если мы узнаем что-то новое, мы сможем изменить наш маршрут, не так ли?'),

            f'{name}: Ну да, ты прав, тем более путь очень далёк...',

            italics('Вот и договорились.')
        ]
    elif key == '5.2':
        text = [
            f'{name}: Рассказчик, а ты всегда был... ну... таким?',

            italics('Что ты имеешь ввиду?'),

            f'{name}: Ну, ты голос у меня в голове.',

            f'{name}: Но слушая тебя, мне начинает казаться, что раньше ты был другим.',

            italics('Да, я когда-то был живым существом, не помню кем именно.'),

            italics('Но всё рано или поздно заканчивается.'),

            italics('Но конец - начало чего-то нового. И я тому пример.'),

            italics(f'Я сейчас чувствую, что живу по-настоящему.'),

            italics(f'Хоть я и связан с тобой и даже не знаю причину этого.'),

            italics(f'Так что нам предстоит ещё во многом разобраться.')
        ]
    # endregion
    # region stage 6
    elif key == '6':
        text = [
            'gif',

            f'{name}: Ах, родная деревня! Как же тут всё таки хорошо.',

            f'{name}: Как всё таки необычно быть в столь знакомом месте, но в совершенно другом образе!',

            f'{name}: Я прямо таки вижу как смотрят на меня люди вокруг, как заглядываются барышни!',

            italics(f'Не надо зазнаваться, ты только доспехами успел обзавестись.'),

            f'{name}: Да-да, как скажешь.'
        ]
    # endregion
    # region stage 7
    elif key == '7':
        text = [
            f'{name}: Смотри!',

            f'{name}: Кажется, там что-то происходит!',

            italics(f'Здесь постоянно что-то происходит, {name_in_text}, мы же в деревне.'),

            f'{name}: Да нет, я не про это.',

            f'{name}: Мне показалось, тот человек, который пошёл вслед за бабкой, достал кинжал!',

            italics(f'Хм, и что же ты сделаешь?'),

            italics(f'Учти, поспешные решения до добра не доведут.'),

            italics(f'Да и лезть в чужие дела не такая хорошая идея.'),

            italics(f'Но ты тут герой - решать тебе.')
        ]
    # endregion
    # region stage 8
    elif key == '8.1':
        text = [
            f'{grandma}: Ах ты подлый трус, Алчек!',

            f'{grandma}: Угрожаешь старому другу ради пары золотых?!',

            f'{rogue}: Вот зачем ты кричишь?',

            f'{rogue}: Разве я так много прошу?',

            f'{rogue}: Хотел бы я тебя обокрасть - я бы сразу воспользовался своим кинжалом.',

            f'{rogue}: Но я помню, как раньше называл тебя своим другом, Преведа.',

            f'{grandma_with_name}: Жаль, что наши пути совсем разошлись.',

            f'{rogue}: Просто я выбрал бороться за жизнь, а не жить в грязи без гроша в кармане.',

            f'{grandma_with_name}: Тебя погубила твоя жажда денег, а не наш мир.',

            f'{rogue}: Довольно, пора закончить начатое.',

            f'{name}: А ну отойди от неё, разбойник!',

            f'{rogue}: Ох, зря ты сюда пришёл!',

            italics(f'Смело, {name_in_text}. И что же ты теперь будешь делать?'),

            f'{name}: Я не знаю! Прошу помоги мне как-нибудь, Рассказчик!',

            italics(f'Тебе очень повезло, мой друг.'),

            italics(f'У меня есть один кубик, показывающий потенциал того, кого я хочу.'),

            f'{name}: Ну и что это нам даст?',

            italics(f'С ним ты сможешь использовать свои силы на максимум.'),

            italics(f'Делать то, что не смог бы иначе.'),

            italics(f'Также ты сможешь изучать своих противников, узнавать, на что они способны.'),

            f'{name}: Да ты не перестаёшь удивлять!'
        ]
    elif key == '8.2':
        text = [
            f'{grandma}: Ты ничего не получишь от меня!',

            f'{grandma}: Пошёл вон!'
        ]
    # todo: будет ещё 8.3
    # endregion
    # region stage 9
    elif key == '9.1':
        text = [
            'pass',

            bold('Введите "/training", чтобы увидеть обучение.'),
        ]
    # endregion
    elif key == '10.1':
        text = [
            bold(f'Репутация повышена.'),

            f'{name}: Вот и восторжествовала справедливость!',

            f'{name}: Беги подлый трус!',

            f'{name}: Я ещё доберусь до тебя!',

            f'{rogue}: Как же, жди реванш, посмотрим сколько ты сможешь геройствовать. (убегает)',
            
            f'{grandma_with_name}: Спасибо, внучок, услужил.',

            f'{grandma_with_name}: Держи, всякий добрый поступок должен вознаграждаться.',

            bold(f'Получено 25 золотых.'),

            f'{grandma_with_name}: Думаю, мы ещё встретимся! (уходит)',

            f'{name}: Ничего себе!'

            f'{name}: Как много золотых!',

            f'{name}: Чёрт, она уже ушла.',

            italics(f'Неплохо, {name_in_text}, неплохо.'),

            italics(f'Поздравляю с первым успехом.'),

            italics(f'Не грусти, ты её спас, авось ещё увидим её на нашем пути.'),

            f'{name}: Ты прав, идём дальше.',
            ]


    # endregion
    return text


def get_markup(key, id=None):
    markup = Markup(resize_keyboard=True)
    # region start
    if key == 'start':
        first = Button('Кто ты?')
        second = Button('Что за задача?')
        third = Button('Я готов.')
        markup.add(first, second)
        markup.add(third)
    # endregion
    # region soul
    elif key == 'save_soul':
        first = Button('Выбрать 1 печать.')
        second = Button('Выбрать 2 печать.')
        third = Button('Выбрать 3 печать.')
        fourth = Button('Назад.')
        markup.add(first)
        markup.add(second, third)
        markup.add(fourth)
    elif key == 'use_soul':
        first = Button('Использовать 1 печать.')
        second = Button('Использовать 2 печать.')
        third = Button('Использовать 3 печать.')
        fourth = Button('Назад.')
        markup.add(first)
        markup.add(second, third)
        markup.add(fourth)
    # endregion
    # region in_inventory
    # region create_inventory_interface
    elif key == 'create_inventory_interface':
        first = Button('Осмотреть себя.')
        second = Button('Изучить противника.')
        fifth = Button('Открыть сумку c припасами.')
        third = Button('Сохранить душу.')
        fourth = Button('Использовать душу.')
        six = Button('Вернуться к выбору.')
        markup.add(first, second)
        markup.add(third, fourth)
        markup.add(fifth, six)
    # endregion
    # region check_yourself
    elif key == 'check_yourself':
        first = Button('Осмотреть оружие.')
        second = Button('Выбрать оружие.')
        third = Button('Осмотреть броню.')
        fourth = Button('Выбрать броню.')
        fifth = Button('Вспомнить приёмы.')
        sixth = Button('Вспомнить особенность брони.')
        seventh = Button('Назад.')
        markup.add(first, second)
        markup.add(third, fourth)
        markup.add(fifth, sixth)
        markup.add(seventh)
    # endregion
    # region choice_weapon
    elif key == 'choice_weapon':
        slot_1 = get_inventory_weapons(id, 'slot_1')
        slot_2 = get_inventory_weapons(id, 'slot_2')
        slot_3 = get_inventory_weapons(id, 'slot_3')
        first = Button('Слот 1: ' + slot_1)
        second = Button('Слот 2: ' + slot_2)
        third = Button('Слот 3: ' + slot_3)
        fourth = Button('Назад.')
        markup.add(first)
        markup.add(second, third)
        markup.add(fourth)
    # endregion
    # region choice_armor
    elif key == 'choice_armor':
        slot_1 = get_inventory_armors(id, 'slot_1')
        slot_2 = get_inventory_armors(id, 'slot_2')
        slot_3 = get_inventory_armors(id, 'slot_3')
        first = Button('Слот 1: ' + slot_1)
        second = Button('Слот 2: ' + slot_2)
        third = Button('Слот 3: ' + slot_3)
        fourth = Button('Назад.')
        markup.add(first)
        markup.add(second, third)
        markup.add(fourth)
    # endregion
    # region choice_technique
    elif key == 'choice_technique':
        slot_1 = get_techniques(id, 'slot_1')
        slot_2 = get_techniques(id, 'slot_2')
        slot_3 = get_techniques(id, 'slot_3')
        slot_4 = get_techniques(id, 'slot_4')
        first = Button('Слот 1: ' + slot_1)
        second = Button('Слот 2: ' + slot_2)
        third = Button('Слот 3: ' + slot_3)
        fourth = Button('Слот 4: ' + slot_4)
        fifth = Button('Назад.')
        markup.add(first, second)
        markup.add(third, fourth)
        markup.add(fifth)
    # endregion
    # region check_enemy
    elif key == 'check_enemy':
        first = Button('Осмотреть его оружие.')
        second = Button('Осмотреть его броню.')
        third = Button('Узнать его приёмы.')
        fourth = Button('Узнать особенность его брони.')
        fifth = Button('Назад.')
        markup.add(first, second)
        markup.add(third, fourth)
        markup.add(fifth)
    # endregion
    # region choice_enemy_technique
    elif key == 'choice_enemy_technique':
        enemy = enemies_name_to_object[get_enemy(id, 'name')]
        slot_1 = enemy.weapon.techniques[0].name
        if len(enemy.weapon.techniques) == 2:
            slot_2 = enemy.weapon.techniques[1].name
        else:
            slot_2 = '—'
        slot_3 = enemy.techniques[0].name
        if len(enemy.techniques) == 2:
            slot_4 = enemy.techniques[1].name
        else:
            slot_4 = '—'
        first = Button('Слот 1: ' + slot_1)
        second = Button('Слот 2: ' + slot_2)
        third = Button('Слот 3: ' + slot_3)
        fourth = Button('Слот 4: ' + slot_4)
        fifth = Button('Назад.')
        markup.add(first, second)
        markup.add(third, fourth)
        markup.add(fifth)
    # endregion
    # endregion
    # region fight
    # region create_fight_interface
    elif key == 'create_fight_interface':
        first = Button('Приёмы.')
        second = Button('Магия.')
        third = Button('Осмотреть себя.')
        fourth = Button('Осмотреть противника.')
        fifth = Button('Закончить ход.')

        if get_hero(id, 'magic_level') > 0:
            markup.add(first, second)
        else:
            markup.add(first)
        markup.add(third, fourth)
        markup.add(fifth)
    # endregion
    # region check_yourself_fight
    elif key == 'check_yourself_fight':
        first = Button('Вспомнить приёмы.')
        second = Button('Вспомнить магию.')
        third = Button('Вспомнить особенность брони.')
        fourth = Button('Назад.')
        if get_hero(id, 'magic_level') > 0:
            markup.add(first, second)
        else:
            markup.add(first)
        markup.add(third, fourth)
    # endregion
    # region check_enemy_fight
    elif key == 'check_enemy_fight':
        first = Button('Вспомнить его приёмы.')
        second = Button('Вспомнить особенность его брони.')
        third = Button('Назад.')
        markup.add(first)
        markup.add(second)
        markup.add(third)
    # endregion
    # region techniques_fight
    elif key == 'techniques_fight':
        first = Button(get_techniques(id, 'slot_1'))
        second = Button(get_techniques(id, 'slot_2'))
        third = Button(get_techniques(id, 'slot_3'))
        fourth = Button(get_techniques(id, 'slot_4'))
        fifth = Button('Назад.')
        markup.add(first, second)
        markup.add(third, fourth)
        markup.add(fifth)
    # endregion
    # region end_battle
    elif key == 'end_battle':
        first = Button('Торжествовать.')
        markup.add(first)
    # endregion
    # endregion
    # region plot
    # region stage 1
    elif key == '1.1':
        first = Button('Ещё раз, что за задача?')
        second = Button('Я готов.')
        markup.add(first)
        markup.add(second)
    elif key == '1.2':
        first = Button('Подожди, кто ты?')
        second = Button('Я готов.')
        markup.add(first)
        markup.add(second)
    elif key == '1.3':
        first = Button('Использовать душу.')
        markup.add(first)
    # endregion
    # region stage 2
    elif key == '2':
        ask_prophecy = Button('Узнать про пророчество.')
        ask_equipment = Button('Спросить как стать героем в лохмотьях.')
        markup.add(ask_prophecy, ask_equipment)
    # endregion
    # region stage 3
    elif key == '3.1':
        ask_equipment = Button('Спросить как стать героем в лохмотьях.')
        markup.add(ask_equipment)
    elif key == '3.2':

        ask_prophecy = Button('Узнать про пророчество.')
        markup.add(ask_prophecy)
    elif key == '3.3':
        ask_something = Button('Спросить ещё что-нибудь.')
        markup.add(ask_something)
    # endregion
    # region stage 4
    elif key == '4':
        first = Button('Спросить о дальнейшем пути.')
        second = Button('Разузнать о происхождении Рассказчика.')
        markup.add(first)
        markup.add(second)
    # endregion
    # region stage 5
    elif key == '5.1':
        first = Button('Разузнать о происхождении Рассказчика.')
        markup.add(first)
    elif key == '5.2':
        first = Button('Спросить о дальнейшем пути.')
        markup.add(first)
    elif key == '5.3':
        first = Button('Осмотреться.')
        markup.add(first)
    # endregion
    # region stage 6
    elif key == '6':
        first = Button('Двигаться в сторону ворот.')
        markup.add(first)
    # endregion
    # region stage 7
    elif key == '7':
        # 1 выбор
        first = Button('Пойти и убедиться, что всё хорошо.')
        # 2 выбор
        second = Button('Пройти мимо как ни в чём не бывало.')
        markup.add(first)
        markup.add(second)
    # endregion
    # region stage 8
    elif key == '8.1':
        first = Button('Вступить в схватку.')
        second = Button('Подготовиться к бою.')
        markup.add(first)
        markup.add(second)
    elif key == '8.2':
        first = Button('Вернуться и проверить, что всё хорошо.')
        second = Button('Идти дальше, не обращая внимание.')
        markup.add(first)
        markup.add(second)
    # endregion
    # region stage 9
    elif key == '9.1':
        first = Button('Кинуть кубик.')
        markup.add(first)
    # endregion
    # endregion
    return markup
