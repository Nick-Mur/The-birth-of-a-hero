import datetime
import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase


class User(SqlAlchemyBase):
    __tablename__ = 'user'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    userID = sqlalchemy.Column(sqlalchemy.Integer,
                               index=True, unique=True, nullable=True)
    reputation = sqlalchemy.Column(sqlalchemy.Integer, default=0)
    special_situation = sqlalchemy.Column(sqlalchemy.String, default='')
    stage = sqlalchemy.Column(sqlalchemy.Integer, default=1)
    #выборы - строчка из чисел, где число - выбор в сцене(1, 2 или 3)
    choices = sqlalchemy.Column(sqlalchemy.String, default='')
    created_date = sqlalchemy.Column(sqlalchemy.DateTime,
                                     default=datetime.datetime.now)

    hero = orm.relationship("Hero", back_populates='user')
    enemy = orm.relationship("Enemy", back_populates='user')
    inventory_weapons = orm.relationship("InventoryWeapons", back_populates='user')
    inventory_armors = orm.relationship("InventoryArmors", back_populates='user')
    inventory_consumables = orm.relationship("InventoryConsumables", back_populates='user')
    fight = orm.relationship("Fight", back_populates='user')
    techniques = orm.relationship("Techniques", back_populates='user')
    magic = orm.relationship("Magic", back_populates='user')
    players_saves = orm.relationship("PlayersSaves", back_populates='user')

    def __repr__(self):
        return '<User %r>' % self.id