from project_data.db_birth_hero.db_operation import *
from project_data.settings.fonts import bold


class Techniques:
    def __init__(self, name, cost, description, mechanics):
        self.name = name
        self.cost = cost
        self.description = description
        self.mechanics = mechanics


    def info(self, id=None, full=True):
        if full:
            text = '+=={:::::::::::::::::> |TECHNIQUE|\n' \
                   '- - - - - - - - - - - - - - - - - - - - - -' \
                   f'\n🪧 Название: {self.name}\n' \
                   f'\n🫰 Стоимость: {self.cost} о.п.\n' \
                   f'✨ Механика: {self.mechanics}\n' \
                   f'\n📜 Описание: {self.description}\n' \
                   f'- - - - - - - - - - - - - - - - - - - - - -'
        else:
            text = '+=={:::::::::::::::::> |TECHNIQUE|\n' \
                   '- - - - - - - - - - - - - - - - - - - - - -' \
                   f'\n🪧 Название: {self.name}\n' \
                   f'\n🫰 Стоимость: {self.cost} о.п.\n' \
                   f'✨ Механика: {self.mechanics}\n' \
                   f'- - - - - - - - - - - - - - - - - - - - - -'
        return text
    

class HeroPunch(Techniques):
    def use(self, subject, damage, id):
        if subject.class_name == 'Hero':
            points = get_fight(id, 'self_points')
            if points >= self.cost:
                save_fight(id, 'self_sequence', get_fight(id, 'self_sequence') + 'П')
                save_fight(id, 'self_points', points - self.cost)
                if get_hero(id, 'defence') > 0:
                    damage *= 2
                defence = get_enemy(id, 'defence')
                text = [bold(f'{get_hero(id, "name")} использовал *{self.name}*'), bold(f'Нанесено {damage} урона.')]
                if defence > 0:
                    if defence >= damage:
                        save_enemy(id, 'defence', defence - damage)
                        if defence - damage == 0:
                            text.append(bold('Защита врага пробита.'))
                    else:
                        damage -= defence
                        save_enemy(id, 'defence', 0)
                        health = get_enemy(id, 'health')
                        save_enemy(id, 'health', health - damage)
                        text.append(bold('Защита врага пробита.'))
                else:
                    health = get_enemy(id, 'health')
                    save_enemy(id, 'health', health - damage)
            else:
                text = [
                    'pass',

                    bold('Не хватает о.п.')
                ]
        else:
            save_fight(id, 'enemy_sequence', get_fight(id, 'enemy_sequence') + 'П')
            points = get_fight(id, 'enemy_points')
            save_fight(id, 'enemy_points', points - self.cost)
            damage = subject.weapon.damage
            if get_enemy(id, 'defence') > 0:
                damage *= 2
            text = [bold(f'{get_enemy(id, "name")} использовал *{self.name}*'), bold(f'{subject.name} нанёс {damage} урона.')]
            defence = get_hero(id, 'defence')
            if defence > 0:
                if defence >= damage:
                    save_hero(id, 'defence', defence - damage)
                    text = [bold(f'{subject.name} нанёс {damage} урона.')]
                else:
                    damage -= defence
                    save_hero(id, 'defence', 0)
                    health = get_hero(id, 'health')
                    save_hero(id, 'health', health - damage)
                    text.append(bold(f'{subject.name} пробил защиту.'))
            else:
                health = get_hero(id, 'health')
                save_hero(id, 'health', health - damage)
        return text



class DefencePosture(Techniques):
    def use(self, subject, damage, id):
        if subject.class_name == 'Hero':
            points = get_fight(id, 'self_points')
            if points >= self.cost:
                save_fight(id, 'self_sequence', get_fight(id, 'self_sequence') + 'П')
                text = [bold(f'{get_hero(id, "name")} использовал *{self.name}*')]
                save_fight(id, 'self_points', points - self.cost)
                health = get_hero(id, 'health')
                max_health = get_hero(id, 'max_health')
                defence =  get_hero(id, 'defence')
                if health == max_health:
                    damage = int(1.5 * damage)
                elif health < (0.75 * max_health):
                    damage = int(0.5 * damage)
                save_hero(id, 'defence', defence + damage)
                text.append(bold(f'Получено {damage} защиты.'))
            else:
                text = [
                    'pass',

                    bold('Не хватает о.п.')
                ]
        else:
            save_fight(id, 'enemy_sequence', get_fight(id, 'enemy_sequence') + 'П')
            text = [bold(f'{get_enemy(id, "name")} использовал *{self.name}*')]
            points = get_fight(id, 'enemy_points')
            save_fight(id, 'enemy_points', points - self.cost)
            health = get_enemy(id, 'health')
            max_health = subject.health
            defence = get_enemy(id, 'defence')
            if health == max_health:
                damage = int(1.5 * damage)
            elif health < (0.75 * max_health):
                damage = int(0.5 * damage)
            save_enemy(id, 'defence', defence + damage)
            text.append(bold(f'{subject.name} получил {damage} защиты.'))
        return text

class KnifeThrowing(Techniques):
    def use(self, subject, damage, id):
        if subject.class_name == 'Hero':
            points = get_fight(id, 'self_points')
            if points >= 2:
                save_fight(id, 'self_sequence', get_fight(id, 'self_sequence') + ('П' * (points - 1)))
                damage = 1 * (points - 1)
                text = [bold(f'{get_hero(id, "name")} использовал *{self.name}*'), bold(f'Нанесено {damage} урона.')]
                save_fight(id, 'self_points', 1)
                defence =  get_enemy(id, 'defence')
                if defence > 0:
                    if defence >= damage:
                        save_enemy(id, 'defence', defence - damage)
                        if defence - damage == 0:
                            text.append(bold('Защита врага пробита.'))
                    else:
                        damage -= defence
                        save_enemy(id, 'defence', 0)
                        health = get_enemy(id, 'health')
                        save_enemy(id, 'health', health - damage)
                        text.append(bold('Защита врага пробита.'))
                else:
                    health = get_enemy(id, 'health')
                    save_enemy(id, 'health', health - damage)
            else:
                text = [
                    'pass',

                    bold('Не хватает о.п.')
                ]
        else:
            points = get_fight(id, 'enemy_points')
            save_fight(id, 'enemy_sequence', get_fight(id, 'enemy_sequence') + ('П' * (points - 1)))
            damage = 1 * (points - 1)
            text = [bold(f'{get_enemy(id, "name")} использовал *{self.name}*'), bold(f'{subject.name} нанёс {damage} урона.')]
            save_fight(id, 'enemy_points', 1)
            defence = get_hero(id, 'defence')
            if defence > 0:
                if defence >= damage:
                    save_hero(id, 'defence', defence - damage)
                    if defence == 0:
                        text.append(bold(f'{subject.name} пробил защиту.'))
                else:
                    damage -= defence
                    save_hero(id, 'defence', 0)
                    health = get_hero(id, 'health')
                    save_hero(id, 'health', health - damage)
                    text.append(bold(f'{subject.name} пробил защиту.'))
            else:
                health = get_hero(id, 'health')
                save_hero(id, 'health', health - damage)
        return text



class ThousandAndOneStrikes(Techniques):
    def use(self, subject, damage, id):
        if subject.class_name == 'Hero':
            points = get_fight(id, 'self_points')
            if points >= self.cost:
                damage = 2 * get_fight(id, 'self_sequence').count('П')
                save_fight(id, 'self_sequence', get_fight(id, 'self_sequence') + 'П')
                text = [bold(f'{get_hero(id, "name")} использовал *{self.name}*'), bold(f'Нанесено {damage} урона.')]
                save_fight(id, 'self_points', points - self.cost)
                defence =  get_enemy(id, 'defence')
                if defence > 0:
                    if defence >= damage:
                        save_enemy(id, 'defence', defence - damage)
                        if defence - damage == 0:
                            text.append(bold('Защита врага пробита.'))
                    else:
                        damage -= defence
                        save_enemy(id, 'defence', 0)
                        health = get_enemy(id, 'health')
                        save_enemy(id, 'health', health - damage)
                        text.append(bold('Защита врага пробита.'))
                else:
                    health = get_enemy(id, 'health')
                    save_enemy(id, 'health', health - damage)
            else:
                text = [
                    'pass',

                    bold('Не хватает о.п.')
                ]
        else:
            damage = 2 * get_fight(id, 'enemy_sequence').count('П')
            save_fight(id, 'enemy_sequence', get_fight(id, 'enemy_sequence') + 'П')
            text = [bold(f'{get_enemy(id, "name")} использовал *{self.name}*'), bold(f'{subject.name} нанёс {damage} урона.')]
            points = get_fight(id, 'enemy_points')
            save_fight(id, 'enemy_points', points - self.cost)
            defence = get_hero(id, 'defence')
            if defence > 0:
                if defence >= damage:
                    save_hero(id, 'defence', defence - damage)
                    if defence - damage == 0:
                        text.append(bold(f'{subject.name} пробил защиту.'))
                else:
                    damage -= defence
                    save_hero(id, 'defence', 0)
                    health = get_hero(id, 'health')
                    save_hero(id, 'health', health - damage)
                    text.append(bold(f'{subject.name} пробил защиту.'))
            else:
                health = get_hero(id, 'health')
                save_hero(id, 'health', health - damage)
        return text

class SneakAttack(Techniques):
    def use(self, subject, damage, id):
        if subject.class_name == 'Hero':
            points = get_fight(id, 'self_points')
            if points >= self.cost:
                save_fight(id, 'self_sequence', get_fight(id, 'self_sequence') + 'П')
                text = [bold(f'{get_hero(id, "name")} использовал *{self.name}*'), bold(f'Нанесено {damage * 2} урона.')]
                save_fight(id, 'self_points', points - self.cost)
                defence =  get_enemy(id, 'defence')
                health = get_enemy(id, 'health')
                save_enemy(id, 'defence', defence - damage)
                save_enemy(id, 'health', health - damage)
                if (defence - damage <= 0) and (defence > 0):
                    text.append(bold('Защита врага пробита.'))
            else:
                text = [
                    'pass',

                    bold('Не хватает о.п.')
                ]
        else:
            save_fight(id, 'enemy_sequence', get_fight(id, 'enemy_sequence') + 'П')
            text = [bold(f'{get_enemy(id, "name")} использовал *{self.name}*'), bold(f'{subject.name} нанёс {damage * 2} урона.')]
            points = get_fight(id, 'enemy_points')
            save_fight(id, 'enemy_points', points - self.cost)
            defence = get_hero(id, 'defence')
            health = get_hero(id, 'health')
            save_hero(id, 'defence', defence - damage)
            save_hero(id, 'health', health - damage)
            if (defence - damage <= 0) and (defence > 0):
                text.append(bold(f'{subject.name} пробил защиту.'))
        return text


hero_punch = HeroPunch(name='Удар героя', cost=2, description=
'Герой не рвётся в бой, теряя голову, и вознаграждается за это.', mechanics=
'Пока есть защита ты наносишь двойной урон.')

defence_posture = DefencePosture(name='Защитная стойка', cost=2, description=
'Каждый герой должен знать, атака без защиты - верный способ проиграть битву.', mechanics=
'Чем больше у тебя здоровья, тем больше ты получаешь защиты (при 100% хп - 150%, при >=75% - 100%, меньше - 50%).')

knife_throwing = KnifeThrowing(name='Метание ножей', cost='X - 1', description=
'Тактика закидать противника чем попало - то же тактика.', mechanics=
'Оставляет 1 о.п., за каждое потраченное о.п. наносит 1 урон, считая каждое нанесение урона ударом. (можно использовать, '
'имея минимум 2 о.п.)')

thousand_and_one_strikes = ThousandAndOneStrikes(name='Тысяча и один удар', cost=1, description=
'Один удар, нанесённый тысячу раз, страшнее тысячи различных ударов.', mechanics=
'Наносит 2 урона за каждый приём в последовательности.')
sneak_attack = SneakAttack(name='Удар исподтишка', cost=3, description=
'Иногда в драке не выиграть честным путём, поэтому не редки удары исподтишка.', mechanics=
'Бьёт и по здоровью, и по броне.')
techniques_name_to_object = {'Удар героя': hero_punch,
                             'Защитная стойка': defence_posture,
                             'Метание ножей': knife_throwing,
                             'Тысяча и один удар': thousand_and_one_strikes,
                             'Удар исподтишка': sneak_attack}

"""""
Последовательность:
П - приём
М - магия
"""""