from project_data.db_birth_hero.db_operation import *
from project_data.settings.fonts import bold


class Techniques:
    def __init__(self, name, cost, mechanics):
        self.name = name
        self.cost = cost
        self.mechanics = mechanics
    

class HeroPunch(Techniques):
    def use(self, subject, weapon=None, id=None):
        weapon_range, distance = weapon.w_range, get_fight(id, 'distance')
        if weapon_range < distance: return 'Не хватает дальности оружия.'
        if get_fight(id, 'self_sequence') == '': cost = 0
        else: cost = self.cost
        if get_fight(id, 'self_points') < cost: return 'Не достаточно о.п.'
        damage, health, defence = weapon.damage, get_enemy(id, 'health'), get_enemy(id, 'defence')
        if defence > 0: defence -= damage
        else: health -= damage
        if len(get_fight(id, 'self_sequence').split(', ')) == 2: distance += 1
        return [health, defence, distance, 'other']


class DefencePosture(Techniques):
    def use(self, subject, weapon=None, id=None):
        if get_fight(id, 'self_points') < self.cost: return 'Не достаточно о.п.'
        damage, health, defence = weapon.damage, get_hero(id, 'health'), get_hero(id, 'defence')
        if get_fight(id, 'self_sequence') == '': damage *= 2
        return [health, defence + damage, get_fight(id, 'distance'), 'self']


class KnifeThrowing(Techniques):
    def use(self, subject, damage, id):
        if subject.class_name == 'Hero':
            points = get_fight(id, 'self_points')
            if points >= 2:
                save_fight(id, 'self_sequence', get_fight(id, 'self_sequence') + ('П' * (points - 1)))
                damage = 1 * (points - 1)
                text = [bold(f'{get_hero(id, "name")} использовал *{self.name}*'), bold(f'Нанесено {damage} урона.')]
                save_fight(id, 'self_points', 1)
                defence =  get_enemy(id, 'defence')
                if defence > 0:
                    if defence >= damage:
                        save_enemy(id, 'defence', defence - damage)
                        if defence - damage == 0:
                            text.append(bold('Защита врага пробита.'))
                    else:
                        damage -= defence
                        save_enemy(id, 'defence', 0)
                        health = get_enemy(id, 'health')
                        save_enemy(id, 'health', health - damage)
                        text.append(bold('Защита врага пробита.'))
                else:
                    health = get_enemy(id, 'health')
                    save_enemy(id, 'health', health - damage)
            else:
                text = [
                    'pass',

                    bold('Не хватает о.п.')
                ]
        else:
            points = get_fight(id, 'enemy_points')
            save_fight(id, 'enemy_sequence', get_fight(id, 'enemy_sequence') + ('П' * (points - 1)))
            damage = 1 * (points - 1)
            text = [bold(f'{get_enemy(id, "name")} использовал *{self.name}*'), bold(f'{subject.name} нанёс {damage} урона.')]
            save_fight(id, 'enemy_points', 1)
            defence = get_hero(id, 'defence')
            if defence > 0:
                if defence >= damage:
                    save_hero(id, 'defence', defence - damage)
                    if defence == 0:
                        text.append(bold(f'{subject.name} пробил защиту.'))
                else:
                    damage -= defence
                    save_hero(id, 'defence', 0)
                    health = get_hero(id, 'health')
                    save_hero(id, 'health', health - damage)
                    text.append(bold(f'{subject.name} пробил защиту.'))
            else:
                health = get_hero(id, 'health')
                save_hero(id, 'health', health - damage)
        return text



class ThousandAndOneStrikes(Techniques):
    def use(self, subject, damage, id):
        if subject.class_name == 'Hero':
            points = get_fight(id, 'self_points')
            if points >= self.cost:
                damage = 2 * get_fight(id, 'self_sequence').count('П')
                save_fight(id, 'self_sequence', get_fight(id, 'self_sequence') + 'П')
                text = [bold(f'{get_hero(id, "name")} использовал *{self.name}*'), bold(f'Нанесено {damage} урона.')]
                save_fight(id, 'self_points', points - self.cost)
                defence =  get_enemy(id, 'defence')
                if defence > 0:
                    if defence >= damage:
                        save_enemy(id, 'defence', defence - damage)
                        if defence - damage == 0:
                            text.append(bold('Защита врага пробита.'))
                    else:
                        damage -= defence
                        save_enemy(id, 'defence', 0)
                        health = get_enemy(id, 'health')
                        save_enemy(id, 'health', health - damage)
                        text.append(bold('Защита врага пробита.'))
                else:
                    health = get_enemy(id, 'health')
                    save_enemy(id, 'health', health - damage)
            else:
                text = [
                    'pass',

                    bold('Не хватает о.п.')
                ]
        else:
            damage = 2 * get_fight(id, 'enemy_sequence').count('П')
            save_fight(id, 'enemy_sequence', get_fight(id, 'enemy_sequence') + 'П')
            text = [bold(f'{get_enemy(id, "name")} использовал *{self.name}*'), bold(f'{subject.name} нанёс {damage} урона.')]
            points = get_fight(id, 'enemy_points')
            save_fight(id, 'enemy_points', points - self.cost)
            defence = get_hero(id, 'defence')
            if defence > 0:
                if defence >= damage:
                    save_hero(id, 'defence', defence - damage)
                    if defence - damage == 0:
                        text.append(bold(f'{subject.name} пробил защиту.'))
                else:
                    damage -= defence
                    save_hero(id, 'defence', 0)
                    health = get_hero(id, 'health')
                    save_hero(id, 'health', health - damage)
                    text.append(bold(f'{subject.name} пробил защиту.'))
            else:
                health = get_hero(id, 'health')
                save_hero(id, 'health', health - damage)
        return text

class SneakAttack(Techniques):
    def use(self, subject, damage, id):
        if subject.class_name == 'Hero':
            points = get_fight(id, 'self_points')
            if points >= self.cost:
                save_fight(id, 'self_sequence', get_fight(id, 'self_sequence') + 'П')
                text = [bold(f'{get_hero(id, "name")} использовал *{self.name}*'), bold(f'Нанесено {damage * 2} урона.')]
                save_fight(id, 'self_points', points - self.cost)
                defence =  get_enemy(id, 'defence')
                health = get_enemy(id, 'health')
                save_enemy(id, 'defence', defence - damage)
                save_enemy(id, 'health', health - damage)
                if (defence - damage <= 0) and (defence > 0):
                    text.append(bold('Защита врага пробита.'))
            else:
                text = [
                    'pass',

                    bold('Не хватает о.п.')
                ]
        else:
            save_fight(id, 'enemy_sequence', get_fight(id, 'enemy_sequence') + 'П')
            text = [bold(f'{get_enemy(id, "name")} использовал *{self.name}*'), bold(f'{subject.name} нанёс {damage * 2} урона.')]
            points = get_fight(id, 'enemy_points')
            save_fight(id, 'enemy_points', points - self.cost)
            defence = get_hero(id, 'defence')
            health = get_hero(id, 'health')
            save_hero(id, 'defence', defence - damage)
            save_hero(id, 'health', health - damage)
            if (defence - damage <= 0) and (defence > 0):
                text.append(bold(f'{subject.name} пробил защиту.'))
        return text


hero_punch = HeroPunch(name='Удар героя', cost=1, mechanics=
'Пока есть защита ты наносишь двойной урон.')

defence_posture = DefencePosture(name='Защитная стойка', cost=2, mechanics=
'Чем больше у тебя здоровья, тем больше ты получаешь защиты (при 100% хп - 150%, при >=75% - 100%, меньше - 50%).')

knife_throwing = KnifeThrowing(name='Метание ножей', cost='X - 1', mechanics=
'Оставляет 1 о.п., за каждое потраченное о.п. наносит 1 урон, считая каждое нанесение урона ударом. (можно использовать, '
'имея минимум 2 о.п.)')

thousand_and_one_strikes = ThousandAndOneStrikes(name='Тысяча и один удар', cost=1, mechanics=
'Наносит 2 урона за каждый приём в последовательности.')
sneak_attack = SneakAttack(name='Удар исподтишка', cost=3, mechanics=
'Бьёт и по здоровью, и по броне.')
techniques_name_to_object = {'Удар героя': hero_punch,
                             'Защитная стойка': defence_posture,
                             'Метание ножей': knife_throwing,
                             'Тысяча и один удар': thousand_and_one_strikes,
                             'Удар исподтишка': sneak_attack}