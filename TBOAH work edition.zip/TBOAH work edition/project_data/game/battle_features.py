from project_data.db_birth_hero.db_operation import *


not_removing_points_after_move = ['Сияющие доспехи']
def self_points_after_move(id):
    if get_hero(id, 'equipped_armor') in not_removing_points_after_move: return
    else: save_fight(id, 'self_points', 0)

def enemy_points_after_move(id):
    save_fight(id, 'enemy_points', 0)
