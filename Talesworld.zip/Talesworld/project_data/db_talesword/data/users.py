import datetime
import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase


class User(SqlAlchemyBase):
    __tablename__ = 'user'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    userID = sqlalchemy.Column(sqlalchemy.Integer,
                               index=True, unique=True, nullable=True)
    reputation_point = sqlalchemy.Column(sqlalchemy.Integer, default=0)
    writers_point = sqlalchemy.Column(sqlalchemy.Integer, default=0)
    magic_point = sqlalchemy.Column(sqlalchemy.Integer, default=0)
    in_battle = sqlalchemy.Column(sqlalchemy.Integer, default=0)
    in_inventory = sqlalchemy.Column(sqlalchemy.Integer, default=False)
    in_dialogue = sqlalchemy.Column(sqlalchemy.Integer, default=False)
    stage = sqlalchemy.Column(sqlalchemy.Integer, default=False)
    created_date = sqlalchemy.Column(sqlalchemy.DateTime,
                                     default=datetime.datetime.now)

    hero = orm.relationship("Hero", back_populates='user')
    enemy = orm.relationship("Enemy", back_populates='user')
    merchant_inventory = orm.relationship("Merchant_inventory", back_populates='user')
    inventory_weapons = orm.relationship("InventoryWeapons", back_populates='user')
    inventory_armors = orm.relationship("InventoryArmors", back_populates='user')
    inventory_consumables = orm.relationship("InventoryConsumables", back_populates='user')
    boss = orm.relationship("Boss", back_populates='user')

    def __repr__(self):
        return '<User %r>' % self.id