import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Inventory(SqlAlchemyBase):
    __tablename__ = 'inventory'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    consumables = sqlalchemy.Column(sqlalchemy.String)
    weapon = sqlalchemy.Column(sqlalchemy.Integer)
    armor = sqlalchemy.Column(sqlalchemy.Integer)

    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="inventory")

    def __repr__(self):
        return '<Inventory %r>' % self.id