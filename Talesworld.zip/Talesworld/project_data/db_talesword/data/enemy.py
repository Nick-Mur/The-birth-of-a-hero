import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Enemy(SqlAlchemyBase):
    __tablename__ = 'enemy'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    health = sqlalchemy.Column(sqlalchemy.Integer)
    defence = sqlalchemy.Column(sqlalchemy.Integer)
    weapon = sqlalchemy.Column(sqlalchemy.Integer)
    armor = sqlalchemy.Column(sqlalchemy.Integer)

    user_id = sqlalchemy.Column(sqlalchemy.Integer,
                                sqlalchemy.ForeignKey("user.userID"))
    user = orm.relationship('User', back_populates="enemy")

    def __repr__(self):
        return '<Enemy %r>' % self.id